# mmBERT-small 五维文本评分

一个面向 **100 万条已标注文本、五个固定评分维度、每维 1～5 分、GPU 推理** 的训练项目。

使用 **PyTorch + Transformers + Datasets**。文本经过一次 mmBERT 编码，再通过一个 `Linear(hidden_size, 25)` 得到五组五分类概率。对外输出五个整数分，也可输出期望分和每一档概率；不调用 `generate()`。

默认骨干：[`jhu-clsp/mmBERT-small`](https://huggingface.co/jhu-clsp/mmBERT-small)。默认全参数微调、带 padding mask 的 mean pooling、五维交叉熵、最大长度 512 tokens。维度名称先用 `dim_1`～`dim_5`，请按业务定义修改配置。

> **交付验证状态**：数据准备与 NumPy 指标逻辑已执行验证，所有 Python 文件已做语法检查；同时按固定版本官方源码检查了 ModernBERT 和 Trainer 的关键接口。当前交付环境没有 PyTorch/CUDA，下载依赖的自动审批服务因容量不足未完成，因此完整训练、模型重载、FastAPI 和 GPU 测速尚未实际运行。项目包含离线小模型端到端检查脚本和 pytest 测试，请在安装依赖后先运行。详见 `VALIDATION.md`。

## 1. 项目内容

| 文件 | 用途 |
|---|---|
| `configs/train.yaml` | 模型、数据、训练参数；五个维度名称在这里修改 |
| `prepare_data.py` | 校验、精确去重、按同源组切分训练/验证/测试集 |
| `train.py` | 单卡/多卡训练、最佳模型选择、断点续训 |
| `evaluate.py` | 独立测试集评估、每维指标与混淆矩阵 |
| `predict.py` | 流式 JSONL 批量推理 |
| `serve.py` | 单 GPU 的 FastAPI 批量评分接口 |
| `benchmark.py` | 进程内分词、推理、后处理的速度测试 |
| `five_scores/modeling.py` | 一次文本编码 + 五维评分头；显式初始化与序列化 |
| `five_scores/data.py` | JSONL/CSV/Parquet 数据读取和分词缓存 |
| `five_scores/metrics.py` | MAE、固定五档 Macro-F1、QWK 等指标 |
| `five_scores/inference.py` | 共用预测器、精度选择、截断标记 |
| `scripts/smoke_test.py` | 无需下载模型的完整训练流程检查 |
| `scripts/create_tiny_fixture.py` | 创建小型随机 ModernBERT 和本地 tokenizer，仅用于测试 |
| `tests/` | 模型、数据、指标、重载和 HTTP 接口的测试 |
| `examples/` | 用于说明格式的合成数据，分数没有业务含义 |

下面的命令都在解压后的 **`mmbert_five_scores` 项目根目录** 执行；所有相对路径以当前工作目录为准。

## 2. 安装环境

默认面向 Linux / WSL2 + NVIDIA GPU，建议 Python 3.11 或 3.12。

```bash
python -m venv .venv
source .venv/bin/activate

# 先安装适合显卡/驱动的 PyTorch。以下为 CUDA 12.8 wheel 的示例。
python -m pip install torch==2.8.0 --index-url https://download.pytorch.org/whl/cu128

# 训练依赖；不会把已经安装的同版本 CUDA wheel 改成 CPU wheel。
python -m pip install -r requirements.txt

# 使用 HTTP 服务时再安装。
python -m pip install -r requirements-serve.txt
```

PyTorch 的 CUDA wheel 包含所需运行时组件，仍需可用的 NVIDIA 驱动。若 CUDA 12.8 wheel 不适合你的环境，请按 [PyTorch 官方 2.8 安装说明](https://pytorch.org/get-started/previous-versions/#v280) 选择对应 wheel。项目固定 PyTorch 2.8.0、Transformers 4.57.1、Datasets 4.3.0、Accelerate 1.10.1，目的是固定 API，**不是宣称这些是最新版本或已在此环境完成运行验证**。

检查 GPU：

```bash
python -c "import torch; print(torch.__version__, torch.version.cuda); print(torch.cuda.is_available()); print(torch.cuda.get_device_name(0))"
```

GPU 默认选择原生支持的 BF16，否则使用 FP16。`sdpa` 为默认注意力实现，不要求安装 `flash-attn`。CPU 只用于小规模功能检查，可另装 CPU wheel：

```bash
python -m pip install torch==2.8.0 --index-url https://download.pytorch.org/whl/cpu
```

### 先运行一次离线流程检查

```bash
# 只创建很小的随机模型和本地 tokenizer；不下载 mmBERT，不访问模型网络。
python scripts/smoke_test.py --device cpu

# 也可以在 GPU 环境检查；保留中间模型和日志便于排查。
python scripts/smoke_test.py --device cuda --work-dir outputs/smoke-gpu

# 更完整的边界测试。
python -m pip install -r requirements-dev.txt
python -m pytest -q
```

smoke 流程覆盖：生成随机模型 → 训练两步 → 保存并重载 → 批量预测 → 独立评估 → 速度脚本 → 从 checkpoint 续训到第三步 → 再次预测。它验证代码能衔接，不衡量预训练 mmBERT 的业务准确率。脚本失败时会返回非零退出码并保留诊断目录。

## 3. 准备标签数据

### 推荐格式：JSONL

每行一个对象，`scores` 的顺序必须与配置中的五个 `dimension_names` 一致：

```json
{"id":"sample-0001","group_id":"document-01","text":"需要评分的文本或完整上下文。","scores":[4,3,5,2,4]}
{"id":"sample-0002","group_id":"document-02","text":"另一条需要评分的文本。","scores":[2,4,3,3,5]}
```

- `text`：非空字符串。若教师评分依赖问题、参考答案或上下文，请按固定模板放进这个字段。
- `scores`：**恰好五个 1～5 的整数**。训练内部会转换为 0～4，外部始终使用 1～5。
- `id`：可选的样本标识。
- `group_id`：可选的同源组标识，如文档、对话或生成模板来源；同组样本不会跨训练/验证/测试集。启用时每行都必须提供。

也支持五个独立分数列，例如 `fluency`、`relevance`、`logic`、`completeness`、`style`。这里的名称仅说明用法，应换成你的真实维度：

```bash
python prepare_data.py \
  --input raw/labels.csv \
  --output-dir data \
  --text-column content \
  --score-columns fluency relevance logic completeness style \
  --group-column document_id
```

CSV 的五个整数列可以是字符串 `"1"`～`"5"`，数组列可存 JSON 字符串。`3.5`、`true`、空值、缺维度和越界标签都会报错；浮点 `3.0` 也要求先明确转换为整数。支持 JSONL、CSV 和 Parquet 流式读取；`.json` 顶层数组会整体读入内存，百万级数据建议使用 JSONL 或 Parquet。

### 清洗、去重与切分

把原始文件放在输出目录之外，例如 `raw/labels.jsonl`：

```bash
python prepare_data.py \
  --input raw/labels.jsonl \
  --output-dir data \
  --validation-ratio 0.02 \
  --test-ratio 0.02 \
  --seed 42
```

输出 `data/train.jsonl`、`data/validation.jsonl`、`data/test.jsonl` 和 `data/report.json`。报告包含行数、移除重复数、每个集合的组数及各维分数分布。

处理规则：

1. 使用临时 SQLite 索引，避免把百万条原文装入 Python 列表。
2. 去重键只做 Unicode NFC、统一换行和裁掉首尾空白，保留内部空格和大小写。**这是精确规范化去重，不是语义近似去重。**
3. 同样文本的分数冲突时直接报错；同样文本出现在不同组也报错，要求先合并相关组或核对数据。
4. 有 `group_id` 时按组哈希切分；没有时按文本哈希切分。比例为近似值，不是严格分层采样；查看报告确认极端分数覆盖。
5. 已有结果默认受保护。确需替换本脚本生成的数据，可加 `--overwrite`。失败不会发布半成品，也不会覆盖原始输入。

若你已有经过检查的独立 train/validation/test 文件，可直接在配置中指定它们。`train.py` 会校验标签，但不会重新去重或重新安排你提供的集合。

## 4. 配置模型与训练

先修改 `configs/train.yaml`：

```yaml
model:
  name_or_path: jhu-clsp/mmBERT-small
  dimension_names: [dim_1, dim_2, dim_3, dim_4, dim_5]
  pooling: mean
  dropout: 0.1
  dimension_weights: [1, 1, 1, 1, 1]
  ordinal_weight: 0.0
  attn_implementation: sdpa

data:
  train_file: data/train.jsonl
  validation_file: data/validation.jsonl
  max_length: 512
  num_proc: 4

training:
  output_dir: outputs/mmbert-five-scores
  num_train_epochs: 2
  per_device_train_batch_size: 16
  gradient_accumulation_steps: 4
  learning_rate: 0.00002
  head_learning_rate: 0.0001
  precision: auto
```

完整配置已提供默认值，上面只是主要参数。未知参数名称会报错，减少拼写错误被静默忽略的情况。

### 单 GPU

```bash
# 首轮用训练集中的 10 万条试跑，使用单独输出目录。
python train.py --config configs/train.yaml \
  --max-train-samples 100000 --output-dir outputs/trial

# 正式训练全部数据。
python train.py --config configs/train.yaml
```

首次加载会从 Hugging Face 下载预训练骨干与 tokenizer。可将 `model.name_or_path` 改成本地已下载的 mmBERT 目录；可将 `revision: main` 换成具体 Hub commit 固定版本。实际解析到的版本信息会尽可能记录在 `environment.json`。

### 多 GPU：同机 DDP

```bash
torchrun --standalone --nproc_per_node=2 train.py --config configs/train.yaml
```

有效 batch size = 每卡 batch × 梯度累积步数 × GPU 数。默认单卡为 16 × 4 = 64，两卡为 128；如果想保持有效 batch 不变，调整梯度累积步数。

训练使用 Hugging Face Trainer/Accelerate 管理 DDP。多个进程先后访问同一分词缓存；最终模型和报告只由主进程写入。当前项目提供同机 DDP 用法，未验证多机配置。

### 保存与断点续训

训练期间按验证集 **五维平均 MAE 最小** 选择 checkpoint。`eval_steps` 默认 1000，`save_steps` 默认 1000，保存间隔必须是评估间隔的整数倍。评估仅使用 validation，测试集由独立 `evaluate.py` 处理。

```bash
# 自动找到同一 output_dir 中最新的 checkpoint-N。
python train.py --config configs/train.yaml --resume-from-checkpoint auto

# 或指定目录。
python train.py --config configs/train.yaml \
  --resume-from-checkpoint outputs/mmbert-five-scores/checkpoint-1000
```

续训时保持维度顺序、池化方式和损失定义一致。`checkpoint-N` 保存了优化器、调度器与 Trainer 状态，适合恢复中断；`final/` 是用于推理的导出结果。改变总训练步数后恢复调度器，只能作为有意识的新实验；smoke 中加一步仅检查恢复逻辑。

结果文件：

| 路径 | 内容 |
|---|---|
| `outputs/mmbert-five-scores/final/` | 最佳验证 checkpoint 的模型、tokenizer 与任务配置 |
| `checkpoint-N/` | 恢复训练所需状态 |
| `resolved_config.json` | 应用命令行覆盖后的配置 |
| `environment.json` | 依赖版本、GPU、精度、有效 batch、骨干来源 |
| `data_report.json` | 数据量、抽样 token 长度与截断率 |
| `train_results.json` / `validation_results.json` | 训练/验证结果 |
| `final/training_summary.json` | 最佳 checkpoint、完成步数、验证指标 |

如果总更新步数不足一次评估间隔，训练期间可能没有最佳 checkpoint；请为小试验设置较短 `eval_steps`/`save_steps`。CLI 的 `--max-steps` 小于默认评估间隔时会自动缩短到相同间隔。

### 显存与速度调整

- 先看 `data_report.json` 的样本 token 长度和截断比例，决定 256、512 或更长输入。长度包括特殊 token；支持长上下文不代表应默认使用上限。
- 显存不足时先降低 `per_device_train_batch_size` 与评估 batch；再增加累积步数维持有效 batch。激活显存成为瓶颈时启用 `gradient_checkpointing`，这会增加重计算。
- `group_by_length: true` 与动态 padding 已开启；分词通过 Datasets 缓存在磁盘。
- 默认使用 `sdpa`。`flash_attention_2` 与 `torch_compile` 是显式选项，请先检查环境并实测；默认不隐式触发 ModernBERT 内部 reference compilation。
- `precision: auto` 选择 BF16/FP16；需要定位数值问题时用 `fp32`。
- 大数据处理会占用临时磁盘与 Arrow 缓存空间，预留原文、SQLite、分词缓存及 checkpoints 所需容量。

## 5. 独立评估

```bash
python evaluate.py \
  --model outputs/mmbert-five-scores/final \
  --data data/test.jsonl \
  --output outputs/test_metrics.json \
  --device cuda --batch-size 32
```

报告包含总体与每维 MAE、accuracy、Macro-F1、QWK、误差至少 2 分的比例，以及五维全部正确率、每维 5×5 混淆矩阵、实际截断数。

- 分数由每维概率 `argmax + 1` 得到。
- Macro-F1 固定计算全部五档，未出现的档位贡献 0；例如测试集只含单一档位，即使预测全对也不等于五档 Macro-F1 为 1。
- QWK 使用固定的五档距离。若分布退化到 QWK 无法定义，报告中的该值写 0，并附 `qwk_defined: 0`；它不计入总体 QWK。查看 `qwk_defined_dimensions`，不要把缺失占位值当成实测结果。
- 对 GLM 标签的指标代表与教师的一致程度。另留人工复核集，可以检查是否符合真正的业务评分标准。

## 6. GPU 批量推理

输入是每行一个对象的 JSONL：

```json
{"id":"request-001","text":"需要评分的文本。"}
{"id":"request-002","text":"第二条文本。"}
```

```bash
python predict.py \
  --model outputs/mmbert-five-scores/final \
  --input raw/predict.jsonl \
  --output outputs/predictions.jsonl \
  --device cuda --batch-size 32 --include-probabilities
```

按批读取，不将整个输入文件装入内存。输出保留 `id`；原文需要 `--include-text` 才复制。输出已存在时默认报错，确定替换可加 `--overwrite`。

每条预测返回：

| 字段 | 含义 |
|---|---|
| `scores` | 按维度名称组织的五个整数 1～5 分 |
| `expected_scores` | 按每档概率加权的连续期望分，范围 1～5 |
| `max_probabilities` | 每维最大 softmax 概率；未做校准，不等同于真实正确率 |
| `probabilities` | 可选；每维五档概率，顺序固定为 1、2、3、4、5 |
| `input_tokens` | 截断前的 token 数，包含特殊 token |
| `used_tokens` | 实际输入模型的 token 数，不含 padding |
| `truncated` | 是否因超过长度限制而截断 |

默认使用训练时保存的 `max_length`，对超长输入右侧截断并明确标记。加 `--reject-truncation` 可要求超长输入直接报错。评估/推理可以用 `--max-length` 覆盖，但不允许超过模型上下文上限；改变训练时的长度策略后应重新验证质量。

也可直接在 Python 里调用：

```python
from five_scores.inference import ScorePredictor

predictor = ScorePredictor("outputs/mmbert-five-scores/final", device="cuda")
results = predictor.predict(
    ["文本一", "文本二"],
    batch_size=32,
    include_probabilities=True,
)
print(results[0]["scores"])
```

使用本项目的 `ModernBertForFiveScores` 或 `ScorePredictor` 重载模型。普通 `AutoModelForSequenceClassification` 不知道这里的五维输出协议。

## 7. HTTP 服务

```bash
MODEL_DIR=outputs/mmbert-five-scores/final \
DEVICE=cuda DTYPE=auto BATCH_SIZE=32 \
python serve.py
```

默认监听 `127.0.0.1:8000`：

```bash
curl http://127.0.0.1:8000/health

curl http://127.0.0.1:8000/predict \
  -H 'Content-Type: application/json' \
  -d '{"texts":["需要评分的文本"],"include_probabilities":true}'
```

返回对象包含 `dimensions` 与 `predictions`。`predictions` 的顺序与输入一致，每条结果的字段与批量预测相同。

| 环境变量 | 默认值 |
|---|---|
| `MODEL_DIR` | 必填，训练后的本地目录 |
| `DEVICE` | `cuda`，也可 `cuda:1` |
| `DTYPE` | `auto` |
| `BATCH_SIZE` | `32` |
| `MAX_LENGTH` | 模型保存的训练长度 |
| `ATTN_IMPLEMENTATION` | `sdpa` |
| `MAX_REQUEST_TEXTS` | 每次最多 128 条 |
| `MAX_TEXT_CHARS` | 每条最多 50,000 字符 |
| `MAX_TOTAL_CHARS` | 每次最多 200,000 字符 |
| `REJECT_TRUNCATION` | `false`，设为 `true` 强制拒绝截断 |
| `HOST` / `PORT` | `127.0.0.1` / `8000` |

默认单进程，每张 GPU 使用一个 worker。服务支持**请求内批量评分**，GPU 调用通过锁串行处理，避免多个工作线程同时占用模型显存；当前实现不合并不同 HTTP 请求形成动态批次。可以在服务前增加自己的流量调度层，并根据真实并发压测决定部署实例数。

## 8. 性能测试

```bash
python benchmark.py \
  --model outputs/mmbert-five-scores/final \
  --input raw/predict.jsonl \
  --device cuda --batch-size 32 \
  --warmup 5 --iterations 50 \
  --output outputs/benchmark.json
```

输入至少要有一个完整批次；试用 `examples/predict.jsonl` 时将 batch 设为 2。

报告包括 GPU/依赖版本、精度、真实 token 长度、截断数、批次请求 P50/P95、requests/s、texts/s、峰值 GPU 显存。

**计时口径**：重复执行输入文件前 B 条组成的同一个批次，包含参数校验、分词、模型计算与概率后处理，显式同步 CUDA；排除模型加载、文件 I/O、HTTP、外部排队与 JSON 序列化。一个 request 指一个批次；`texts/s` 才是每秒处理多少条文本。批次延迟不能除以 batch 后当成单请求延迟。实际接口尾延迟仍需用业务流量单独压测。

## 9. 损失函数与扩展点

默认 logits 为 `[B, 5, 5]`，labels 为 `[B, 5]` 的整数索引 0～4。每个维度内部五分类，五维 CE 按配置权重求加权平均。标签范围在 CPU 数据管道中检查，避免训练热路径每批反复同步 GPU。

`model.ordinal_weight` 默认为 0，可设小的正值比较有序辅助损失：把五分类分布转换成前四个累计概率，与真实等级的累计分布计算平方距离，再加到 CE。它不会增加推理输出头或额外前向计算，**也不是 CORAL 的实现**。是否有收益应由独立验证指标决定。

如果调整维度名称，必须保持数组标签的对应顺序，并重新保存模型配置。若改变维度数量或等级数，需要同时修改数据校验、输出头与指标实现；本项目有意固定为五维、每维五档。

## 10. 参考与实现依据

- [mmBERT-small 官方模型卡](https://huggingface.co/jhu-clsp/mmBERT-small)：骨干结构、预训练来源和语言覆盖。
- [Transformers 4.57.1 ModernBERT 文档](https://huggingface.co/docs/transformers/v4.57.1/en/model_doc/modernbert)：配置、SDPA 和模型接口。
- [ModernBERT 4.57.1 源码](https://github.com/huggingface/transformers/blob/v4.57.1/src/transformers/models/modernbert/modeling_modernbert.py)：权重键前缀、分类头初始化和池化相关实现。
- [Trainer 4.57.1 文档](https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/trainer)：训练、保存、评估及 processing_class 接口。
- [PyTorch 官方安装版本说明](https://pytorch.org/get-started/previous-versions/)：对应 CUDA wheel。

没有将模型卡中的检索或生成基准分数视为本任务效果。下载包提供训练代码与测试工具；业务质量由你的五维标准、数据与部署实测决定。
