# 交付验证记录

日期：2026-10-19。

## 已执行

- 所有交付 Python 文件的语法检查。
- 数据校验：非空文本、五个整数 1～5 标签、CSV 字符串整数、布尔值/小数/缺失值/越界拒绝。
- 数据准备实测：1,501 行输入，保留 1,500 行，移除 1 行规范化重复；500 个同源组在划分后不跨集合。
- 独立准备流程检查：201 行输入保留 200 行；反转输入顺序仍保持同一组的集合归属；冲突标签与冲突组标识均终止且保留原有成功输出。
- 重新执行准备流程结果一致；已有目录保护与异常清理路径经过检查。
- NumPy 指标：完美预测、反向评分、单一类别退化分布、固定五档距离的 QWK 等手工可验算情况。
- 关键 Transformers 4.57.1 API 与官方版本源码核对：ModernBERT 的 backbone 键前缀、SDPA、gradient checkpointing、get/set_input_embeddings、Trainer processing_class 和 loss scaling 等。
- 根据源码核对修正了自定义评分头的显式初始化；添加了对应 pytest 用例。

## 未在交付环境执行

- PyTorch 下的前向/反向、实际 Trainer 训练与断点续训。
- 实际权重保存与重新加载后的数值一致性。
- Datasets/Arrow/实际 tokenizer 联合流程。
- FastAPI/TestClient 测试。
- 真正的 mmBERT-small 预训练权重加载及业务微调。
- GPU 性能测试、多 GPU DDP 测试和精度对比。

原因：交付环境没有 PyTorch、Transformers、Datasets 或 CUDA。下载 PyTorch 到隔离环境的网络访问需要自动审批；两次审批都因审批服务所选模型容量不足而未能完成，动作未执行。返回信息明确说明这是审批服务故障，不是认定该下载不安全。没有改用其他方式绕过审批。

## 在你的机器上复现

安装 README 中的依赖后执行：

```bash
python scripts/smoke_test.py --device cpu
python -m pip install -r requirements-dev.txt
python -m pytest -q
```

有 GPU 后执行：

```bash
python scripts/smoke_test.py --device cuda --work-dir outputs/smoke-gpu
```

smoke 使用随机的小型 ModernBERT 和本地 tokenizer，验证训练、保存、预测、评估、测速及恢复的衔接。它不需要下载任何模型，不会使用你的正式标签，也不证明真实业务评分效果。失败会保留日志目录，返回非零退出码；成功会打印阶段报告。
