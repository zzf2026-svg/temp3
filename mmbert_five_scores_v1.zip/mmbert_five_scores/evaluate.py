#!/usr/bin/env python3
"""Evaluate a saved five-score checkpoint on a separate labeled data file."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import tempfile

import numpy as np

from five_scores.data import load_labeled_dataset
from five_scores.inference import ScorePredictor
from five_scores.metrics import score_metrics


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", required=True, help="Local trained checkpoint, normally outputs/.../final")
    parser.add_argument("--data", required=True, help="Labeled JSONL, CSV, JSON array or Parquet")
    parser.add_argument("--output", required=True, help="Write evaluation report as JSON")
    parser.add_argument("--text-column", default="text")
    parser.add_argument("--scores-column", default="scores")
    parser.add_argument("--score-columns", nargs=5, metavar=("D1", "D2", "D3", "D4", "D5"))
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--precision", choices=["auto", "bf16", "fp16", "fp32"], default="auto")
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--max-length", type=int)
    parser.add_argument("--max-text-chars", type=int, default=100_000)
    parser.add_argument("--attn-implementation", default="sdpa", choices=["sdpa", "eager", "flash_attention_2"])
    parser.add_argument("--reject-truncation", action="store_true")
    parser.add_argument("--overwrite", action="store_true")
    options = parser.parse_args()
    if options.batch_size < 1:
        parser.error("--batch-size must be positive")
    destination = Path(options.output).expanduser().resolve()
    source = Path(options.data).expanduser().resolve()
    if destination == source:
        parser.error("--output must differ from --data")
    if destination.exists() and not options.overwrite:
        parser.error("--output exists; use a new path or --overwrite")
    raw = load_labeled_dataset(
        source, text_column=options.text_column, scores_column=options.scores_column,
        score_columns=options.score_columns,
    )
    predictor = ScorePredictor(
        options.model, device=options.device, precision=options.precision,
        max_length=options.max_length, attn_implementation=options.attn_implementation,
        max_text_chars=options.max_text_chars,
    )
    names = predictor.dimension_names
    # Ten bytes per row for predictions+targets; no full text or logits copy.
    # score_metrics temporarily promotes the small index arrays to int64.
    labels = np.empty((len(raw), 5), dtype=np.int8)
    predictions = np.empty((len(raw), 5), dtype=np.int8)
    truncated = 0
    for start in range(0, len(raw), options.batch_size):
        end = min(start + options.batch_size, len(raw))
        batch = raw[start:end]
        results = predictor.predict(
            batch["text"], batch_size=options.batch_size,
            reject_truncation=options.reject_truncation,
        )
        labels[start:end] = np.asarray(batch["scores"], dtype=np.int8) - 1
        predictions[start:end] = np.asarray(
            [[result["scores"][name] for name in names] for result in results], dtype=np.int8
        ) - 1
        truncated += sum(int(result["truncated"]) for result in results)

    confusion = {
        name: np.bincount(5 * labels[:, i] + predictions[:, i], minlength=25).reshape(5, 5).tolist()
        for i, name in enumerate(names)
    }
    report = {
        "model": str(predictor.model_dir),
        "data": str(source),
        "examples": len(raw),
        "dimensions": names,
        "max_length": predictor.max_length,
        "device": str(predictor.device),
        "precision": predictor.precision,
        "truncated_examples": truncated,
        "truncation_rate": truncated / len(raw),
        "metrics": score_metrics(labels, predictions, names),
        "confusion_matrix_axes": "rows=true score 1..5; columns=predicted score 1..5",
        "confusion_matrices": confusion,
        "metric_notes": [
            "Predictions are per-dimension probability argmax, converted to integer scores 1..5.",
            "macro_f1 includes all five score classes, even when a class is absent.",
            "QWK with qwk_defined=0 is a missing-value placeholder and is excluded from aggregate QWK.",
            "Agreement with teacher labels is not an independent measurement of human scoring quality.",
        ],
    }
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=destination.parent, suffix=".tmp", delete=False) as handle:
            temporary = Path(handle.name)
            json.dump(report, handle, ensure_ascii=False, indent=2, allow_nan=False)
            handle.write("\n")
        if destination.exists() and not options.overwrite:
            raise FileExistsError(f"Output appeared during evaluation: {destination}")
        os.replace(temporary, destination)
        temporary = None
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    print(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
