"""Small, strict YAML configuration loader (paths are relative to the CWD)."""

from __future__ import annotations

from copy import deepcopy
from pathlib import Path

import yaml


DEFAULTS = {
    "model": {
        "name_or_path": "jhu-clsp/mmBERT-small",
        "revision": "main",
        "dimension_names": ["dim_1", "dim_2", "dim_3", "dim_4", "dim_5"],
        "pooling": "mean",
        "dropout": 0.1,
        "dimension_weights": [1, 1, 1, 1, 1],
        "ordinal_weight": 0.0,
        "attn_implementation": "sdpa",
    },
    "data": {
        "train_file": "data/train.jsonl",
        "validation_file": "data/validation.jsonl",
        "text_column": "text",
        "scores_column": "scores",
        "score_columns": None,
        "max_length": 512,
        "num_proc": 4,
        "max_train_samples": None,
        "max_eval_samples": None,
    },
    "training": {
        "output_dir": "outputs/mmbert-five-scores",
        "seed": 42,
        "num_train_epochs": 2.0,
        "max_steps": -1,
        "per_device_train_batch_size": 16,
        "per_device_eval_batch_size": 32,
        "gradient_accumulation_steps": 4,
        "learning_rate": 2e-5,
        "head_learning_rate": 1e-4,
        "weight_decay": 0.01,
        "warmup_ratio": 0.03,
        "lr_scheduler_type": "cosine",
        "precision": "auto",
        "use_cpu": False,
        "gradient_checkpointing": False,
        "eval_steps": 1000,
        "save_steps": 1000,
        "logging_steps": 50,
        "save_total_limit": 2,
        "early_stopping_patience": 3,
        "dataloader_num_workers": 4,
        "group_by_length": True,
        "max_grad_norm": 1.0,
        "tf32": True,
        "torch_compile": False,
        "resume_from_checkpoint": None,
    },
}


def load_config(path: str | Path) -> dict:
    with Path(path).open(encoding="utf-8") as handle:
        supplied = yaml.safe_load(handle) or {}
    if not isinstance(supplied, dict):
        raise ValueError("YAML root must be a mapping")
    result = deepcopy(DEFAULTS)
    for section, values in supplied.items():
        if section not in result:
            raise ValueError(f"Unknown config section: {section}")
        if not isinstance(values, dict):
            raise ValueError(f"Config section {section} must be a mapping")
        extra = set(values) - set(result[section])
        if extra:
            raise ValueError(f"Unknown {section} options: {sorted(extra)}")
        result[section].update(values)
    return result
