"""Shared, local-checkpoint inference for batch jobs and the HTTP service."""

from __future__ import annotations

import threading
from pathlib import Path
from typing import Any

import torch
from transformers import AutoConfig, AutoTokenizer

from .modeling import ModernBertForFiveScores


def resolve_device_precision(device: str, precision: str) -> tuple[torch.device, torch.dtype, str]:
    """Choose GPU BF16 when supported, otherwise FP16; keep CPU inference FP32."""
    target = torch.device(device)
    if target.type not in {"cpu", "cuda"}:
        raise ValueError("device must be 'cpu', 'cuda', or 'cuda:N'")
    if precision not in {"auto", "bf16", "fp16", "fp32"}:
        raise ValueError("precision must be auto, bf16, fp16, or fp32")
    if target.type == "cpu":
        if precision not in {"auto", "fp32"}:
            raise ValueError("CPU inference uses fp32; select --precision auto or fp32")
        return target, torch.float32, "fp32"
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is unavailable. Install a CUDA-enabled PyTorch build or select --device cpu.")
    index = target.index if target.index is not None else torch.cuda.current_device()
    if index < 0 or index >= torch.cuda.device_count():
        raise ValueError(f"CUDA device {index} does not exist")
    target = torch.device("cuda", index)
    with torch.cuda.device(target):
        # Exclude emulation on older GPUs when choosing the fast default.
        bf16_supported = torch.cuda.is_bf16_supported(including_emulation=False)
    chosen = ("bf16" if bf16_supported else "fp16") if precision == "auto" else precision
    if chosen == "bf16" and not bf16_supported:
        raise ValueError("This CUDA device does not support BF16; select auto or fp16")
    dtype = {"bf16": torch.bfloat16, "fp16": torch.float16, "fp32": torch.float32}[chosen]
    return target, dtype, chosen


class ScorePredictor:
    """Load a saved five-score checkpoint and predict all dimensions together.

    Results preserve input order. ``input_tokens`` counts the original tokens,
    including special tokens; ``used_tokens`` excludes padding. Exact truncation
    reporting requires tokenizing the original input. Overlength texts alone are
    tokenized a second time with the tokenizer's own truncation/post-processing,
    preserving special tokens correctly for generic fast tokenizers.

    A lock serializes calls to this instance, including tokenizer operations.
    This is useful for a single GPU shared by the HTTP endpoint's thread pool.
    """

    def __init__(
        self,
        model_dir: str | Path,
        device: str = "cuda",
        precision: str = "auto",
        max_length: int | None = None,
        attn_implementation: str = "sdpa",
        compile_model: bool = False,
        max_text_chars: int = 100_000,
    ) -> None:
        self.model_dir = Path(model_dir).expanduser().resolve()
        if not self.model_dir.is_dir():
            raise ValueError(f"A local trained checkpoint directory is required: {self.model_dir}")
        self.device, self.dtype, self.precision = resolve_device_precision(device, precision)
        if type(max_text_chars) is not int or max_text_chars < 1:
            raise ValueError("max_text_chars must be a positive integer")
        self.max_text_chars = max_text_chars
        self._lock = threading.Lock()

        config = AutoConfig.from_pretrained(self.model_dir, local_files_only=True, trust_remote_code=False)
        names = getattr(config, "score_dim_names", None)
        required = ("score_dim_names", "score_pooling", "score_max_length", "score_model_version")
        if any(not hasattr(config, name) for name in required):
            raise ValueError("This is not a saved five-score checkpoint. Run train.py and use its final/ directory.")
        if (
            not isinstance(names, list)
            or len(names) != 5
            or any(not isinstance(name, str) or not name.strip() for name in names)
            or len(set(names)) != 5
        ):
            raise ValueError("Checkpoint score_dim_names must contain five distinct, nonempty strings")
        if config.score_model_version != 1:
            raise ValueError(f"Unsupported score_model_version: {config.score_model_version}")
        if config.score_pooling not in {"mean", "cls"}:
            raise ValueError("Checkpoint score_pooling must be mean or cls")
        trained_length = config.score_max_length
        if type(trained_length) is not int or trained_length < 1:
            raise ValueError("Checkpoint score_max_length must be a positive integer")
        self.dimension_names = list(names)
        self.max_length = trained_length if max_length is None else max_length
        context_length = getattr(config, "max_position_embeddings", None)
        if type(self.max_length) is not int or self.max_length < 1:
            raise ValueError("max_length must be a positive integer")
        if not isinstance(context_length, int) or self.max_length > context_length:
            raise ValueError(f"max_length={self.max_length} exceeds the model context length {context_length}")
        self.config = config
        self.attn_implementation = attn_implementation
        self.compiled = bool(compile_model)

        self.tokenizer = AutoTokenizer.from_pretrained(
            self.model_dir, local_files_only=True, trust_remote_code=False, padding_side="right"
        )
        self.tokenizer.padding_side = "right"
        self.tokenizer.truncation_side = "right"
        if self.tokenizer.pad_token_id is None:
            raise ValueError("Checkpoint tokenizer must have a pad token")
        if self.max_length <= self.tokenizer.num_special_tokens_to_add(pair=False):
            raise ValueError("max_length must leave room for text in addition to special tokens")

        model, loading_info = ModernBertForFiveScores.from_pretrained(
            self.model_dir,
            config=config,
            local_files_only=True,
            attn_implementation=attn_implementation,
            torch_dtype=self.dtype,
            output_loading_info=True,
        )
        # Inference must never silently use a newly initialized scoring head.
        for key in ("missing_keys", "unexpected_keys", "mismatched_keys", "error_msgs"):
            if loading_info.get(key):
                raise ValueError(f"Incomplete or incompatible five-score checkpoint ({key}): {loading_info[key]}")
        model.to(self.device).eval()
        if compile_model:
            model = torch.compile(model, dynamic=True)
        self.model = model

    def _tokenize(self, texts: list[str], reject_truncation: bool) -> tuple[Any, list[int], list[int]]:
        encoded = self.tokenizer(
            texts, padding=False, truncation=False, return_attention_mask=True,
            return_token_type_ids=False, verbose=False,
        )
        original_lengths = [len(ids) for ids in encoded["input_ids"]]
        long_indices = [i for i, length in enumerate(original_lengths) if length > self.max_length]
        if long_indices and reject_truncation:
            i = long_indices[0]
            raise ValueError(
                f"Text at batch index {i} has {original_lengths[i]} tokens, exceeding max_length={self.max_length}. "
                "Shorten the input or explicitly allow truncation."
            )
        if long_indices:
            shortened = self.tokenizer(
                [texts[i] for i in long_indices], padding=False, truncation=True,
                max_length=self.max_length, return_attention_mask=True,
                return_token_type_ids=False, verbose=False,
            )
            for j, i in enumerate(long_indices):
                encoded["input_ids"][i] = shortened["input_ids"][j]
                encoded["attention_mask"][i] = shortened["attention_mask"][j]
        used_lengths = [len(ids) for ids in encoded["input_ids"]]
        # An aligned training limit keeps alignment padding inside model context.
        multiple = 8 if self.device.type == "cuda" and self.max_length % 8 == 0 else None
        batch = self.tokenizer.pad(
            {"input_ids": encoded["input_ids"], "attention_mask": encoded["attention_mask"]},
            padding=True, pad_to_multiple_of=multiple, return_tensors="pt",
        )
        return batch, original_lengths, used_lengths

    @torch.inference_mode()
    def predict(
        self,
        texts: list[str],
        batch_size: int = 32,
        include_probabilities: bool = False,
        reject_truncation: bool = False,
    ) -> list[dict[str, Any]]:
        if not isinstance(texts, list):
            raise ValueError("texts must be a list of strings")
        if type(batch_size) is not int or batch_size < 1:
            raise ValueError("batch_size must be a positive integer")
        if not texts:
            return []
        for i, text in enumerate(texts):
            if not isinstance(text, str) or not text.strip():
                raise ValueError(f"Text at index {i} must be a nonempty string")
            if len(text) > self.max_text_chars:
                raise ValueError(f"Text at index {i} exceeds max_text_chars={self.max_text_chars}")

        results: list[dict[str, Any]] = []
        with self._lock:
            for start in range(0, len(texts), batch_size):
                current = texts[start : start + batch_size]
                batch, original_lengths, used_lengths = self._tokenize(current, reject_truncation)
                batch = {name: values.to(self.device) for name, values in batch.items()}
                logits = self.model(**batch).logits
                if tuple(logits.shape) != (len(current), 5, 5):
                    raise RuntimeError(f"Expected [batch, 5, 5] logits; got {tuple(logits.shape)}")
                # Transfer a single, small tensor; all probability calculations
                # and JSON conversion then happen in FP32 on CPU.
                probabilities = torch.softmax(logits.float(), dim=-1).cpu()
                if not torch.isfinite(probabilities).all().item():
                    raise RuntimeError("Model produced non-finite probabilities; try --precision fp32")
                scores = probabilities.argmax(dim=-1) + 1
                expected = (probabilities * torch.arange(1, 6, dtype=torch.float32)).sum(dim=-1).clamp_(1, 5)
                maxima = probabilities.max(dim=-1).values
                for i in range(len(current)):
                    result: dict[str, Any] = {
                        "scores": dict(zip(self.dimension_names, scores[i].tolist())),
                        "expected_scores": dict(zip(self.dimension_names, expected[i].tolist())),
                        "max_probabilities": dict(zip(self.dimension_names, maxima[i].tolist())),
                        "input_tokens": original_lengths[i],
                        "used_tokens": used_lengths[i],
                        "truncated": original_lengths[i] > self.max_length,
                    }
                    if include_probabilities:
                        result["probabilities"] = dict(zip(self.dimension_names, probabilities[i].tolist()))
                    results.append(result)
        return results
