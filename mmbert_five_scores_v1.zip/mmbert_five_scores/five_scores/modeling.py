"""A checkpoint-compatible ModernBERT encoder with five five-class heads.

The backbone attribute is named ``model`` to match ModernBertForMaskedLM's
checkpoint keys. No vocabulary-sized MLM head is constructed or evaluated.
Labels inside the model are int64 class indices in [0, 4]. External ratings
are [1, 5]; the data and inference modules perform that conversion.
"""

from __future__ import annotations

import math
from typing import Optional

import torch
from torch import nn
from torch.nn import functional as F
from transformers import ModernBertConfig, ModernBertModel
from transformers.modeling_outputs import SequenceClassifierOutput
from transformers.models.modernbert.modeling_modernbert import ModernBertPreTrainedModel


NUM_DIMENSIONS = 5
NUM_CLASSES = 5


def validate_score_config(config: ModernBertConfig) -> None:
    """Validate and persist all task metadata alongside the HF configuration."""
    names = getattr(config, "score_dim_names", [f"dim_{i + 1}" for i in range(5)])
    if (not isinstance(names, list) or len(names) != 5
            or any(not isinstance(n, str) or not n.strip() for n in names)
            or len(set(names)) != 5):
        raise ValueError("score_dim_names must contain five distinct non-empty strings")
    config.score_dim_names = names
    config.score_pooling = getattr(config, "score_pooling", "mean")
    if config.score_pooling not in {"mean", "cls"}:
        raise ValueError("score_pooling must be 'mean' or 'cls'")
    config.score_dropout = float(getattr(config, "score_dropout", 0.1))
    if not 0 <= config.score_dropout < 1:
        raise ValueError("score_dropout must be in [0, 1)")
    config.score_ordinal_weight = float(getattr(config, "score_ordinal_weight", 0.0))
    if not math.isfinite(config.score_ordinal_weight) or config.score_ordinal_weight < 0:
        raise ValueError("score_ordinal_weight must be finite and non-negative")
    weights = getattr(config, "score_dim_weights", [1.0] * 5)
    if (not isinstance(weights, (list, tuple)) or len(weights) != 5
            or any(not math.isfinite(float(w)) or float(w) <= 0 for w in weights)):
        raise ValueError("score_dim_weights must contain five finite positive values")
    config.score_dim_weights = [float(w) for w in weights]
    config.score_max_length = getattr(config, "score_max_length", 512)
    if (isinstance(config.score_max_length, bool)
            or not isinstance(config.score_max_length, int)
            or not 2 <= config.score_max_length <= config.max_position_embeddings):
        raise ValueError("score_max_length must be an integer within the backbone context window")
    config.score_model_version = 1
    config.score_num_dimensions = NUM_DIMENSIONS
    config.score_num_classes = NUM_CLASSES
    # These are 5 independent distributions, not one 25-way softmax.
    config.num_labels = NUM_DIMENSIONS * NUM_CLASSES


class ModernBertForFiveScores(ModernBertPreTrainedModel):
    """Shared ModernBERT + Linear(hidden, 25); output shape [batch, 5, 5]."""

    config_class = ModernBertConfig
    # Our loss is a mean over samples and dimensions. Trainer must perform its
    # normal gradient-accumulation scaling, not assume we consume item counts.
    accepts_loss_kwargs = False

    def __init__(self, config: ModernBertConfig):
        validate_score_config(config)
        super().__init__(config)
        self.model = ModernBertModel(config)
        self.dropout = nn.Dropout(config.score_dropout)
        self.classifier = nn.Linear(config.hidden_size, NUM_DIMENSIONS * NUM_CLASSES)
        self.register_buffer(
            "dimension_weights",
            torch.tensor(config.score_dim_weights, dtype=torch.float32),
            persistent=False,
        )
        self.post_init()

    def _init_weights(self, module):
        super()._init_weights(module)
        # ModernBERT 4.57 initializes classifier weights only for its built-in
        # task classes. Explicitly initialize our new head as well, including
        # from_pretrained's missing-parameter/meta-device initialization path.
        if module is getattr(self, "classifier", None):
            std = self.config.initializer_range
            cutoff = getattr(self.config, "initializer_cutoff_factor", 2.0)
            nn.init.trunc_normal_(module.weight, mean=0.0, std=std, a=-cutoff * std, b=cutoff * std)
            if module.bias is not None:
                nn.init.zeros_(module.bias)

    def get_input_embeddings(self):
        return self.model.get_input_embeddings()

    def set_input_embeddings(self, value):
        self.model.set_input_embeddings(value)

    def forward(
        self,
        input_ids: Optional[torch.Tensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.Tensor] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
    ):
        return_dict = self.config.use_return_dict if return_dict is None else return_dict
        if input_ids is None or input_ids.ndim != 2:
            raise ValueError("input_ids must have shape [batch, sequence_length]")
        if attention_mask is None:
            attention_mask = input_ids.ne(self.config.pad_token_id).long()
        if attention_mask.shape != input_ids.shape:
            raise ValueError("attention_mask must match input_ids")

        output = self.model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=True,
        )
        hidden = output.last_hidden_state
        if self.config.score_pooling == "cls":
            # All supplied tokenizers/collators use right padding.
            pooled = hidden[:, 0]
        else:
            mask = attention_mask.unsqueeze(-1).to(torch.float32)
            # Accumulate in FP32 even under BF16/FP16 autocast.
            pooled = (hidden.float() * mask).sum(1) / mask.sum(1).clamp_min(1)
            pooled = pooled.to(hidden.dtype)

        logits = self.classifier(self.dropout(pooled)).reshape(-1, 5, 5)
        loss = None
        if labels is not None:
            if labels.shape != logits.shape[:2]:
                raise ValueError("labels must have shape [batch, 5]")
            if labels.dtype != torch.long:
                raise ValueError("labels must be torch.int64 class indices in [0, 4]")
            # The CPU data pipeline validates every target. Avoid GPU .item()
            # synchronizations on the hot path; CE also checks index validity.
            if labels.device.type == "cpu" and ((labels < 0).any() or (labels > 4).any()):
                raise ValueError("labels must contain class indices in [0, 4]")
            per_dimension = F.cross_entropy(
                logits.float().reshape(-1, 5), labels.reshape(-1), reduction="none"
            ).reshape(-1, 5)
            if self.config.score_ordinal_weight:
                # Optional squared cumulative-distribution distance. The five
                # softmax probabilities stay valid/ordered by construction.
                probs_cdf = logits.float().softmax(-1).cumsum(-1)[..., :-1]
                target_cdf = F.one_hot(labels, 5).float().cumsum(-1)[..., :-1]
                ordinal = (probs_cdf - target_cdf).square().mean(-1)
                per_dimension = per_dimension + self.config.score_ordinal_weight * ordinal
            weights = self.dimension_weights.float()
            loss = (per_dimension * weights).sum(-1).div(weights.sum()).mean()

        if not return_dict:
            result = (logits,)
            if output_hidden_states:
                result += (output.hidden_states,)
            if output_attentions:
                result += (output.attentions,)
            return ((loss,) + result) if loss is not None else result
        return SequenceClassifierOutput(
            loss=loss,
            logits=logits,
            hidden_states=output.hidden_states,
            attentions=output.attentions,
        )
