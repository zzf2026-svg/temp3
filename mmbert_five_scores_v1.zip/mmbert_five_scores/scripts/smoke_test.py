#!/usr/bin/env python3
"""Run the complete pipeline on a local random tiny ModernBERT, without downloads.

This is a functional test, not a model-quality or production-speed benchmark.
It trains for two optimizer steps, saves/reloads, predicts, evaluates, benchmarks
and resumes a checkpoint for one more step. The changed resume step budget is
only a loading/continuation check, not a recommended learning-rate schedule.

Examples:
    python scripts/smoke_test.py
    python scripts/smoke_test.py --device cuda --work-dir /tmp/mmbert-smoke-gpu

Temporary outputs are cleaned after success. An explicit --work-dir preserves
all outputs, and a failed run always preserves its work directory and stage logs.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time


PROJECT = Path(__file__).resolve().parents[1]
DIMENSIONS = [f"dimension_{i}" for i in range(1, 6)]


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def read_json(path: Path):
    require(path.is_file(), f"Expected output is missing: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def check_checkpoint(path: Path, expected_step: int) -> None:
    config = read_json(path / "config.json")
    require(config.get("score_dim_names") == DIMENSIONS, "Saved dimension order does not match the training configuration")
    require(config.get("score_model_version") == 1, "Scoring model metadata was not saved")
    require(config.get("score_max_length") == 64, "The saved training length is incorrect")
    require((path / "model.safetensors").is_file(), "Safe model weights were not saved")
    require((path / "tokenizer.json").is_file(), "The tokenizer was not saved for local reload")
    summary = read_json(path / "training_summary.json")
    require(summary.get("global_step") == expected_step, f"Expected global_step={expected_step}, got {summary.get('global_step')}")


def check_predictions(path: Path) -> int:
    require(path.is_file(), f"Prediction output is missing: {path}")
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    require(len(rows) == 3, f"Expected 3 predictions, got {len(rows)}")
    require([row.get("id") for row in rows] == ["0", "1", "2"], "Prediction IDs or ordering changed")
    for row in rows:
        require(set(row.get("scores", {})) == set(DIMENSIONS), "Prediction does not contain all five dimensions")
        for name in DIMENSIONS:
            score = row["scores"][name]
            require(type(score) is int and 1 <= score <= 5, "External scores must be integers in 1..5")
            probs = row.get("probabilities", {}).get(name, [])
            require(len(probs) == 5, "Each dimension must have five class probabilities")
            require(all(math.isfinite(p) and 0 <= p <= 1 for p in probs), "Invalid probability values")
            require(math.isclose(sum(probs), 1.0, abs_tol=1e-5), "Class probabilities do not sum to one")
    return len(rows)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
    parser.add_argument("--work-dir", type=Path, help="New or empty directory; keep all artifacts here")
    parser.add_argument("--stage-timeout", type=int, default=600, help="Maximum seconds for each subprocess")
    args = parser.parse_args()
    if args.stage_timeout < 1:
        parser.error("--stage-timeout must be positive")
    keep_outputs = args.work_dir is not None
    if keep_outputs:
        work = args.work_dir.expanduser().resolve()
        if work.exists() and (not work.is_dir() or any(work.iterdir())):
            parser.error("--work-dir must be new or empty; existing files are never overwritten")
        work.mkdir(parents=True, exist_ok=True)
    else:
        work = Path(tempfile.mkdtemp(prefix="mmbert-five-scores-smoke-"))
    logs = work / "logs"
    logs.mkdir()
    env = os.environ.copy()
    env.update({"HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1", "TOKENIZERS_PARALLELISM": "false"})
    env.setdefault("OMP_NUM_THREADS", "1")
    env.setdefault("MKL_NUM_THREADS", "1")
    env["PYTHONPATH"] = str(PROJECT) + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
    stages = []

    def run(stage: str, script: str, *arguments: str) -> None:
        command = [sys.executable, str(PROJECT / script), *map(str, arguments)]
        log = logs / f"{len(stages) + 1:02d}_{stage}.log"
        print(json.dumps({"stage": stage, "status": "running"}), flush=True)
        started = time.perf_counter()
        try:
            result = subprocess.run(
                command, cwd=PROJECT, env=env, capture_output=True,
                text=True, encoding="utf-8", errors="replace",
                check=True, timeout=args.stage_timeout,
            )
        except subprocess.CalledProcessError as exc:
            log.write_text(
                json.dumps(command, ensure_ascii=False) + "\n\nSTDOUT\n" + (exc.stdout or "")
                + "\nSTDERR\n" + (exc.stderr or ""), encoding="utf-8"
            )
            raise RuntimeError(f"Stage {stage} exited with status {exc.returncode}; inspect {log}") from exc
        except subprocess.TimeoutExpired as exc:
            log.write_text(f"Command: {json.dumps(command)}\nExceeded {args.stage_timeout} seconds\n", encoding="utf-8")
            raise RuntimeError(f"Stage {stage} timed out; inspect {log}") from exc
        log.write_text(
            json.dumps(command, ensure_ascii=False) + "\n\nSTDOUT\n" + result.stdout
            + "\nSTDERR\n" + result.stderr, encoding="utf-8"
        )
        stages.append({"stage": stage, "status": "passed", "seconds": round(time.perf_counter() - started, 3)})

    try:
        fixture = work / "fixture"
        output = work / "training"
        config_path = work / "smoke.yaml"
        run("fixture", "scripts/create_tiny_fixture.py", "--output", fixture, "--train-rows", "20")
        configuration = {
            "model": {
                "name_or_path": str(fixture / "model"), "dimension_names": DIMENSIONS,
                "pooling": "mean", "dropout": 0.0, "attn_implementation": "sdpa",
            },
            "data": {
                "train_file": str(fixture / "train.jsonl"),
                "validation_file": str(fixture / "validation.jsonl"),
                "max_length": 64, "num_proc": 1,
            },
            "training": {
                "output_dir": str(output), "seed": 17, "max_steps": 2,
                "per_device_train_batch_size": 2, "per_device_eval_batch_size": 2,
                "gradient_accumulation_steps": 2, "eval_steps": 1, "save_steps": 1,
                "logging_steps": 1, "save_total_limit": 2, "early_stopping_patience": 0,
                "dataloader_num_workers": 0, "group_by_length": True,
                "precision": "fp32" if args.device == "cpu" else "auto",
                "use_cpu": args.device == "cpu", "tf32": False,
            },
        }
        # JSON is a strict subset of YAML and avoids another import in this
        # orchestrator; train.py still exercises the actual YAML config loader.
        config_path.write_text(json.dumps(configuration, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        run("train", "train.py", "--config", config_path)
        final = output / "final"
        check_checkpoint(final, expected_step=2)
        require(read_json(output / "checkpoint-2" / "trainer_state.json").get("global_step") == 2,
                "Trainer checkpoint-2 was not saved for resume")
        predictions = work / "predictions.jsonl"
        common = ("--model", final, "--device", args.device, "--batch-size", "2")
        run("predict", "predict.py", *common, "--input", fixture / "predict.jsonl",
            "--output", predictions, "--include-probabilities")
        count = check_predictions(predictions)
        metrics_path = work / "metrics.json"
        run("evaluate", "evaluate.py", *common, "--data", fixture / "test.jsonl", "--output", metrics_path)
        evaluation = read_json(metrics_path)
        metrics = evaluation.get("metrics", evaluation)
        require("mae" in metrics and math.isfinite(metrics["mae"]), "Evaluation did not return a finite MAE")
        require(0 <= metrics["mae"] <= 4, "Evaluation MAE is outside the five-score range")
        benchmark_path = work / "benchmark.json"
        run("benchmark", "benchmark.py", *common, "--input", fixture / "predict.jsonl",
            "--warmup", "1", "--iterations", "2", "--output", benchmark_path)
        benchmark = read_json(benchmark_path)
        require(benchmark.get("timed_texts") == 4, "Benchmark did not time two batches of two texts")
        require(math.isfinite(benchmark.get("texts_per_second", 0)) and benchmark["texts_per_second"] > 0,
                "Benchmark did not return a valid throughput value")
        run("resume", "train.py", "--config", config_path, "--max-steps", "3",
            "--resume-from-checkpoint", output / "checkpoint-2")
        check_checkpoint(final, expected_step=3)
        resumed_predictions = work / "resumed_predictions.jsonl"
        run("predict_resumed", "predict.py", *common, "--input", fixture / "predict.jsonl",
            "--output", resumed_predictions, "--include-probabilities")
        check_predictions(resumed_predictions)
        report = {
            "status": "passed", "network": "disabled", "device": args.device,
            "model": "local random tiny ModernBERT; no pretrained quality assessment",
            "stages": stages, "prediction_rows": count, "resume_global_step": 3,
            "work_directory": str(work) if keep_outputs else None,
            "outputs_retained": keep_outputs,
            "note": "Synthetic metrics and timings validate mechanics only. Resume uses a changed step budget only to test checkpoint continuation.",
        }
        (work / "smoke_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        if not keep_outputs:
            shutil.rmtree(work)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0
    except Exception as exc:
        report = {"status": "failed", "error": str(exc), "completed_stages": stages, "work_directory": str(work)}
        (work / "smoke_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(report, ensure_ascii=False, indent=2), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
