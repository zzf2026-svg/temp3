"""Boundary checks for label semantics and fixed-five-bin ordinal metrics."""

from __future__ import annotations

import json

import numpy as np
import pytest
from transformers import AutoTokenizer

from five_scores.data import canonical_record, get_tokenized_dataset, load_labeled_dataset, parse_scores
from five_scores.metrics import score_metrics


@pytest.mark.parametrize("scores", [
    [True, 2, 3, 4, 5],
    [1.0, 2, 3, 4, 5],
    [0, 2, 3, 4, 5],
    [1, 2, 3, 4, 6],
    [1, 2, 3, 4],
    [1, 2, 3, 4, None],
])
def test_rejects_invalid_raw_scores(scores):
    with pytest.raises(ValueError):
        parse_scores(scores)


def test_accepts_json_and_five_csv_integer_columns():
    assert parse_scores("[1,2,3,4,5]") == [1, 2, 3, 4, 5]
    row = {"content": " 文本保留空格 ", **{f"s{i}": str(i) for i in range(1, 6)}}
    parsed = canonical_record(row, text_column="content", score_columns=[f"s{i}" for i in range(1, 6)])
    assert parsed == {"text": " 文本保留空格 ", "scores": [1, 2, 3, 4, 5]}


@pytest.mark.parametrize("text", [None, "", "   ", 123])
def test_rejects_missing_or_blank_text(text):
    with pytest.raises(ValueError):
        canonical_record({"text": text, "scores": [1, 2, 3, 4, 5]})


def test_arrow_tokenization_converts_labels_once_without_padding(tmp_path, tiny_pretrained):
    source = tmp_path / "valid.jsonl"
    rows = [
        {"text": "hello", "scores": [1, 2, 3, 4, 5]},
        {"text": "这 是 一个 清晰 回答", "scores": [5, 4, 3, 2, 1]},
    ]
    source.write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows), encoding="utf-8")
    raw = load_labeled_dataset(source)
    tokenizer = AutoTokenizer.from_pretrained(tiny_pretrained / "model", local_files_only=True)
    tokenized = get_tokenized_dataset(raw, tokenizer, max_length=32)
    assert tokenized[0]["labels"] == [0, 1, 2, 3, 4]
    assert tokenized[1]["labels"] == [4, 3, 2, 1, 0]
    assert len(tokenized[0]["input_ids"]) < len(tokenized[1]["input_ids"])
    assert "text" not in tokenized.column_names
    assert "scores" not in tokenized.column_names


def test_metrics_preserve_ordinal_distance_and_five_class_f1():
    # Class 2 and 3 are absent. Compressing the remaining bins [0,1,4]
    # to [0,1,2] would incorrectly turn QWK into +0.5 instead of -1/26.
    labels = np.repeat(np.array([0, 1, 4])[:, None], 5, axis=1)
    predictions = np.repeat(np.array([0, 4, 1])[:, None], 5, axis=1)
    result = score_metrics(labels, predictions)
    assert result["qwk"] == pytest.approx(-1 / 26)
    assert result["mae"] == pytest.approx(2.0)
    assert result["accuracy"] == pytest.approx(1 / 3)
    assert result["all_dimensions_accuracy"] == pytest.approx(1 / 3)
    assert result["severe_error_rate"] == pytest.approx(2 / 3)
    assert result["macro_f1"] == pytest.approx(0.2)
    assert result["qwk_defined_dimensions"] == 5


def test_degenerate_qwk_is_finite_but_explicitly_undefined():
    labels = np.zeros((3, 5), dtype=np.int64)
    result = score_metrics(labels, labels)
    assert result["accuracy"] == 1
    assert result["mae"] == 0
    assert result["macro_f1"] == pytest.approx(0.2)
    assert result["qwk"] == 0
    assert result["qwk_defined_dimensions"] == 0
    assert result["dimension_1_qwk_defined"] == 0
    assert all(np.isfinite(value) for value in result.values())


@pytest.mark.parametrize("labels", [
    np.zeros((1, 5), dtype=np.float64),
    np.zeros((1, 5), dtype=np.bool_),
    np.full((1, 5), 5, dtype=np.int64),
    np.zeros((1, 4), dtype=np.int64),
])
def test_metrics_reject_non_index_or_wrong_shape_labels(labels):
    with pytest.raises(ValueError):
        score_metrics(labels, np.zeros((1, 5), dtype=np.int64))
