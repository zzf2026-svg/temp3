"""Verify the expensive risks: backbone transfer, loss, masking, persistence."""

from __future__ import annotations

import pytest
import torch
import torch.nn.functional as F
from transformers import ModernBertForMaskedLM

from five_scores.modeling import ModernBertForFiveScores


def test_loads_actual_mlm_backbone(tiny_pretrained, tiny_config):
    source = ModernBertForMaskedLM.from_pretrained(
        tiny_pretrained / "model", local_files_only=True, attn_implementation="sdpa"
    )
    target = ModernBertForFiveScores.from_pretrained(
        tiny_pretrained / "model", config=tiny_config,
        local_files_only=True, attn_implementation="sdpa"
    )
    # Compare every backbone tensor so an incorrect pretrained prefix cannot
    # silently turn supervised fine-tuning into training a random encoder.
    assert set(source.model.state_dict()) == set(target.model.state_dict())
    for key, value in source.model.state_dict().items():
        torch.testing.assert_close(target.model.state_dict()[key], value, rtol=0, atol=0)
    # A custom head must be initialized by our override: upstream ModernBERT
    # only initializes classifier weights for its own built-in task classes.
    assert torch.isfinite(target.classifier.weight).all()
    assert 1e-3 < target.classifier.weight.float().std() < 1
    assert target.classifier.weight.abs().max() < 5
    torch.testing.assert_close(target.classifier.bias, torch.zeros_like(target.classifier.bias))


def test_five_head_cross_entropy_and_backbone_gradient(tiny_config, input_batch):
    torch.manual_seed(5)
    model = ModernBertForFiveScores(tiny_config)
    labels = torch.tensor([[0, 1, 2, 3, 4], [4, 3, 2, 1, 0]])
    output = model(**input_batch, labels=labels)
    assert output.logits.shape == (2, 5, 5)
    expected = F.cross_entropy(output.logits.reshape(-1, 5), labels.reshape(-1))
    torch.testing.assert_close(output.loss, expected)
    output.loss.backward()
    assert model.classifier.weight.grad is not None
    assert torch.isfinite(model.classifier.weight.grad).all()
    assert model.classifier.weight.grad.abs().sum() > 0
    assert any(p.grad is not None and p.grad.abs().sum() > 0 for p in model.model.parameters())


@pytest.mark.parametrize("pooling", ["mean", "cls"])
def test_right_padding_does_not_change_scores(tiny_config, pooling):
    tiny_config.score_pooling = pooling
    model = ModernBertForFiveScores(tiny_config).eval()
    ids = torch.tensor([[1, 5, 6, 2]])
    padded = F.pad(ids, (0, 7), value=0)
    with torch.inference_mode():
        reference = model(input_ids=ids, attention_mask=torch.ones_like(ids)).logits
        result = model(input_ids=padded, attention_mask=padded.ne(0).long()).logits
    torch.testing.assert_close(result, reference, rtol=1e-4, atol=1e-6)


def test_save_reload_keeps_logits_and_scoring_metadata(tmp_path, tiny_config, input_batch):
    tiny_config.score_ordinal_weight = 0.15
    model = ModernBertForFiveScores(tiny_config).eval()
    with torch.inference_mode():
        before = model(**input_batch).logits
    model.save_pretrained(tmp_path, safe_serialization=True)
    restored = ModernBertForFiveScores.from_pretrained(
        tmp_path, local_files_only=True, attn_implementation="sdpa"
    ).eval()
    with torch.inference_mode():
        after = restored(**input_batch).logits
    torch.testing.assert_close(after, before, rtol=0, atol=0)
    for field in (
        "score_dim_names", "score_pooling", "score_max_length",
        "score_model_version", "score_ordinal_weight",
    ):
        assert getattr(restored.config, field) == getattr(tiny_config, field)


@pytest.mark.parametrize("names", [["a", "b", "c", "d"], ["a", "b", "c", "d", "d"]])
def test_rejects_invalid_dimension_names(tiny_config, names):
    tiny_config.score_dim_names = names
    with pytest.raises((ValueError, TypeError)):
        ModernBertForFiveScores(tiny_config)


def test_rejects_unsupported_pooling(tiny_config):
    tiny_config.score_pooling = "last"
    with pytest.raises(ValueError):
        ModernBertForFiveScores(tiny_config)


@pytest.mark.parametrize("labels", [
    torch.zeros((2, 4), dtype=torch.long),
    torch.full((2, 5), 5, dtype=torch.long),
    torch.full((2, 5), -1, dtype=torch.long),
    torch.ones((2, 5), dtype=torch.float32),
    torch.ones((2, 5), dtype=torch.bool),
])
def test_invalid_model_targets_fail_explicitly(tiny_config, input_batch, labels):
    model = ModernBertForFiveScores(tiny_config)
    with pytest.raises((ValueError, TypeError)):
        model(**input_batch, labels=labels)
