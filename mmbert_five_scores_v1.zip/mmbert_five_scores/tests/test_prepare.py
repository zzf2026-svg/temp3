"""Verify group isolation, conflicting-label protection and atomic outputs."""

from __future__ import annotations

import json

import pytest

from prepare_data import prepare_dataset


def write_jsonl(path, rows):
    path.write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows), encoding="utf-8")


def read_jsonl(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def group_membership(directory):
    membership = {}
    for split in ("train", "validation", "test"):
        for row in read_jsonl(directory / f"{split}.jsonl"):
            group = row["group_id"]
            assert membership.setdefault(group, split) == split, f"Group {group} leaked across splits"
    return membership


def test_split_preserves_groups_and_is_independent_of_input_order(tmp_path):
    rows = [
        {"id": f"{i}-{j}", "group_id": f"document-{i}", "text": f"文档 {i} 段落 {j}", "scores": [1, 2, 3, 4, 5]}
        for i in range(100) for j in range(2)
    ]
    # Same content and labels in one group: one canonical example is retained.
    rows.append({**rows[0], "id": "duplicate", "text": "  " + rows[0]["text"] + "\n"})
    source = tmp_path / "source.jsonl"
    first, second = tmp_path / "first", tmp_path / "second"
    write_jsonl(source, rows)
    report = prepare_dataset(source, first, validation_ratio=0.2, test_ratio=0.2, seed=19)
    assert report["input_rows"] == 201
    assert report["unique_rows"] == 200
    assert report["duplicates_removed"] == 1
    assert sum(report["splits"][split]["rows"] for split in ("train", "validation", "test")) == 200
    assert all(report["splits"][split]["rows"] > 0 for split in ("train", "validation", "test"))
    first_membership = group_membership(first)
    assert len(first_membership) == 100
    write_jsonl(source, list(reversed(rows)))
    prepare_dataset(source, second, validation_ratio=0.2, test_ratio=0.2, seed=19)
    assert group_membership(second) == first_membership


@pytest.mark.parametrize("change,error", [
    ({"scores": [5, 4, 3, 2, 1]}, "conflicting labels"),
    ({"group_id": "other-document"}, "different group ID"),
])
def test_conflicting_duplicates_abort_and_preserve_previous_outputs(tmp_path, change, error):
    source = tmp_path / "source.jsonl"
    destination = tmp_path / "prepared"
    first = {"text": "相同 文本", "scores": [1, 2, 3, 4, 5], "group_id": "document-1"}
    write_jsonl(source, [first])
    prepare_dataset(source, destination, validation_ratio=0, test_ratio=0)
    before = {path.name: path.read_bytes() for path in destination.iterdir()}
    write_jsonl(source, [first, {**first, **change}])
    with pytest.raises(ValueError, match=error):
        prepare_dataset(source, destination, validation_ratio=0, test_ratio=0, overwrite=True)
    assert {path.name: path.read_bytes() for path in destination.iterdir()} == before


@pytest.mark.parametrize("reverse", [False, True])
def test_mixed_group_ids_are_rejected_in_any_order(tmp_path, reverse):
    rows = [
        {"text": "第一条", "scores": [1, 2, 3, 4, 5], "group_id": "document"},
        {"text": "第二条", "scores": [1, 2, 3, 4, 5]},
    ]
    source = tmp_path / "mixed.jsonl"
    write_jsonl(source, list(reversed(rows)) if reverse else rows)
    with pytest.raises(ValueError, match="group"):
        prepare_dataset(source, tmp_path / "out", validation_ratio=0, test_ratio=0)
    assert not (tmp_path / "out").exists()
