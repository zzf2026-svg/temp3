# 更新说明

## v2.1：CSV 输入支持

- 新增通用入口 `convert_data.py`，按扩展名读取 CSV、XLSX、XLSM；旧 `convert_xlsx.py` 命令继续兼容。
- CSV 采用流式 CSV 解析器，支持 UTF-8 BOM、GB18030、可配置分隔符和被正确引用的多行字段，保留 ID 前导零。
- 新增 `conversion.csv_encoding` / `conversion.csv_delimiter` 配置，以及 `--encoding` / `--delimiter` 命令行覆盖。
- CSV 字段数不匹配时输出拒绝诊断；编码和语法错误时中止整个批次，保留已有结果。
- CSV 单独转换只需 `requirements-convert.txt` 中的 PyYAML；Excel 依赖按需安装。
- 七维默认配置、任意维度数量、训练样本上限、GPU 训练和部署接口沿用 v2。
- 更新 CSV 入门命令及验证记录，见 `GETTING_STARTED.md` 和 `VALIDATION.md`。

## v2

### 面向实际 Excel 数据

- 新增 convert_xlsx.py，独立安装 requirements-excel.txt 即可转换，不依赖训练框架。
- 默认适配七个独立分数列、五个原始内容字段、score_status 和 scene_key。
- 输出合格 JSONL、拒绝明细、报告和可复用文本模板。
- 附带本次上传样本的真实转换结果，原 Excel 保持不变。

### 可配置任务

- 维度名称列表统一驱动数据、分类头、损失、评估和推理；每维仍为五分类。
- 自动生成等权重，保存维度数量和顺序，拒绝同长度但顺序错误的标签。
- 保留旧版五维模型的类名与推理兼容。
- max_train_samples / max_eval_samples 为可选上限，null 使用实际全部数据。
- 新增按 epoch 评估和保存作为默认策略；steps 模式要求评估和保存间隔相等。
- 训练报告记录抽样前条数、配置上限、实际条数和随机种子。

### 文档与验证

- 重写 README.md 和 GETTING_STARTED.md，更新七维示例和全部命令。
- 完成 139 项测试、七维 CPU 端到端流程、默认 epoch 最佳模型验证。
- 详细记录见 VALIDATION.md；GPU 和真实业务训练仍需在目标环境执行。
