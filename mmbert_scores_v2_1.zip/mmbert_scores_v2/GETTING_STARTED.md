# 如何开始使用：mmBERT 多维评分 v2.1

配套代码包：`mmbert_scores_v2_1.zip`。支持 CSV、XLSX 和 XLSM 输入，默认按此前样表的字段配置训练七维评分模型，每维仍为 1～5 分；维度数和训练样本量都能通过配置调整。

下列命令在解压后的 `mmbert_scores_v2` 目录执行，多行写法适用于 Linux / WSL2 的 Bash。

## 1. 创建环境

```bash
unzip mmbert_scores_v2_1.zip
cd mmbert_scores_v2
python -m venv .venv
source .venv/bin/activate

# 只转换 CSV 时安装这一组即可，不需要 PyTorch。
python -m pip install -r requirements-convert.txt

# 可选：读取 XLSX/XLSM 时额外安装。
# python -m pip install -r requirements-excel.txt
```

## 2. 检查维度与样本量配置

打开 `configs/train.yaml`，默认已经填好这七个维度：

```yaml
model:
  dimension_names: [authenticity, value, relevance, severity, effectiveness, innovativeness, feasibility]
  num_dimensions: null
  dimension_weights: null

data:
  max_train_samples: null
  max_eval_samples: null
  validation_ratio: 0.05
  test_ratio: 0.05

training:
  seed: 42
  eval_strategy: epoch
```

这是配置摘录，请保留文件中的其他字段。

- **修改维度数：** 修改 `dimension_names` 列表即可。`num_dimensions: null` 自动计算数量，`dimension_weights: null` 自动生成等权重。
- **使用全部训练数据：** 保持 `max_train_samples: null`。
- **限制训练数量：** 例如设为 `50000`，表示切分后最多随机取五万条；实际不足则使用实际条数，不会重复补足。
- **控制切分：** 默认训练／验证／测试比例约为 90%／5%／5%，可以按实际数据量修改。
- **适配不同数据规模：** 默认每个 epoch 结束时评估并保存，避免短训练尚未达到固定评估步数就结束。

如果分数列名、输入字段或工作表名称变了，修改同一文件中的 `conversion` 部分；CSV 不使用工作表名称。

## 3. 转换 CSV（也支持 Excel）

把源文件放入 `raw/`：

```bash
mkdir -p raw

python convert_data.py \
  --input "raw/scores.csv" \
  --output-dir converted \
  --config configs/train.yaml
```

多个同结构 CSV 文件可使用 `--input "raw/*.csv"`，也可逐个传入路径。XLSX/XLSM 用同一个命令传入对应文件，脚本按扩展名选择读取方式。旧入口 `convert_xlsx.py` 也继续可用。

CSV 默认读取 UTF-8（有无 BOM 均可）、逗号分隔。如果导出为 GBK/GB18030，命令末尾加 `--encoding gb18030`；分号分隔加 `--delimiter ';'`，制表符分隔加 `--delimiter '\t'`。也可在 `configs/train.yaml` 中设置：

```yaml
conversion:
  csv_encoding: utf-8-sig
  csv_delimiter: ','
  header_row: 1
```

这是配置摘录，保留其他 `conversion` 字段。脚本支持 CSV 中用双引号包围的逗号、引号和多行文本。若 CSV 列名与此前样表不同，请调整 `text_columns`、`score_columns` 等映射；不用改模型代码。

默认输入文本按固定顺序拼接：核心要素、场景描述、痛点分析、解决方案、所属领域。七个分数列作为标签。总分 `score` 和 `model_name` 等信息保留为元数据。

转换后查看：

| 文件 | 用途 |
|---|---|
| `converted/labeled.jsonl` | 合格数据 |
| `converted/rejected.jsonl` | 拒绝行和原因 |
| `converted/report.json` | 条数与标签分布 |
| `converted/text_template.json` | 部署时沿用的输入格式 |

此前 XLSX 样表实际只有一条记录，其转换结果已经放在代码包的 `examples/from_uploaded_sample/` 中，标签为 `[4,3,4,4,3,3,3]`。它用于核对格式；后续训练需要你的完整数据。CSV 的兼容性验证使用同一记录导出的临时 CSV 与合成边界测试，尚未检查你的完整 CSV 文件。

## 4. 去重并切分

有足够数据后执行：

```bash
python prepare_data.py \
  --input converted/labeled.jsonl \
  --output-dir data \
  --config configs/train.yaml
```

生成 `data/train.jsonl`、`data/validation.jsonl`、`data/test.jsonl` 和 `data/report.json`。同一 `scene_key` 的记录保持在同一个集合。

如果仅有附件中的一条记录，此步骤无法生成有效的训练／验证／测试三份数据，会明确报错。不要复制这条记录填充集合。

## 5. 安装训练依赖并自检

```bash
# CUDA 12.8 wheel 示例；显卡或驱动不匹配时按官方说明换 wheel。
python -m pip install torch==2.8.0 --index-url https://download.pytorch.org/whl/cu128
python -m pip install -r requirements.txt

python -c "import torch; print('CUDA available:', torch.cuda.is_available())"

# 创建随机小模型，不下载 mmBERT，检查训练到推理的完整流程。
python scripts/smoke_test.py --device cpu --num-dimensions 7
```

GPU 训练前应确认 `CUDA available: True`。其他 PyTorch wheel 见 [官方安装说明](https://pytorch.org/get-started/previous-versions/#v280)。

## 6. 试跑与正式训练

先限制样本量，使用独立输出目录：

```bash
python train.py --config configs/train.yaml \
  --max-train-samples 50000 \
  --output-dir outputs/trial \
  --text-template-file converted/text_template.json
```

正式训练全部配置允许的数据：

```bash
python train.py --config configs/train.yaml \
  --text-template-file converted/text_template.json
```

同机两张 GPU 时，将上面的单卡命令替换为：

```bash
torchrun --standalone --nproc_per_node=2 train.py \
  --config configs/train.yaml \
  --text-template-file converted/text_template.json
```

默认最大长度为 512 tokens、每卡 batch 为 16、梯度累积为 4、训练两轮。根据显存和截断报告调整。

正式模型保存在 `outputs/mmbert-scores/final/`。试跑模型在 `outputs/trial/final/`。`--text-template-file` 将转换模板一同保存，便于部署时复用。

中断后，从同一输出目录恢复：

```bash
python train.py --config configs/train.yaml --resume-from-checkpoint auto
```

## 7. 评估与 GPU 批量推理

```bash
python evaluate.py \
  --model outputs/mmbert-scores/final \
  --data data/test.jsonl \
  --output outputs/test_metrics.json \
  --device cuda --batch-size 32
```

预测输入 `raw/predict.jsonl` 每行包含 `id` 和 `text`。`text` 使用与训练相同的拼接方式；原始字段字典如何复用模板，见 `README.md` 的“复用原始字段输入模板”示例。

```bash
python predict.py \
  --model outputs/mmbert-scores/final \
  --input raw/predict.jsonl \
  --output outputs/predictions.jsonl \
  --device cuda --batch-size 32 --include-probabilities
```

维度名称和顺序自动从模型读取。输出包含整数评分、期望分、可选完整概率及超长输入截断标记。

## 8. 启动 HTTP 接口

```bash
python -m pip install -r requirements-serve.txt

MODEL_DIR=outputs/mmbert-scores/final \
DEVICE=cuda DTYPE=auto BATCH_SIZE=32 \
python serve.py
```

另开终端测试：

```bash
curl http://127.0.0.1:8000/health

curl http://127.0.0.1:8000/predict \
  -H 'Content-Type: application/json' \
  -d '{"texts":["按训练模板拼接的文本"],"include_probabilities":true}'
```

更多数据格式、错误处理、显存调整、参数和性能测试说明见 `README.md`，本次实际测试记录见 `VALIDATION.md`。
