# mmBERT-small 多维文本评分（v2.1）

适用于已有教师评分标签的文本分类任务：使用 **PyTorch + Transformers + Datasets**，共享一次 mmBERT 编码，每个配置维度输出一组 1～5 分的概率。默认七个维度，维度数量和训练样本上限均可调整，数据没有“必须 100 万条”的限制。

默认维度顺序：

`authenticity → value → relevance → severity → effectiveness → innovativeness → feasibility`

默认骨干是 [jhu-clsp/mmBERT-small](https://huggingface.co/jhu-clsp/mmBERT-small)，全参数微调、mean pooling、每维五分类交叉熵。模型输出 `[batch_size, D, 5]`；D 是维度数，5 是固定评分等级数。

**验证记录见 `VALIDATION.md`。** 交付验证使用小型随机 ModernBERT；真实预训练模型的业务效果、GPU 显存、速度和多 GPU 运行需在你的环境中验证。代码包不包含预训练权重。

## 1. 从哪里开始

- 第一次操作：先读 `GETTING_STARTED.md`。
- 更改维度、字段或训练量：编辑 `configs/train.yaml`。
- 只转换 CSV：安装 `requirements-convert.txt`，无需安装 PyTorch；还要读取 XLSX/XLSM 时安装 `requirements-excel.txt`。
- 查看此前 XLSX 样表的实际转换结果：`examples/from_uploaded_sample/`。其中只有一条真实记录，适合检查转换格式；正式训练需要另外提供完整数据。
- `examples/train.jsonl` 等文件是合成格式示例，标签没有业务含义。

所有命令在解压后的 **`mmbert_scores_v2` 项目根目录** 执行。多行命令使用 Bash 语法，适用于 Linux / WSL2。

## 2. 安装环境

建议 Python 3.11 或 3.12。创建独立环境：

```bash
python -m venv .venv
source .venv/bin/activate

# 只转换 CSV / 准备 JSONL 数据时，安装这一组即可。
python -m pip install -r requirements-convert.txt

# 可选：需要读取 XLSX/XLSM 时安装。
# python -m pip install -r requirements-excel.txt
```

训练和 GPU 推理再安装：

```bash
# CUDA 12.8 wheel 示例。请按实际显卡和驱动选择合适的官方 wheel。
python -m pip install torch==2.8.0 --index-url https://download.pytorch.org/whl/cu128
python -m pip install -r requirements.txt

# 提供 HTTP 接口时安装。
python -m pip install -r requirements-serve.txt
```

其他 PyTorch 2.8 wheel 见 [官方历史版本安装说明](https://pytorch.org/get-started/previous-versions/#v280)。项目固定 Transformers 4.57.1、Datasets 4.3.0、Accelerate 1.10.1，以固定 API；不是要求使用最新依赖。

```bash
python -c "import torch; print(torch.__version__, torch.version.cuda); print('CUDA available:', torch.cuda.is_available())"
```

默认 GPU 使用原生 BF16 支持，否则选择 FP16；注意力采用 SDPA，不要求安装 flash-attn。只做 CPU 自检时，可将上面的 CUDA wheel 安装命令换成官方 CPU wheel：

```bash
python -m pip install torch==2.8.0 --index-url https://download.pytorch.org/whl/cpu
```

## 3. CSV / Excel 转换

把 CSV 放到 `raw/` 目录，例如 `raw/scores.csv`。默认按此前样表的列名配置；实际 CSV 表头不同的话，先调整下面的字段映射：

```bash
python convert_data.py \
  --input "raw/scores.csv" \
  --output-dir converted \
  --config configs/train.yaml
```

批量转换同结构文件：

```bash
python convert_data.py \
  --input "raw/*.csv" \
  --output-dir converted \
  --config configs/train.yaml
```

也可以在 `--input` 后传入多个明确路径，包括同结构的 CSV 和 XLSX/XLSM 混合文件。脚本按扩展名选择读取方式，文件按稳定顺序处理；同一文件不会因多个匹配模式重复读取。XLSX/XLSM 读取配置指定的工作表，CSV 忽略 `sheet_name`。旧入口 `convert_xlsx.py` 保留，也支持这三种格式。

### CSV 编码与分隔符

默认 `utf-8-sig` 同时读取带 BOM 和不带 BOM 的 UTF-8 文件。若实际导出为 GBK/GB18030，可明确指定：

```bash
python convert_data.py --input "raw/scores.csv" --output-dir converted \
  --config configs/train.yaml --encoding gb18030
```

默认分隔符为逗号。分号分隔文件使用 `--delimiter ';'`，制表符分隔文件使用 `--delimiter '\t'`。也可将这些设置写入 YAML；命令行覆盖 YAML。

读取使用标准 CSV 引号规则：字段中的逗号和换行需被双引号包围，字段内的双引号写成两个双引号。正确引用的多行文本会作为一个字段处理，ID 的前导零会保留。脚本不会猜测编码或分隔符，也不会用简单的字符串切分读取 CSV。

### 输出文件

| 文件 | 内容 |
|---|---|
| `converted/labeled.jsonl` | 合格记录，尚未去重或切分 |
| `converted/rejected.jsonl` | 拒绝的行、原因和来源 |
| `converted/report.json` | 逐文件与总条数、拒绝原因、每维分数分布 |
| `converted/text_template.json` | 文本字段、顺序、标题和格式，部署时可复用 |

每条合格记录的结构：

```json
{
  "id": "原始样本ID",
  "group_id": "原始scene_key",
  "text": "【核心要素】……\n【场景描述】……\n【痛点分析】……\n【解决方案】……\n【所属领域】……",
  "scores": [4, 3, 4, 4, 3, 3, 3],
  "dimension_names": ["authenticity", "value", "relevance", "severity", "effectiveness", "innovativeness", "feasibility"],
  "metadata": {
    "source_file": "来源CSV路径",
    "source_sheet": null,
    "source_format": "csv",
    "source_row": 2,
    "score": "3.3",
    "model_name": "原表中的值"
  }
}
```

JSONL 中每条记录实际占一行。外部标签始终是 1～5，训练内部自动转换成 0～4。

CSV 元数据保留原始字符串类型；XLSX 元数据保留读取到的数值等类型。因此总分 `score` 在 CSV 中可能为字符串 `"3.3"`，这不影响七维整数标签。CSV 的 `source_row` 是从 1 开始的逻辑记录编号，包含表头及跳过的记录；字段内换行不增加记录编号。XLSX 的 `source_row` 为工作表行号，`source_sheet` 为工作表名。

### 字段配置

```yaml
conversion:
  sheet_name: Sheet1
  header_row: 1
  csv_encoding: utf-8-sig
  csv_delimiter: ','
  text_columns: [core_elements, scene_description, pain_analysis, solution, domains]
  text_labels:
    core_elements: 核心要素
    scene_description: 场景描述
    pain_analysis: 痛点分析
    solution: 解决方案
    domains: 所属领域
  required_text_columns: [scene_description, pain_analysis, solution]
  score_columns: null
  id_column: id
  group_column: scene_key
  status_column: score_status
  accepted_statuses: [done]
  metadata_columns: [score, model_name, scored_at, create_time]
```

- `score_columns: null` 表示 CSV/Excel 分数列名与 `model.dimension_names` 一致。若列名不同，填入同样长度的列名列表，位置与维度列表一一对应。
- `sheet_name` 仅用于 XLSX/XLSM。`header_row` 默认是 1；CSV 中按逻辑记录计数，XLSX 中按工作表行计数。
- `csv_encoding` 和 `csv_delimiter` 仅用于 CSV；分隔符必须是一个字符，也接受字面量 `\t` 表示制表符。
- `text_columns` 控制输入字段及顺序；标题来自 `text_labels`。选定字段都应在表头中存在；`required_text_columns` 中的字段还要求每行值非空。可选字段的空值会被省略。
- 评分列和 `score` 总分不允许进入输入文本，以避免标签泄漏。
- `id_column`、`group_column`、`status_column` 可以设为 `null` 关闭相应处理。启用时要求每条接受记录有有效值。
- `accepted_statuses` 默认是 `[done]`；去掉首尾空格后比较，区分大小写。
- 配置在 `metadata_columns` 中的列要求存在表头，单元格可为空。如果某批数据没有这些列，请删去对应配置或设为 `[]`。
- 原表的 `model_name` 只保留为元数据。附件中它是 `Qwen3.5-4B`，转换器不会据此推断标签的评分模型。

### 校验与错误处理

转换器使用只读、逐记录流式处理方式，不修改输入文件。整数 3、数值 3.0、数值文本 "3.0" 都可规范成标签 3；3.5 不会被四舍五入。布尔、缺失、非有限数、越界标签和相关字段的 Excel 公式／错误值会被拒绝。CSV 不执行公式，文本字段中的 `=...` 作为普通文本保留，但不能作为合法评分。

CSV 非空记录的字段数量必须与表头一致，少列或多列（包括多出的空字段）会被拒绝并记录原因。空记录会被计数并跳过；单个 CSV 字段默认上限为 16,777,216 个字符，整个文件仍按记录读取。

缺少工作表、缺少配置列、重复表头、编码错误、CSV 引号语法错误或读取失败会终止整个批次，并撤回临时输出；已有转换结果保持不变。部分行被拒绝时保留合格记录并返回码 0；全部行无效时输出诊断目录，状态为 `no_valid_rows`，返回码 2。查看报告后再进入训练。

已有转换目录默认受保护。确实需要重新转换时加 `--overwrite`，该选项只替换本脚本生成的目录，不覆盖原始文件或无关目录。

## 4. 调整维度数

修改同一配置文件的有序维度列表：

```yaml
model:
  dimension_names:
    - authenticity
    - value
    - relevance
    - severity
    - effectiveness
    - innovativeness
    - feasibility
  num_dimensions: null
  dimension_weights: null
```

`num_dimensions: null` 表示自动取名称列表长度。也可显式填 7 作为一致性检查，但必须与名称数量一致。`dimension_weights: null` 自动为每个维度分配相同权重；手动指定时也必须有 D 项正数。

如只训练前五个维度，将名称列表改成这五项，再重新运行转换、切分和训练。如果源文件列映射使用了显式列表，也要同步调整映射。名称、顺序和数量会保存在数据记录和模型中；顺序不一致会报错。

原模型的导入名称 `ModernBertForFiveScores` 和包名 `five_scores` 保留兼容；新增别名 `ModernBertForMultiScores`，两者都支持配置 D。旧版五维 checkpoint 可按其原维度推理。增加、删除或改变评分维度时，应从预训练骨干重新训练任务头；不能仅改旧 checkpoint 的 JSON 配置。

## 5. 去重和切分

转换完成后：

```bash
python prepare_data.py \
  --input converted/labeled.jsonl \
  --output-dir data \
  --config configs/train.yaml
```

配置中的比例默认是约 90% / 5% / 5%：

```yaml
data:
  validation_ratio: 0.05
  test_ratio: 0.05

training:
  seed: 42
```

也可以通过 CLI 覆盖，例如 `--validation-ratio 0.1 --test-ratio 0.1`。比例为按组哈希分配的近似值，不是严格分层采样。

输出 `data/train.jsonl`、`data/validation.jsonl`、`data/test.jsonl` 和 `data/report.json`。该步骤使用磁盘 SQLite 做精确规范化去重，检查同文标签冲突和分组冲突，保持同一 `group_id` 不跨集合。来源元数据和维度顺序保留在切分结果中。

没有分组字段时按文本哈希切分。若场景变体还有更高一级同源关系，应在转换配置中选择相应的分组列。报告列出各维各档覆盖情况，便于检查极少出现的分数。

**此前 XLSX 样表只有一条记录，不能形成有效的三份数据集。** 可以单独完成转换。仅为检查后续 JSONL 校验，也可显式设置 `--validation-ratio 0 --test-ratio 0`；这不代表可以用同一条记录完成正式训练评估。请求的非空集合无法生成时，脚本会明确报错。

已有独立 JSONL/CSV/Parquet 也可直接使用。`--score-columns` 支持任意 D 个独立列；`--dimension-names` 和 `--num-dimensions` 支持不依赖 YAML 的转换校验。参数优先级为显式 CLI、配置、默认值。JSON 顶层数组会整体读入，较大数据建议 JSONL 或 Parquet。

## 6. 调整训练样本量并训练

```yaml
data:
  max_train_samples: null
  max_eval_samples: null
  max_length: 512
  num_proc: 4

training:
  num_train_epochs: 2
  per_device_train_batch_size: 16
  gradient_accumulation_steps: 4
  eval_strategy: epoch
```

`max_train_samples` 在完成切分之后应用：

| 配置 | 训练集实际有 80,000 条时 |
|---|---:|
| `null` | 使用 80,000 条 |
| `50000` | 按固定 seed 随机抽取 50,000 条 |
| `100000` | 使用实际可用的 80,000 条 |

不会复制样本补足上限。0、负数、非整数和布尔值会报错。`max_eval_samples` 只限制验证集；独立测试集仍由评估脚本读取。

先试跑：

```bash
python train.py --config configs/train.yaml \
  --max-train-samples 50000 --output-dir outputs/trial \
  --text-template-file converted/text_template.json
```

正式单卡训练：

```bash
python train.py --config configs/train.yaml \
  --text-template-file converted/text_template.json
```

`--text-template-file` 会将转换模板保存在模型配置与导出目录中；也可设置 `data.text_template_file`。使用自行准备、没有该模板的 JSONL 时省略此选项。

同机两卡 DDP：

```bash
torchrun --standalone --nproc_per_node=2 train.py \
  --config configs/train.yaml \
  --text-template-file converted/text_template.json
```

有效 batch = 每卡 batch × 梯度累积 × GPU 数。默认单卡为 64，两卡为 128。首次训练需要下载预训练模型和 tokenizer；也可以将 `model.name_or_path` 改成本地模型目录。将 `model.revision` 改为明确 Hub commit 可固定骨干版本。

### 评估、保存与恢复

默认 `eval_strategy: epoch`，每轮结束评估并保存，按验证集各维平均 MAE 最小选择模型，适配不同数据规模。

大数据需要更频繁评估时，设 `eval_strategy: steps`。本项目要求 `eval_steps` 与 `save_steps` **相等**，确保每次可能成为最佳结果的权重都有对应 checkpoint。短 `max_steps` 试跑会自动缩短超出总步数的评估／保存间隔。

最终推理目录：`outputs/mmbert-scores/final/`。试跑目录对应 `outputs/trial/final/`。

```bash
python train.py --config configs/train.yaml --resume-from-checkpoint auto
```

续训使用原输出目录和兼容配置，维度顺序、权重与损失定义应保持一致。使用 `checkpoint-N` 恢复优化器和调度器；`final/` 用于推理。训练报告包含抽样前条数、请求上限、实际使用条数、维度列表、随机种子和输入截断诊断。

## 7. 独立评估与 GPU 推理

评估测试集：

```bash
python evaluate.py \
  --model outputs/mmbert-scores/final \
  --data data/test.jsonl \
  --output outputs/test_metrics.json \
  --device cuda --batch-size 32
```

包含每维及总体 MAE、accuracy、五档 Macro-F1、QWK、严重误差率和每维 5×5 混淆矩阵。QWK 无法定义的退化维度有明确标记，不计入总体 QWK。教师标签上的指标表示与教师的一致程度，可另外建立人工复核集衡量业务质量。

批量预测的 `raw/predict.jsonl` 每行是 `{"id":"可选ID","text":"按训练模板组织好的文本"}`：

```bash
python predict.py \
  --model outputs/mmbert-scores/final \
  --input raw/predict.jsonl \
  --output outputs/predictions.jsonl \
  --device cuda --batch-size 32 --include-probabilities
```

输出 `scores`、`expected_scores`、`max_probabilities`、可选每档 `probabilities`，以及 token 长度和 `truncated` 标记。维度名称和顺序来自已训练 checkpoint，不需要部署时再次指定。

超长输入默认从右侧截断，长度沿用训练配置；`--reject-truncation` 可改为报错。最大 softmax 概率尚未校准，不等于真实正确率。

### 复用原始字段输入模板

预测接口接收已拼接的文本。对于原始字段字典，可以先复用保存的模板：

```python
import json
from five_scores.excel import build_text_from_template
from five_scores.inference import ScorePredictor

with open("outputs/mmbert-scores/final/text_template.json", encoding="utf-8") as f:
    template = json.load(f)

raw_fields = {
    "core_elements": "多人拼车",
    "scene_description": "乘客在车辆行驶时聊天，驾驶员感到疲惫。",
    "pain_analysis": "聊天干扰叠加疲劳，可能降低警觉性。",
    "solution": "检测驾驶员状态，并在需要时提醒停车休息。",
    "domains": "车联网|驾驶辅助",
}
text = build_text_from_template(raw_fields, template)
predictor = ScorePredictor("outputs/mmbert-scores/final", device="cuda")
print(predictor.predict([text])[0]["scores"])
```

模板格式化函数本身不依赖 Torch 或 openpyxl。模型训练和 HTTP 接口不会自动猜测原始字段的拼接方式。

## 8. HTTP 服务与测速

```bash
MODEL_DIR=outputs/mmbert-scores/final \
DEVICE=cuda DTYPE=auto BATCH_SIZE=32 \
python serve.py
```

默认地址 `http://127.0.0.1:8000`：

```bash
curl http://127.0.0.1:8000/health

curl http://127.0.0.1:8000/predict \
  -H 'Content-Type: application/json' \
  -d '{"texts":["按训练模板组织好的文本"],"include_probabilities":true}'
```

每张 GPU 一个服务进程；支持单个请求内批量评分，当前不合并多个 HTTP 请求形成动态批次。主要环境变量：

| 变量 | 默认值 |
|---|---|
| `MODEL_DIR` | 必填，训练后的本地目录 |
| `DEVICE` / `DTYPE` | `cuda` / `auto` |
| `BATCH_SIZE` | 32 |
| `HOST` / `PORT` | `127.0.0.1` / 8000 |
| `MAX_REQUEST_TEXTS` | 128 |
| `MAX_TEXT_CHARS` | 50,000 |
| `MAX_TOTAL_CHARS` | 200,000 |
| `REJECT_TRUNCATION` | `false` |

进程内性能检查：

```bash
python benchmark.py \
  --model outputs/mmbert-scores/final \
  --input raw/predict.jsonl --device cuda --batch-size 32 \
  --warmup 5 --iterations 50 --output outputs/benchmark.json
```

输入至少要有一个完整 batch。计时包括校验、分词、模型和后处理，排除加载、文件 I/O、HTTP 和外部排队；一个 request 是一个批次。`texts/s` 是文本吞吐，批次延迟不能除以 batch 冒充单条请求延迟。真实接口延迟请另用业务流量测量。

## 9. 自检

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q

# 本地随机小模型，不下载 mmBERT。
python scripts/smoke_test.py --device cpu --num-dimensions 7

# 验证其他维度数，或在目标 GPU 上验证。
python scripts/smoke_test.py --device cpu --num-dimensions 5
python scripts/smoke_test.py --device cuda --num-dimensions 7
```

smoke 使用临时目录和独立 Hugging Face 缓存，覆盖训练两步、保存重载、预测、评估、测速、续训到第三步、再预测，并检查训练样本上限与维度元数据。显式 `--work-dir` 会保留全部诊断；失败也保留输出。其分数和耗时仅用于功能检查。

## 10. 文件与来源

| 文件 | 用途 |
|---|---|
| `convert_data.py`、`five_scores/excel.py` | CSV / XLSX 转换、输入模板与异常报告；`convert_xlsx.py` 为兼容入口 |
| `five_scores/schema.py` | 七维默认名称、数量与类别数校验 |
| `configs/train.yaml` | 维度、字段、样本量和训练设置 |
| `prepare_data.py`、`five_scores/data.py` | 去重、分组切分、Arrow 缓存、分词 |
| `train.py`、`five_scores/modeling.py` | 可变 D 分类头、单卡／DDP、checkpoint |
| `evaluate.py`、`five_scores/metrics.py` | 独立评估 |
| `predict.py`、`serve.py`、`benchmark.py` | 批量推理、HTTP 接口和速度检查 |
| `tests/`、`scripts/` | 自动化测试与离线流程检查 |
| `VALIDATION.md`、`validation/` | 本次交付的验证记录 |

官方参考：[mmBERT-small 模型](https://huggingface.co/jhu-clsp/mmBERT-small)、[Transformers 4.57.1 Trainer](https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/trainer)、[openpyxl 只读模式](https://openpyxl.readthedocs.io/en/stable/optimized.html)、[PyTorch 2.8 安装](https://pytorch.org/get-started/previous-versions/#v280)。
