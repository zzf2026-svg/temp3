#!/usr/bin/env python3
"""Measure repeated fixed-batch latency, including tokenization and post-processing.

This is an in-process benchmark. File I/O, HTTP transport, external queueing and
model loading are excluded from timed requests. The first B input rows form one
batch, repeated each iteration. Test separate batch sizes and real text lengths.
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import statistics
import tempfile
import time
from pathlib import Path
from typing import Any

import torch
import transformers

from predict import add_inference_arguments, commit_output, iter_rows, predictor_from_args


def percentile(values: list[float], quantile: float) -> float:
    ordered = sorted(values)
    position = (len(ordered) - 1) * quantile
    left = int(position)
    right = min(left + 1, len(ordered) - 1)
    return ordered[left] + (ordered[right] - ordered[left]) * (position - left)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    add_inference_arguments(parser)
    parser.add_argument("--input", type=Path, required=True, help="Representative UTF-8 JSONL with at least batch-size rows")
    parser.add_argument("--text-column", default="text")
    parser.add_argument("--warmup", type=int, default=5)
    parser.add_argument("--iterations", type=int, default=30)
    parser.add_argument("--output", type=Path, help="Optional JSON report path")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    if args.batch_size < 1 or args.iterations < 1 or args.warmup < 0:
        parser.error("batch-size and iterations must be positive; warmup must be nonnegative")
    source = args.input.expanduser().resolve()
    destination = args.output.expanduser().resolve() if args.output else None
    if destination == source:
        parser.error("--input and --output must use different paths")
    if destination and destination.exists() and not args.overwrite:
        parser.error("Output exists; use another path or explicitly pass --overwrite")
    texts: list[str] = []
    for _, row in iter_rows(source, args.text_column):
        texts.append(row[args.text_column])
        if len(texts) == args.batch_size:
            break
    if len(texts) != args.batch_size:
        parser.error(f"Input has only {len(texts)} rows; choose --batch-size <= {len(texts)} or provide more rows")

    load_started = time.perf_counter()
    predictor = predictor_from_args(args)

    def synchronize() -> None:
        if predictor.device.type == "cuda":
            torch.cuda.synchronize(predictor.device)

    def run_once() -> list[dict[str, Any]]:
        return predictor.predict(
            texts, batch_size=args.batch_size, include_probabilities=args.include_probabilities,
            reject_truncation=args.reject_truncation,
        )

    synchronize()
    model_load_seconds = time.perf_counter() - load_started
    for _ in range(args.warmup):
        run_once()
        synchronize()
    if predictor.device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(predictor.device)

    durations_ms: list[float] = []
    predictions: list[dict[str, Any]] = []
    for _ in range(args.iterations):
        synchronize()
        started = time.perf_counter()
        predictions = run_once()
        synchronize()
        durations_ms.append((time.perf_counter() - started) * 1000)
    measured_seconds = sum(durations_ms) / 1000
    lengths = [row["input_tokens"] for row in predictions]
    report: dict[str, Any] = {
        "measurement": "in-process, one sequential batch request at a time; tokenization + model + post-processing",
        "excluded": ["model loading", "file I/O", "HTTP transport", "external queueing", "JSON serialization"],
        "input_selection": f"First {args.batch_size} rows of {source.name}; same fixed batch repeated each iteration",
        "model_directory": str(predictor.model_dir),
        "dimensions": predictor.dimension_names,
        "batch_size": args.batch_size,
        "warmup_requests": args.warmup,
        "timed_requests": args.iterations,
        "timed_texts": args.iterations * args.batch_size,
        "batch_request_latency_ms": {
            "mean": statistics.mean(durations_ms),
            "p50": percentile(durations_ms, 0.5),
            "p95": percentile(durations_ms, 0.95),
            "min": min(durations_ms), "max": max(durations_ms),
        },
        "requests_per_second": args.iterations / measured_seconds,
        "texts_per_second": args.iterations * args.batch_size / measured_seconds,
        "model_load_seconds": model_load_seconds,
        "input_tokens_including_special_tokens": {
            "min": min(lengths), "p50": percentile(lengths, 0.5), "max": max(lengths),
        },
        "truncated_texts_per_request": sum(int(row["truncated"]) for row in predictions),
        "settings": {
            "device": str(predictor.device), "precision": predictor.precision,
            "max_length": predictor.max_length, "attention": args.attn_implementation,
            "torch_compile": args.compile_model, "include_probabilities": args.include_probabilities,
            "reject_truncation": args.reject_truncation,
        },
        "versions": {
            "python": platform.python_version(), "torch": torch.__version__,
            "transformers": transformers.__version__, "torch_cuda": torch.version.cuda,
            "platform": platform.platform(),
        },
    }
    if predictor.device.type == "cuda":
        properties = torch.cuda.get_device_properties(predictor.device)
        report["hardware"] = {
            "name": properties.name, "compute_capability": f"{properties.major}.{properties.minor}",
            "total_memory_mib": properties.total_memory / 2**20,
            "peak_allocated_memory_mib": torch.cuda.max_memory_allocated(predictor.device) / 2**20,
            "peak_reserved_memory_mib": torch.cuda.max_memory_reserved(predictor.device) / 2**20,
        }
    else:
        report["hardware"] = {
            "name": platform.processor() or platform.machine(), "torch_num_threads": torch.get_num_threads(),
        }
    serialized = json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    if destination:
        destination.parent.mkdir(parents=True, exist_ok=True)
        fd, name = tempfile.mkstemp(prefix=f".{destination.name}.", suffix=".tmp", dir=destination.parent)
        temporary = Path(name)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                stream.write(serialized)
                stream.flush()
                os.fsync(stream.fileno())
            commit_output(temporary, destination, args.overwrite)
        finally:
            temporary.unlink(missing_ok=True)
    print(serialized, end="")


if __name__ == "__main__":
    main()
