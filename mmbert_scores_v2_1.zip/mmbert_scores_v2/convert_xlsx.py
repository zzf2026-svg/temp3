#!/usr/bin/env python3
"""Backward-compatible v2 entry point; accepts CSV, XLSX and XLSM inputs."""

from convert_data import main


if __name__ == "__main__":
    raise SystemExit(main())
