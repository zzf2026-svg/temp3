"""One mmBERT encoder, five ordinal score distributions."""

__version__ = "1.0.0"
