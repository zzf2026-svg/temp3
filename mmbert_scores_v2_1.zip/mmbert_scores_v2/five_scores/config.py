"""Small, strict YAML configuration loader (paths are relative to the CWD)."""

from __future__ import annotations

from copy import deepcopy
import math
from pathlib import Path

import yaml

from five_scores.schema import DEFAULT_DIMENSION_NAMES, validate_dimension_names, validate_num_dimensions


DEFAULTS = {
    "model": {
        "name_or_path": "jhu-clsp/mmBERT-small",
        "revision": "main",
        "dimension_names": list(DEFAULT_DIMENSION_NAMES),
        "num_dimensions": None,
        "pooling": "mean",
        "dropout": 0.1,
        "dimension_weights": None,
        "ordinal_weight": 0.0,
        "attn_implementation": "sdpa",
    },
    "data": {
        "train_file": "data/train.jsonl",
        "validation_file": "data/validation.jsonl",
        "text_column": "text",
        "scores_column": "scores",
        "score_columns": None,
        "text_template_file": None,
        "max_length": 512,
        "num_proc": 4,
        "max_train_samples": None,
        "max_eval_samples": None,
        "validation_ratio": 0.05,
        "test_ratio": 0.05,
    },
    "conversion": {
        "sheet_name": "Sheet1",
        "header_row": 1,
        "csv_encoding": "utf-8-sig",
        "csv_delimiter": ",",
        "text_columns": ["core_elements", "scene_description", "pain_analysis", "solution", "domains"],
        "text_labels": {
            "core_elements": "核心要素", "scene_description": "场景描述",
            "pain_analysis": "痛点分析", "solution": "解决方案", "domains": "所属领域",
        },
        "required_text_columns": ["scene_description", "pain_analysis", "solution"],
        "score_columns": None,
        "id_column": "id",
        "group_column": "scene_key",
        "status_column": "score_status",
        "accepted_statuses": ["done"],
        "metadata_columns": ["score", "model_name", "scored_at", "create_time"],
    },
    "training": {
        "output_dir": "outputs/mmbert-scores",
        "seed": 42,
        "num_train_epochs": 2.0,
        "max_steps": -1,
        "per_device_train_batch_size": 16,
        "per_device_eval_batch_size": 32,
        "gradient_accumulation_steps": 4,
        "learning_rate": 2e-5,
        "head_learning_rate": 1e-4,
        "weight_decay": 0.01,
        "warmup_ratio": 0.03,
        "lr_scheduler_type": "cosine",
        "precision": "auto",
        "use_cpu": False,
        "gradient_checkpointing": False,
        "eval_strategy": "epoch",
        "eval_steps": 1000,
        "save_steps": 1000,
        "logging_steps": 50,
        "save_total_limit": 2,
        "early_stopping_patience": 3,
        "dataloader_num_workers": 4,
        "group_by_length": True,
        "max_grad_norm": 1.0,
        "tf32": True,
        "torch_compile": False,
        "resume_from_checkpoint": None,
    },
}


def validate_config(config: dict) -> dict:
    """Resolve the shared schema and reject inconsistent inexpensive options."""
    model, data, training = (config[section] for section in ("model", "data", "training"))
    names = validate_dimension_names(model["dimension_names"])
    count = len(names)
    declared = model.get("num_dimensions")
    if declared is not None and validate_num_dimensions(declared) != count:
        raise ValueError("model.num_dimensions must match len(model.dimension_names)")
    model["dimension_names"] = names
    model["num_dimensions"] = count
    weights = model.get("dimension_weights")
    if weights is None:
        weights = [1.0] * count
    if not isinstance(weights, (list, tuple)) or len(weights) != count:
        raise ValueError("model.dimension_weights must be null or contain one weight per dimension")
    if any(isinstance(weight, bool) or not isinstance(weight, (int, float))
           or not math.isfinite(weight) or weight <= 0 for weight in weights):
        raise ValueError("model.dimension_weights must contain finite positive numbers")
    model["dimension_weights"] = [float(weight) for weight in weights]
    columns = data.get("score_columns")
    if columns is not None and len(validate_dimension_names(columns)) != count:
        raise ValueError("data.score_columns must match the configured dimension count")
    for key in ("max_train_samples", "max_eval_samples"):
        value = data[key]
        if value is not None and (isinstance(value, bool) or not isinstance(value, int) or value < 1):
            raise ValueError(f"data.{key} must be a positive integer or null (all available rows)")
    ratios = [data["validation_ratio"], data["test_ratio"]]
    if any(isinstance(value, bool) or not isinstance(value, (int, float))
           or not math.isfinite(value) or not 0 <= value < 1 for value in ratios) or sum(ratios) >= 1:
        raise ValueError("data.validation_ratio/test_ratio must be in [0,1), with sum below 1")
    if training["eval_strategy"] not in {"epoch", "steps"}:
        raise ValueError("training.eval_strategy must be 'epoch' or 'steps'")
    if training["eval_strategy"] == "steps" and training["save_steps"] != training["eval_steps"]:
        raise ValueError("For steps evaluation, save_steps must equal eval_steps so every candidate best model is saved")
    if isinstance(training["seed"], bool) or not isinstance(training["seed"], int) or training["seed"] < 0:
        raise ValueError("training.seed must be a non-negative integer")
    return config


def load_config(path: str | Path) -> dict:
    with Path(path).open(encoding="utf-8") as handle:
        supplied = yaml.safe_load(handle) or {}
    if not isinstance(supplied, dict):
        raise ValueError("YAML root must be a mapping")
    result = deepcopy(DEFAULTS)
    for section, values in supplied.items():
        if section not in result:
            raise ValueError(f"Unknown config section: {section}")
        if not isinstance(values, dict):
            raise ValueError(f"Config section {section} must be a mapping")
        extra = set(values) - set(result[section])
        if extra:
            raise ValueError(f"Unknown {section} options: {sorted(extra)}")
        result[section].update(values)
    return validate_config(result)
