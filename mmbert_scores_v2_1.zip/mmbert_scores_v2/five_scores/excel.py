"""Read-only, streaming CSV/Excel conversion for configurable scoring dimensions.

The input workbook is never written. Scores are read with ``data_only=False``
so formula cells cannot silently become labels from stale cached results.
Deduplication and train/validation/test splitting belong to prepare_data.py.
"""

from __future__ import annotations

from collections import Counter
from contextlib import contextmanager
import codecs
import csv
from dataclasses import dataclass
from datetime import date, datetime, time
from decimal import Decimal, InvalidOperation
import glob
import json
import math
from numbers import Integral, Real
from pathlib import Path
import re
import shutil
import sys
import tempfile
from typing import Any, Mapping, Sequence
import uuid

from .schema import NUM_CLASSES, validate_dimension_names


# Retain the ownership marker so --overwrite accepts directories made by v2.
PIPELINE_ID = "mmbert_scores.convert_xlsx.v2"
OUTPUT_FILES = {"labeled.jsonl", "rejected.jsonl", "report.json", "text_template.json"}
DEFAULT_CONVERSION = {
    "sheet_name": "Sheet1",
    "header_row": 1,
    "csv_encoding": "utf-8-sig",
    "csv_delimiter": ",",
    "text_columns": ["core_elements", "scene_description", "pain_analysis", "solution", "domains"],
    "text_labels": {
        "core_elements": "核心要素",
        "scene_description": "场景描述",
        "pain_analysis": "痛点分析",
        "solution": "解决方案",
        "domains": "所属领域",
    },
    "required_text_columns": ["scene_description", "pain_analysis", "solution"],
    "id_column": "id",
    "group_column": "scene_key",
    "status_column": "score_status",
    "accepted_statuses": ["done"],
    "metadata_columns": ["score", "model_name", "scored_at", "create_time"],
    "score_columns": None,
}
_SOURCE_KEYS = {"source_file", "source_sheet", "source_row", "source_format"}
_DECIMAL_TEXT = re.compile(r"[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)\Z")


def _column_list(value: Any, name: str, *, nonempty: bool = False) -> list[str]:
    if not isinstance(value, (list, tuple)) or (nonempty and not value):
        raise ValueError(f"conversion.{name} must be {'a nonempty' if nonempty else 'a'} list of column names")
    if any(not isinstance(item, str) or not item.strip() for item in value):
        raise ValueError(f"conversion.{name} must contain nonempty strings")
    result = [item.strip() for item in value]
    if len(set(result)) != len(result):
        raise ValueError(f"conversion.{name} must contain distinct names after trimming whitespace")
    return result


def _optional_column(value: Any, name: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"conversion.{name} must be a nonempty column name or null")
    return value.strip()


@dataclass(frozen=True)
class ExcelSettings:
    dimension_names: tuple[str, ...]
    score_columns: tuple[str, ...]
    sheet_name: str
    header_row: int
    text_columns: tuple[str, ...]
    text_labels: dict[str, str]
    required_text_columns: tuple[str, ...]
    id_column: str | None
    group_column: str | None
    status_column: str | None
    accepted_statuses: tuple[str, ...]
    metadata_columns: tuple[str, ...]
    csv_encoding: str
    csv_delimiter: str

    @property
    def required_columns(self) -> set[str]:
        columns = set(self.text_columns) | set(self.score_columns) | set(self.metadata_columns)
        columns.update(column for column in (self.id_column, self.group_column, self.status_column) if column)
        return columns

    def text_template(self) -> dict[str, Any]:
        """A portable manifest; inference must use the same field ordering."""
        return {
            "schema_version": 1,
            "renderer": "labeled_sections_v1",
            "format": "【{label}】{value}",
            "separator": "\n",
            "value_normalization": "strip outer whitespace; normalize CRLF/CR to LF",
            "empty_optional_fields": "omit",
            "sections": [
                {"column": column, "label": self.text_labels[column], "required": column in self.required_text_columns}
                for column in self.text_columns
            ],
            "dimension_names": list(self.dimension_names),
            "score_columns": list(self.score_columns),
            "num_classes": NUM_CLASSES,
            "score_range": [1, NUM_CLASSES],
        }


def resolve_settings(config: Mapping[str, Any]) -> ExcelSettings:
    """Validate the converter subset of a loaded train.yaml configuration.

    ``model.dimension_names`` is the authoritative label order. Optional
    ``conversion.score_columns`` is an equally long list of source column names
    in that order. Null ID/group/status column names disable their respective
    behavior; ID and group keys are then omitted rather than fabricated.
    """
    if not isinstance(config, Mapping) or not isinstance(config.get("model"), Mapping):
        raise ValueError("Configuration must contain model.dimension_names")
    names = validate_dimension_names(config["model"].get("dimension_names"))
    supplied = config.get("conversion", {})
    if not isinstance(supplied, Mapping):
        raise ValueError("conversion must be a mapping")
    extra = set(supplied) - set(DEFAULT_CONVERSION)
    if extra:
        raise ValueError(f"Unknown conversion options: {sorted(extra)}")
    options = {**DEFAULT_CONVERSION, **supplied}
    score_columns = names if options["score_columns"] is None else _column_list(options["score_columns"], "score_columns", nonempty=True)
    if len(score_columns) != len(names):
        raise ValueError("conversion.score_columns must have one entry per model.dimension_names, in the same order")
    text_columns = _column_list(options["text_columns"], "text_columns", nonempty=True)
    forbidden = set(score_columns) | set(names) | {"score"}
    if forbidden.intersection(text_columns):
        raise ValueError(f"Label/aggregate score columns cannot be input text: {sorted(forbidden.intersection(text_columns))}")
    required_text = _column_list(options["required_text_columns"], "required_text_columns")
    if not set(required_text).issubset(text_columns):
        raise ValueError("conversion.required_text_columns must be a subset of conversion.text_columns")
    metadata_columns = _column_list(options["metadata_columns"], "metadata_columns")
    if _SOURCE_KEYS.intersection(metadata_columns):
        raise ValueError("conversion.metadata_columns cannot use reserved source_file/source_sheet/source_row/source_format names")
    raw_labels = options["text_labels"]
    if not isinstance(raw_labels, Mapping):
        raise ValueError("conversion.text_labels must be a mapping")
    labels: dict[str, str] = {}
    for column in text_columns:
        label = raw_labels.get(column, column)
        if not isinstance(label, str) or not label.strip():
            raise ValueError(f"conversion.text_labels[{column!r}] must be a nonempty string")
        labels[column] = label.strip()
    sheet_name = options["sheet_name"]
    if not isinstance(sheet_name, str) or not sheet_name:
        raise ValueError("conversion.sheet_name must be a nonempty worksheet name")
    header_row = options["header_row"]
    if isinstance(header_row, bool) or not isinstance(header_row, Integral) or header_row < 1:
        raise ValueError("conversion.header_row must be a positive integer")
    encoding = options["csv_encoding"]
    if not isinstance(encoding, str) or not encoding.strip():
        raise ValueError("conversion.csv_encoding must be a nonempty encoding name")
    encoding = encoding.strip()
    try:
        codecs.lookup(encoding)
        # A registered codec can be a binary transform (e.g. base64_codec),
        # which cannot be used as an encoding for a text file.
        "".encode(encoding)
    except (LookupError, TypeError) as exc:
        raise ValueError(f"Unknown or non-text conversion.csv_encoding: {encoding!r}") from exc
    delimiter = options["csv_delimiter"]
    if delimiter == r"\t":
        delimiter = "\t"
    if not isinstance(delimiter, str) or len(delimiter) != 1 or delimiter in {'"', "\r", "\n", "\x00"}:
        raise ValueError("conversion.csv_delimiter must be one character (or literal \\t); quote, newline and NUL are not allowed")
    status_column = _optional_column(options["status_column"], "status_column")
    statuses = _column_list(options["accepted_statuses"], "accepted_statuses", nonempty=status_column is not None)
    return ExcelSettings(
        dimension_names=tuple(names), score_columns=tuple(score_columns),
        sheet_name=sheet_name, header_row=int(header_row), text_columns=tuple(text_columns),
        text_labels=labels, required_text_columns=tuple(required_text),
        id_column=_optional_column(options["id_column"], "id_column"),
        group_column=_optional_column(options["group_column"], "group_column"),
        status_column=status_column, accepted_statuses=tuple(statuses),
        metadata_columns=tuple(metadata_columns),
        csv_encoding=encoding, csv_delimiter=delimiter,
    )


def parse_rating(value: Any) -> int:
    """Accept exactly integral 1..5 values, including Excel 3.0 or text '3.0'."""
    if isinstance(value, bool) or value is None:
        raise ValueError("expected an integer score from 1 to 5")
    if isinstance(value, Integral):
        result = int(value)
    elif isinstance(value, Real):
        if not math.isfinite(value) or value != int(value):
            raise ValueError("expected a finite integer score from 1 to 5")
        result = int(value)
    elif isinstance(value, str) and _DECIMAL_TEXT.fullmatch(value.strip()):
        try:
            number = Decimal(value.strip())
        except InvalidOperation as exc:
            raise ValueError("expected a numeric score from 1 to 5") from exc
        if not number.is_finite() or number != number.to_integral_value():
            raise ValueError("fractional scores cannot be rounded into labels")
        result = int(number)
    else:
        raise ValueError("expected an integer score from 1 to 5")
    if not 1 <= result <= NUM_CLASSES:
        raise ValueError(f"score must be in 1..{NUM_CLASSES}, got {result}")
    return result


def _json_safe(value: Any) -> Any:
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else str(value)
    if isinstance(value, (datetime, date, time)):
        return value.isoformat()
    if isinstance(value, Mapping):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    return str(value)


def _is_blank(value: Any) -> bool:
    return value is None or (isinstance(value, str) and not value.strip())


def _text_value(value: Any) -> str:
    if _is_blank(value):
        return ""
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("text field contains a nonfinite number")
    safe = _json_safe(value)
    text = safe if isinstance(safe, str) else json.dumps(safe, ensure_ascii=False, allow_nan=False)
    return text.replace("\r\n", "\n").replace("\r", "\n").strip()


def build_input_text(values: Mapping[str, Any], settings: ExcelSettings) -> str:
    """Apply the training template to raw inference fields as well as Excel rows."""
    sections: list[str] = []
    for column in settings.text_columns:
        value = _text_value(values.get(column))
        if not value:
            if column in settings.required_text_columns:
                raise ValueError(f"required text column {column!r} is blank")
            continue
        sections.append(f"【{settings.text_labels[column]}】{value}")
    if not sections:
        raise ValueError("all configured text fields are blank")
    return "\n".join(sections)


def build_text_from_template(values: Mapping[str, Any], template: Mapping[str, Any]) -> str:
    """Render inference fields using the saved text_template.json manifest.

    This helper uses only the Python standard library and the shared schema
    module; loading this module does not import openpyxl or torch.
    """
    if not isinstance(template, Mapping) or template.get("schema_version") != 1 or template.get("renderer") != "labeled_sections_v1":
        raise ValueError("Unsupported text template version or renderer")
    if template.get("format") != "【{label}】{value}" or template.get("separator") != "\n":
        raise ValueError("Unsupported text template format or separator")
    sections = template.get("sections")
    if not isinstance(sections, list) or not sections:
        raise ValueError("Text template must contain a nonempty sections list")
    seen: set[str] = set()
    rendered: list[str] = []
    for section in sections:
        if not isinstance(section, Mapping):
            raise ValueError("Every text template section must be a mapping")
        column, label, required = section.get("column"), section.get("label"), section.get("required")
        if not isinstance(column, str) or not column.strip() or column in seen:
            raise ValueError("Text template columns must be nonempty and distinct")
        if not isinstance(label, str) or not label.strip() or not isinstance(required, bool):
            raise ValueError("Each text template section requires a label and a boolean required flag")
        seen.add(column)
        value = _text_value(values.get(column))
        if not value:
            if required:
                raise ValueError(f"required text column {column!r} is blank")
            continue
        rendered.append(f"【{label}】{value}")
    if not rendered:
        raise ValueError("all configured text fields are blank")
    return "\n".join(rendered)


def _identifier(value: Any) -> str | int:
    if isinstance(value, str) and value.strip():
        return value
    if isinstance(value, Integral) and not isinstance(value, bool):
        return int(value)
    if isinstance(value, Real) and not isinstance(value, bool) and math.isfinite(value) and value == int(value):
        return int(value)
    raise ValueError("expected a nonempty text ID or an integer ID")


def validate_row(
    values: Mapping[str, Any], settings: ExcelSettings, *,
    source_file: str, source_sheet: str | None, source_row: int,
    formula_columns: set[str] | frozenset[str] = frozenset(),
    error_columns: set[str] | frozenset[str] = frozenset(),
) -> tuple[dict[str, Any] | None, list[dict[str, str]]]:
    """Validate one row, returning all relevant issues without inventing labels."""
    reasons: list[dict[str, str]] = []

    def issue(code: str, column: str, message: str) -> None:
        reasons.append({"code": code, "column": column, "message": message})

    protected = set(settings.score_columns) | set(settings.text_columns)
    protected.update(column for column in (settings.id_column, settings.group_column, settings.status_column) if column)
    blocked = (formula_columns | error_columns).intersection(protected)
    for column in sorted(blocked):
        if column in formula_columns:
            issue("formula_cell", column, "Formula cells are not accepted for input text, labels, IDs, groups, or status; supply explicit values")
        else:
            issue("excel_error", column, "Excel error cells are not usable values")
    if settings.status_column and settings.status_column not in blocked:
        status = values.get(settings.status_column)
        if not isinstance(status, str) or not status.strip():
            issue("missing_status", settings.status_column, "Scoring status must be a nonempty string")
        elif status.strip() not in settings.accepted_statuses:
            issue("status_not_accepted", settings.status_column, f"Status {status!r} is not in {list(settings.accepted_statuses)!r}")
    scores: list[int] = []
    for column in settings.score_columns:
        if column in blocked:
            continue
        try:
            scores.append(parse_rating(values.get(column)))
        except ValueError as exc:
            issue("invalid_score", column, str(exc))
    identifiers: dict[str, str | int] = {}
    for output_key, column in (("id", settings.id_column), ("group_id", settings.group_column)):
        if column is None or column in blocked:
            continue
        try:
            identifiers[output_key] = _identifier(values.get(column))
        except ValueError as exc:
            issue("invalid_identifier", column, str(exc))
    text = ""
    if not blocked.intersection(settings.text_columns):
        try:
            text = build_input_text(values, settings)
        except ValueError as exc:
            issue("invalid_text", "text", str(exc))
    if reasons:
        return None, reasons
    metadata = {"source_file": source_file, "source_sheet": source_sheet, "source_row": source_row}
    metadata.update({column: _json_safe(values.get(column)) for column in settings.metadata_columns})
    return {
        **identifiers,
        "text": text,
        "scores": scores,
        "dimension_names": list(settings.dimension_names),
        "metadata": metadata,
    }, []


def expand_input_paths(inputs: Sequence[str | Path]) -> list[Path]:
    """Expand user globs deterministically and remove duplicate input paths."""
    if isinstance(inputs, (str, Path)) or not inputs:
        raise ValueError("inputs must be a nonempty sequence of file paths or glob patterns")
    results: list[Path] = []
    seen: set[Path] = set()
    for item in inputs:
        pattern = str(Path(item).expanduser())
        # An existing literal filename may itself contain glob metacharacters,
        # such as export[1].xlsx. Prefer that exact file before glob expansion.
        matches = [pattern] if Path(pattern).is_file() or not glob.has_magic(pattern) else sorted(glob.glob(pattern, recursive=True))
        if not matches:
            raise FileNotFoundError(f"No input file matches: {item}")
        for matched in matches:
            path = Path(matched).resolve()
            if not path.is_file():
                raise FileNotFoundError(f"Input is not a file: {path}")
            if path.suffix.lower() not in {".csv", ".xlsx", ".xlsm"}:
                raise ValueError(f"Expected a .csv, .xlsx or .xlsm file, got: {path}")
            if path not in seen:
                results.append(path)
                seen.add(path)
    return results


def _check_destination(output: Path, overwrite: bool) -> None:
    if output.is_symlink():
        raise ValueError("The output directory must not be a symbolic link")
    if not output.exists():
        return
    if not output.is_dir():
        raise ValueError(f"Output path exists and is not a directory: {output}")
    children = list(output.iterdir())
    if not children:
        return
    if not overwrite:
        raise FileExistsError(f"Output directory is not empty: {output}; use a new path or --overwrite for a prior conversion")
    if any(child.name not in OUTPUT_FILES or not child.is_file() or child.is_symlink() for child in children):
        raise ValueError("--overwrite only replaces an owned conversion directory containing labeled/rejected.jsonl, report.json, and text_template.json")
    try:
        previous = json.loads((output / "report.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError("--overwrite requires a report.json from this converter") from exc
    if not isinstance(previous, dict) or previous.get("pipeline") != PIPELINE_ID:
        raise ValueError("--overwrite refuses a directory not created by this converter")


def _publish_directory(staging: Path, output: Path, overwrite: bool) -> None:
    _check_destination(output, overwrite)
    backup: Path | None = None
    if output.exists():
        backup = output.with_name(f".{output.name}.backup-{uuid.uuid4().hex}")
        output.rename(backup)
    try:
        staging.rename(output)
    except BaseException:
        if backup is not None and not output.exists():
            backup.rename(output)
        raise
    if backup is not None:
        try:
            shutil.rmtree(backup)
        except OSError:
            print(f"Warning: conversion succeeded; old backup retained at {backup}", file=sys.stderr)


def _headers(cells: Sequence[Any], settings: ExcelSettings, location: str) -> list[str | None]:
    headers: list[str | None] = []
    seen: set[str] = set()
    for number, cell in enumerate(cells, start=1):
        value = cell.value
        if _is_blank(value):
            headers.append(None)
            continue
        if getattr(cell, "data_type", None) in {"f", "e"} or not isinstance(value, str):
            raise ValueError(f"{location}: header column {number} must be a text column name")
        name = value.strip()
        if name in seen:
            raise ValueError(f"{location}: duplicate header after trimming whitespace: {name!r}")
        seen.add(name)
        headers.append(name)
    missing = settings.required_columns - seen
    if missing:
        raise ValueError(f"{location}: missing configured columns: {sorted(missing)}")
    return headers


def _write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


@dataclass(frozen=True)
class _CsvCell:
    """Expose the small cell interface shared by the streaming validators."""
    value: str
    data_type: str = "s"


@contextmanager
def _source_rows(source: Path, settings: ExcelSettings):
    """Yield sheet name, validated headers and a streaming cell iterator.

    CSV rows are logical records: quoted embedded newlines do not create extra
    rows. No type inference is applied, preserving leading zeros in identifiers.
    """
    if source.suffix.lower() == ".csv":
        previous_limit = csv.field_size_limit()
        # LLM exports may contain descriptions longer than Python's default.
        # Allow 16 * 1024 * 1024 characters (or respect a higher caller limit).
        csv.field_size_limit(max(previous_limit, 16 * 1024 * 1024))
        reader = None
        try:
            with source.open("r", encoding=settings.csv_encoding, newline="") as stream:
                reader = csv.reader(stream, delimiter=settings.csv_delimiter, strict=True)
                header_values = None
                for _ in range(settings.header_row):
                    header_values = next(reader, None)
                    if header_values is None:
                        raise ValueError(f"{source.name}: missing CSV header record {settings.header_row}")
                headers = _headers([_CsvCell(value) for value in header_values], settings,
                                   f"{source.name}:CSV record {settings.header_row}")
                rows = ([_CsvCell(value) for value in values] for values in reader)
                yield None, headers, rows
        except UnicodeError as exc:
            raise ValueError(f"{source.name}: cannot decode CSV using {settings.csv_encoding!r}; set conversion.csv_encoding or --encoding to the file's actual encoding") from exc
        except csv.Error as exc:
            line = reader.line_num if reader is not None else 0
            raise ValueError(f"{source.name}: malformed CSV near physical line {line}: {exc}") from exc
        finally:
            csv.field_size_limit(previous_limit)
        return

    try:
        from openpyxl import load_workbook
    except ImportError as exc:
        raise ImportError("Excel conversion requires openpyxl; install requirements-excel.txt") from exc
    workbook = load_workbook(source, read_only=True, data_only=False, keep_links=False)
    try:
        if settings.sheet_name not in workbook.sheetnames:
            raise ValueError(f"{source.name}: missing worksheet {settings.sheet_name!r}; available: {workbook.sheetnames}")
        sheet = workbook[settings.sheet_name]
        # Some exporters save incorrect dimensions. Reset them so a read-only
        # iterator does not silently truncate valid rows.
        sheet.reset_dimensions()
        rows = sheet.iter_rows(min_row=settings.header_row)
        header_cells = next(rows, None)
        location = f"{source.name}:{settings.sheet_name}:row {settings.header_row}"
        if header_cells is None:
            raise ValueError(f"{location}: missing header row")
        yield settings.sheet_name, _headers(header_cells, settings, location), rows
    finally:
        workbook.close()


def convert_files(
    inputs: Sequence[str | Path], output_dir: str | Path, config: Mapping[str, Any], *, overwrite: bool = False,
) -> dict[str, Any]:
    """Stream CSV/Excel files to canonical JSONL and publish a complete directory.

    File/schema errors leave any existing output unchanged. Invalid data rows
    are saved to rejected.jsonl. If every row is invalid (or the sheets contain
    no records), diagnostics are intentionally published with status
    ``no_valid_rows``; the CLI then exits with code 2. A partial conversion is a
    successful run with explicit accepted/rejected counts. No splitting or
    deduplication is performed here.
    """
    settings = resolve_settings(config)
    sources = expand_input_paths(inputs)
    output = Path(output_dir).expanduser().absolute()
    resolved_output = output.resolve()
    if any(resolved_output == source or resolved_output in source.parents for source in sources):
        raise ValueError("Input files must be outside the output directory")
    _check_destination(output, overwrite)
    output.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=f".{output.name}.tmp-", dir=output.parent))
    report: dict[str, Any] = {
        "pipeline": PIPELINE_ID,
        "converter_version": "2.1",
        "status": "ok",
        "input_files": [str(path) for path in sources],
        "dimension_names": list(settings.dimension_names),
        "num_dimensions": len(settings.dimension_names),
        "score_range": [1, NUM_CLASSES],
        "score_columns": list(settings.score_columns),
        "sheet_name": settings.sheet_name,
        "header_row": settings.header_row,
        "csv_encoding": settings.csv_encoding,
        "csv_delimiter": settings.csv_delimiter,
        "scanned_rows": 0,
        "input_rows": 0,
        "blank_rows": 0,
        "accepted_rows": 0,
        "rejected_rows": 0,
        "label_distributions": {name: {str(score): 0 for score in range(1, NUM_CLASSES + 1)} for name in settings.dimension_names},
        "deduplication_performed": False,
        "split_performed": False,
        "status_filter": {"column": settings.status_column, "accepted_values": list(settings.accepted_statuses) if settings.status_column else None},
        "id_column": settings.id_column,
        "group_column": settings.group_column,
        "metadata_columns": list(settings.metadata_columns),
        "source_reports": [],
        "warnings": [],
    }
    reasons_count: Counter[str] = Counter()
    try:
        with (staging / "labeled.jsonl").open("w", encoding="utf-8", newline="\n") as accepted, (staging / "rejected.jsonl").open("w", encoding="utf-8", newline="\n") as rejected:
            for source in sources:
                source_format = source.suffix.lower().lstrip(".")
                with _source_rows(source, settings) as (source_sheet, headers, rows):
                    per_file = {"source_file": str(source), "source_format": source_format, "source_sheet": source_sheet, "scanned_rows": 0, "input_rows": 0, "blank_rows": 0, "accepted_rows": 0, "rejected_rows": 0}
                    for row_number, cells in enumerate(rows, start=settings.header_row + 1):
                        for counts in (report, per_file):
                            counts["scanned_rows"] += 1
                        if all(_is_blank(cell.value) for cell in cells):
                            for counts in (report, per_file):
                                counts["blank_rows"] += 1
                            continue
                        for counts in (report, per_file):
                            counts["input_rows"] += 1
                        values = {name: cells[index].value if index < len(cells) else None for index, name in enumerate(headers) if name is not None}
                        formulas = {name for index, name in enumerate(headers) if name is not None and index < len(cells) and getattr(cells[index], "data_type", None) == "f"}
                        errors = {name for index, name in enumerate(headers) if name is not None and index < len(cells) and getattr(cells[index], "data_type", None) == "e"}
                        record, reasons = validate_row(values, settings, source_file=str(source), source_sheet=source_sheet, source_row=row_number, formula_columns=formulas, error_columns=errors)
                        if source_format == "csv" and len(cells) != len(headers):
                            record = None
                            reasons.append({"code": "csv_field_count", "column": "row", "message": f"CSV field count {len(cells)} does not match header column count {len(headers)}; check delimiter and quoting"})
                        unnamed = [index + 1 for index, cell in enumerate(cells) if not _is_blank(cell.value) and (index >= len(headers) or headers[index] is None)]
                        if unnamed:
                            record = None
                            reasons.append({"code": "unnamed_columns", "column": "header", "message": f"Nonempty cells under missing headers at column numbers {unnamed}"})
                            for number in unnamed:
                                values[f"__unnamed_column_{number}"] = cells[number - 1].value
                        if record is None:
                            for counts in (report, per_file):
                                counts["rejected_rows"] += 1
                            # Count affected rows per code, even if several
                            # dimensions fail the same validation on one row.
                            reasons_count.update({reason["code"] for reason in reasons})
                            diagnostic = {"source_file": str(source), "source_format": source_format, "source_sheet": source_sheet, "source_row": row_number, "reasons": reasons, "raw": _json_safe(values)}
                            rejected.write(json.dumps(diagnostic, ensure_ascii=False, allow_nan=False) + "\n")
                        else:
                            if source_format == "csv":
                                record["metadata"]["source_format"] = "csv"
                            for counts in (report, per_file):
                                counts["accepted_rows"] += 1
                            for name, score in zip(settings.dimension_names, record["scores"]):
                                report["label_distributions"][name][str(score)] += 1
                            accepted.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n")
                        if report["input_rows"] % 100000 == 0:
                            print(f"Converted {report['input_rows']:,} rows; accepted {report['accepted_rows']:,}; rejected {report['rejected_rows']:,}", file=sys.stderr)
                report["source_reports"].append(per_file)
        report["rejection_reason_rows"] = dict(sorted(reasons_count.items()))
        if report["accepted_rows"] == 0:
            report["status"] = "no_valid_rows"
            report["warnings"].append("No valid records were converted. Diagnostics are saved; the CLI exits with code 2.")
        if report["rejected_rows"]:
            report["warnings"].append("Some records were rejected; review rejected.jsonl before training.")
        _write_json(staging / "report.json", report)
        _write_json(staging / "text_template.json", settings.text_template())
        _publish_directory(staging, output, overwrite)
        return report
    finally:
        if staging.exists():
            shutil.rmtree(staging)


# Public compatibility name used by v2 integrations. Both names now support CSV.
convert_workbooks = convert_files
