"""Metrics for integer score indices (0..4) and D separate dimensions."""

from __future__ import annotations

import re
from typing import Sequence

import numpy as np

from .schema import NUM_CLASSES, default_dimension_names, validate_dimension_names


def _validate_indices(values: np.ndarray, name: str) -> np.ndarray:
    values = np.asarray(values)
    if values.ndim != 2 or values.shape[1] < 1 or values.shape[0] == 0:
        raise ValueError(f"{name} must have nonempty shape [N, D], with D >= 1")
    if not np.issubdtype(values.dtype, np.integer):
        raise ValueError(f"{name} must contain integer class indices in 0..4")
    if np.any(values < 0) or np.any(values >= NUM_CLASSES):
        raise ValueError(f"{name} contains a class index outside 0..4")
    return values.astype(np.int64, copy=False)


def score_metrics(
    labels: np.ndarray,
    predictions: np.ndarray,
    dimension_names: Sequence[str] | None = None,
) -> dict[str, float | int]:
    """Return flat numeric metrics; both arguments are integer [N,D] in 0..4.

    Accuracy is the mean over N*D decisions. Macro-F1 uses all five possible
    score classes in every dimension (an unsupported class contributes zero).
    QWK uses the fixed five-bin scale. An undefined QWK is represented by 0
    plus ``<dimension>_qwk_defined=0`` so Trainer logs remain finite; it is
    excluded from the aggregate QWK. If all dimensions are undefined, aggregate
    QWK is also 0 and ``qwk_defined_dimensions`` is 0. Such 0 values are missing
    metric placeholders, not measured agreement.
    """
    labels = _validate_indices(labels, "labels")
    predictions = _validate_indices(predictions, "predictions")
    if labels.shape != predictions.shape:
        raise ValueError("labels and predictions must have the same shape")
    dimensions = labels.shape[1]
    names = validate_dimension_names(
        dimension_names if dimension_names is not None else default_dimension_names(dimensions)
    )
    if len(names) != dimensions:
        raise ValueError(f"dimension_names must contain {dimensions} nonempty strings")
    prefixes = [re.sub(r"[^\w]+", "_", name, flags=re.UNICODE).strip("_") for name in names]
    if any(not name for name in prefixes) or len(set(prefixes)) != dimensions:
        raise ValueError("dimension_names must remain nonempty and unique after punctuation normalization")

    differences = np.abs(labels - predictions)
    result: dict[str, float | int] = {
        "mae": float(differences.mean()),
        "accuracy": float((labels == predictions).mean()),
        "severe_error_rate": float((differences >= 2).mean()),
        "all_dimensions_accuracy": float((labels == predictions).all(axis=1).mean()),
    }
    f1_values: list[float] = []
    defined_qwk: list[float] = []
    weights = (np.arange(NUM_CLASSES)[:, None] - np.arange(NUM_CLASSES)[None, :]) ** 2 / (NUM_CLASSES - 1) ** 2
    count = labels.shape[0]
    for dimension, prefix in enumerate(prefixes):
        y_true, y_pred = labels[:, dimension], predictions[:, dimension]
        confusion = np.bincount(NUM_CLASSES * y_true + y_pred, minlength=NUM_CLASSES ** 2).reshape(
            NUM_CLASSES, NUM_CLASSES
        ).astype(np.float64)
        actual = confusion.sum(axis=1)
        predicted = confusion.sum(axis=0)
        f1_denominator = actual + predicted
        per_class_f1 = np.divide(
            2 * np.diag(confusion),
            f1_denominator,
            out=np.zeros(NUM_CLASSES, dtype=np.float64),
            where=f1_denominator != 0,
        )
        f1 = float(per_class_f1.mean())
        f1_values.append(f1)
        expected = np.outer(actual, predicted) / count
        denominator = float((weights * expected).sum())
        is_defined = denominator > 0
        qwk = float(1.0 - (weights * confusion).sum() / denominator) if is_defined else 0.0
        if is_defined:
            defined_qwk.append(qwk)
        result.update({
            f"{prefix}_mae": float(differences[:, dimension].mean()),
            f"{prefix}_accuracy": float((y_true == y_pred).mean()),
            f"{prefix}_macro_f1": f1,
            f"{prefix}_severe_error_rate": float((differences[:, dimension] >= 2).mean()),
            f"{prefix}_qwk": qwk,
            f"{prefix}_qwk_defined": int(is_defined),
        })
    result["macro_f1"] = float(np.mean(f1_values))
    result["qwk"] = float(np.mean(defined_qwk)) if defined_qwk else 0.0
    result["qwk_defined_dimensions"] = len(defined_qwk)
    return result
