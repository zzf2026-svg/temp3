"""Shared score schema; task dimensions are independent of rating classes."""

from __future__ import annotations

from numbers import Integral
from typing import Sequence


NUM_CLASSES = 5
DEFAULT_DIMENSION_NAMES = (
    "authenticity", "value", "relevance", "severity",
    "effectiveness", "innovativeness", "feasibility",
)


def validate_num_dimensions(value: int) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral) or value < 1:
        raise ValueError("num_dimensions must be a positive integer")
    return int(value)


def validate_dimension_names(names: Sequence[str]) -> list[str]:
    if not isinstance(names, (list, tuple)) or not names:
        raise ValueError("dimension_names must be a nonempty list of distinct strings")
    if any(not isinstance(name, str) or not name.strip() for name in names):
        raise ValueError("dimension_names must contain nonempty strings")
    result = [name.strip() for name in names]
    if len(set(result)) != len(result):
        raise ValueError("dimension_names must be distinct after trimming whitespace")
    return result


def default_dimension_names(num_dimensions: int | None = None) -> list[str]:
    if num_dimensions is None:
        return list(DEFAULT_DIMENSION_NAMES)
    count = validate_num_dimensions(num_dimensions)
    if count == len(DEFAULT_DIMENSION_NAMES):
        return list(DEFAULT_DIMENSION_NAMES)
    return [f"dim_{index + 1}" for index in range(count)]
