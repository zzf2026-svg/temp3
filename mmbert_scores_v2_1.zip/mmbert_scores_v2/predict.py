#!/usr/bin/env python3
"""Stream JSONL through a saved five-score model and atomically write JSONL."""

from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
from pathlib import Path
from typing import Any, Iterator

from five_scores.inference import ScorePredictor


def iter_rows(path: Path, text_column: str) -> Iterator[tuple[int, dict[str, Any]]]:
    with path.open("r", encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            try:
                row = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"{path}, line {line_number}: invalid JSON ({exc.msg})") from exc
            if not isinstance(row, dict):
                raise ValueError(f"{path}, line {line_number}: expected a JSON object")
            text = row.get(text_column)
            if not isinstance(text, str) or not text.strip():
                raise ValueError(f"{path}, line {line_number}: {text_column!r} must be a nonempty string")
            yield line_number, row


def add_inference_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--model", type=Path, required=True, help="Saved trained checkpoint directory")
    parser.add_argument("--device", default="cuda", help="cuda, cuda:N, or cpu")
    parser.add_argument("--precision", choices=["auto", "bf16", "fp16", "fp32"], default="auto")
    parser.add_argument("--max-length", type=int, help="Override the training token limit, including special tokens")
    parser.add_argument("--attn-implementation", choices=["sdpa", "eager", "flash_attention_2"], default="sdpa")
    parser.add_argument("--compile", dest="compile_model", action="store_true", help="Optional torch.compile; allow warmup")
    parser.add_argument("--max-text-chars", type=int, default=100_000)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--include-probabilities", action="store_true")
    parser.add_argument("--reject-truncation", action="store_true", help="Fail if any input exceeds max_length")


def predictor_from_args(args: argparse.Namespace) -> ScorePredictor:
    return ScorePredictor(
        args.model, device=args.device, precision=args.precision,
        max_length=args.max_length, attn_implementation=args.attn_implementation,
        compile_model=args.compile_model, max_text_chars=args.max_text_chars,
    )


def commit_output(temporary: Path, destination: Path, overwrite: bool) -> None:
    """Publish a complete file; a failed run leaves the previous output intact."""
    if overwrite:
        os.replace(temporary, destination)
    else:
        # Both paths are in the same directory/filesystem. link() creates the
        # final name atomically and refuses even a concurrent existing file.
        os.link(temporary, destination)
        temporary.unlink()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    add_inference_arguments(parser)
    parser.add_argument("--input", type=Path, required=True, help="UTF-8 JSONL; one text object per line")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--text-column", default="text")
    parser.add_argument("--id-column", default="id", help="If present, copy this field into output id")
    parser.add_argument("--include-text", action="store_true", help="Also copy input text into output text")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    if args.batch_size < 1:
        parser.error("--batch-size must be positive")
    source, destination = args.input.expanduser().resolve(), args.output.expanduser().resolve()
    if source == destination:
        parser.error("--input and --output must use different paths")
    if destination.exists() and not args.overwrite:
        parser.error("Output exists; use another path or explicitly pass --overwrite")
    if not source.is_file():
        parser.error(f"Input file does not exist: {source}")
    predictor = predictor_from_args(args)
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary_name = tempfile.mkstemp(prefix=f".{destination.name}.", suffix=".tmp", dir=destination.parent)
    temporary = Path(temporary_name)
    count = 0
    truncated_count = 0

    try:
        with os.fdopen(fd, "w", encoding="utf-8") as output:
            pending: list[tuple[int, dict[str, Any]]] = []

            def flush() -> None:
                nonlocal count, truncated_count
                texts = [row[args.text_column] for _, row in pending]
                predictions = predictor.predict(
                    texts, batch_size=args.batch_size, include_probabilities=args.include_probabilities,
                    reject_truncation=args.reject_truncation,
                )
                for (_, row), prediction in zip(pending, predictions):
                    result: dict[str, Any] = {}
                    if args.id_column in row:
                        result["id"] = row[args.id_column]
                    if args.include_text:
                        result["text"] = row[args.text_column]
                    result.update(prediction)
                    output.write(json.dumps(result, ensure_ascii=False, allow_nan=False) + "\n")
                    count += 1
                    truncated_count += int(prediction["truncated"])
                pending.clear()

            for row in iter_rows(source, args.text_column):
                pending.append(row)
                if len(pending) == args.batch_size:
                    flush()
            if pending:
                flush()
            if not count:
                raise ValueError("Input contains no records")
            output.flush()
            os.fsync(output.fileno())
        commit_output(temporary, destination, args.overwrite)
    finally:
        temporary.unlink(missing_ok=True)
    print(f"Wrote {count} predictions to {destination}; truncated inputs: {truncated_count}", file=sys.stderr)


if __name__ == "__main__":
    main()
