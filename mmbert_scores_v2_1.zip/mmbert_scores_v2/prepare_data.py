#!/usr/bin/env python3
"""Validate, deduplicate, and reproducibly split a labeled text dataset.

This preparation step uses a temporary disk-backed SQLite index. It never loads
an entire JSONL, CSV, or Parquet source into Python memory. JSON arrays are
supported for small files; use JSONL at million-row scale.
"""

from __future__ import annotations

import argparse
from contextlib import ExitStack
import hashlib
import json
import math
from pathlib import Path
import shutil
import sqlite3
import sys
import tempfile
from typing import Any, Sequence
import uuid

from five_scores.data import (
    canonical_record,
    iter_source_records,
    normalized_text,
    resolve_dimension_schema,
    text_digest,
    validate_score_columns,
)
from five_scores.schema import default_dimension_names

PIPELINE_ID = "mmbert_scores.prepare_data.v2"
OUTPUT_FILES = {"train.jsonl", "validation.jsonl", "test.jsonl", "report.json"}
SPLIT_NAMES = ("train", "validation", "test")
PROVENANCE_KEYS = (
    "metadata", "source", "source_file", "source_sheet", "source_row", "source_path", "source_record", "source_line",
)


def _score_counts(dimension_names: Sequence[str]) -> dict[str, dict[str, int]]:
    return {name: {str(score): 0 for score in range(1, 6)} for name in dimension_names}


def _count_scores(counts: dict[str, dict[str, int]], scores: list[int]) -> None:
    for dimension, score in zip(counts, scores, strict=True):
        counts[dimension][str(score)] += 1


def _metadata_identifier(value: Any, *, column: str, location: str) -> str | int:
    if isinstance(value, bool) or not isinstance(value, (str, int)):
        raise ValueError(f"{location}: '{column}' must be a nonempty string or an integer identifier")
    if isinstance(value, str) and not value.strip():
        raise ValueError(f"{location}: '{column}' must be a nonempty identifier")
    return value


def _split_for_key(key: str, seed: int, validation_ratio: float, test_ratio: float) -> str:
    # Hash the complete group key; every row in a group makes the same choice.
    # JSON serialization distinguishes integer IDs from string IDs.
    digest = hashlib.sha256(f"{seed}\0{key}".encode("utf-8")).digest()
    number = int.from_bytes(digest[:8], "big")
    train_limit = int((1.0 - validation_ratio - test_ratio) * (1 << 64))
    validation_limit = int((1.0 - test_ratio) * (1 << 64))
    if number < train_limit:
        return "train"
    if number < validation_limit:
        return "validation"
    return "test"


def _check_destination(output: Path, overwrite: bool) -> None:
    if output.is_symlink():
        raise ValueError("The output directory must not be a symbolic link")
    if not output.exists():
        return
    if not output.is_dir():
        raise ValueError(f"Output path already exists and is not a directory: {output}")
    children = list(output.iterdir())
    if not children:
        return
    if not overwrite:
        raise FileExistsError(f"Output directory is not empty: {output}; pass --overwrite to replace a previously prepared dataset")
    if any(child.name not in OUTPUT_FILES or not child.is_file() or child.is_symlink() for child in children):
        raise ValueError("--overwrite only replaces a generated dataset directory containing train/validation/test.jsonl and report.json")
    try:
        old_report = json.loads((output / "report.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError("--overwrite requires a report.json from an earlier successful preparation run") from exc
    if old_report.get("pipeline") != PIPELINE_ID:
        raise ValueError("--overwrite refuses a directory that was not created by this preparation script")


def _publish_directory(staging: Path, output: Path, overwrite: bool) -> None:
    # Recheck immediately before publication so an unrelated existing directory
    # is not replaced if it appeared during a long preparation job.
    _check_destination(output, overwrite)
    backup: Path | None = None
    if output.exists():
        backup = output.with_name(f".{output.name}.backup-{uuid.uuid4().hex}")
        output.rename(backup)
    try:
        staging.rename(output)
    except BaseException:
        if backup is not None and not output.exists():
            backup.rename(output)
        raise
    if backup is not None:
        try:
            shutil.rmtree(backup)
        except OSError:
            # Publication has succeeded; retain the backup if cleanup is denied.
            print(f"Warning: prepared data saved, but the old backup could not be removed: {backup}", file=sys.stderr)


def prepare_dataset(
    input_path: str | Path,
    output_dir: str | Path,
    *,
    text_column: str = "text",
    scores_column: str = "scores",
    score_columns: Sequence[str] | None = None,
    num_dimensions: int | None = None,
    dimension_names: Sequence[str] | None = None,
    group_column: str | None = None,
    seed: int = 42,
    validation_ratio: float = 0.05,
    test_ratio: float = 0.05,
    overwrite: bool = False,
) -> dict[str, Any]:
    """Prepare canonical JSONL splits and return the saved preparation report.

    Duplicate normalization is deliberately conservative: NFC, uniform line
    endings, and outer trim. Duplicate labels must agree. If the same normalized
    text appears with different group IDs, preparation fails for manual review
    instead of silently creating a train/validation/test leakage path.

    ``group_id`` is auto-detected when present on the first row. Custom group
    column names must be passed explicitly. Mixed presence of group IDs fails.
    Hash assignment makes split membership deterministic and group-preserving;
    requested ratios are approximate and are not class-stratified.

    The supplied dimension_names determine the semantic score order; when no
    names are supplied, num_dimensions selects generated names (seven defaults
    to the actual XLSX fields). Declared row names must agree exactly. Canonical
    output records include this schema plus IDs and conversion provenance.
    """
    num_dimensions, names = resolve_dimension_schema(num_dimensions=num_dimensions, dimension_names=dimension_names)
    names = names if names is not None else default_dimension_names(num_dimensions)
    ratios = (validation_ratio, test_ratio)
    if any(not math.isfinite(ratio) or ratio < 0 or ratio >= 1 for ratio in ratios):
        raise ValueError("validation_ratio and test_ratio must be finite numbers in [0, 1)")
    if validation_ratio + test_ratio >= 1:
        raise ValueError("validation_ratio + test_ratio must be below 1 so training data remains")
    if isinstance(seed, bool) or not isinstance(seed, int):
        raise ValueError("seed must be an integer")
    if score_columns is not None:
        score_columns = validate_score_columns(score_columns, num_dimensions)
    source = Path(input_path).expanduser().resolve()
    output = Path(output_dir).expanduser().absolute()
    if not source.is_file():
        raise FileNotFoundError(f"Input file does not exist: {source}")
    # A mistaken output path must never replace the original input's directory.
    if source == output or output.resolve() in source.parents:
        raise ValueError("The input file must be outside the output directory")
    _check_destination(output, overwrite)
    output.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=f".{output.name}.tmp-", dir=output.parent))
    connection: sqlite3.Connection | None = None
    resolved_group_column = group_column
    grouping_detected = False
    total_rows = 0
    unique_rows = 0
    duplicate_rows = 0
    input_counts = _score_counts(names)
    unique_counts = _score_counts(names)

    try:
        database_path = staging / "dedup.sqlite3"
        connection = sqlite3.connect(database_path)
        # The index is disposable and is never published. Keep its cache bounded
        # while avoiding durability work for a fully reproducible temporary DB.
        connection.execute("PRAGMA journal_mode=OFF")
        connection.execute("PRAGMA synchronous=OFF")
        connection.execute("PRAGMA temp_store=FILE")
        connection.execute("PRAGMA cache_size=-65536")
        connection.execute(
            "CREATE TABLE examples (digest BLOB PRIMARY KEY, raw_json TEXT NOT NULL, "
            "scores TEXT NOT NULL, group_key TEXT NOT NULL, first_row INTEGER NOT NULL)"
        )
        if source.suffix.lower() == ".json":
            print("Note: a JSON array is read into memory; prefer JSONL, CSV, or Parquet for large datasets.", file=sys.stderr)
        for row_number, raw in iter_source_records(source):
            location = f"{source.name}: record/line {row_number}"
            record = canonical_record(
                raw,
                text_column=text_column,
                scores_column=scores_column,
                score_columns=score_columns,
                num_dimensions=num_dimensions,
                dimension_names=names,
                location=location,
            )
            record["dimension_names"] = names
            for key in PROVENANCE_KEYS:
                if key in raw:
                    if key == "metadata" and not isinstance(raw[key], dict):
                        raise ValueError(f"{location}: metadata must be a JSON object")
                    record[key] = raw[key]
            if not grouping_detected:
                if resolved_group_column is None and "group_id" in raw:
                    resolved_group_column = "group_id"
                grouping_detected = True
            if resolved_group_column is None and "group_id" in raw:
                raise ValueError(f"{location}: mixed presence of group_id; supply a valid group ID on every row")
            digest = text_digest(record["text"])
            if resolved_group_column is not None:
                if resolved_group_column not in raw:
                    raise ValueError(f"{location}: missing group column '{resolved_group_column}'")
                group_id = _metadata_identifier(raw[resolved_group_column], column=resolved_group_column, location=location)
                record["group_id"] = group_id
                group_key = "group:" + json.dumps(group_id, ensure_ascii=False, separators=(",", ":"))
            else:
                group_key = "text:" + digest.hex()
            if "id" in raw and raw["id"] is not None:
                record["id"] = _metadata_identifier(raw["id"], column="id", location=location)
            scores_json = json.dumps(record["scores"], separators=(",", ":"))
            try:
                raw_json = json.dumps(record, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
            except (TypeError, ValueError) as exc:
                raise ValueError(f"{location}: metadata/source fields must be JSON-serializable with finite numbers: {exc}") from exc
            total_rows += 1
            _count_scores(input_counts, record["scores"])
            cursor = connection.execute(
                "INSERT OR IGNORE INTO examples(digest,raw_json,scores,group_key,first_row) VALUES (?,?,?,?,?)",
                (digest, raw_json, scores_json, group_key, row_number),
            )
            if cursor.rowcount == 1:
                unique_rows += 1
                _count_scores(unique_counts, record["scores"])
            else:
                previous = connection.execute(
                    "SELECT raw_json,scores,group_key,first_row FROM examples WHERE digest=?", (digest,)
                ).fetchone()
                assert previous is not None
                previous_json, previous_scores, previous_group, first_row = previous
                if normalized_text(json.loads(previous_json)["text"]) != normalized_text(record["text"]):
                    raise ValueError(f"{location}: a text-hash collision was detected; no data was published")
                if previous_scores != scores_json:
                    raise ValueError(
                        f"{location}: conflicting labels for a normalized duplicate of record/line {first_row}; "
                        "review these records before splitting. No outputs were committed."
                    )
                if previous_group != group_key:
                    raise ValueError(
                        f"{location}: normalized duplicate of record/line {first_row} has a different group ID; "
                        "merge the connected groups or review these records before splitting. No outputs were committed."
                    )
                duplicate_rows += 1
            if total_rows % 10000 == 0:
                connection.commit()
            if total_rows % 100000 == 0:
                print(f"Scanned {total_rows:,} records; kept {unique_rows:,}; duplicates removed {duplicate_rows:,}", file=sys.stderr)
        connection.commit()
        if total_rows == 0:
            raise ValueError("Input contains no labeled records. Convert and inspect valid source rows before splitting; no outputs were committed.")

        required_splits = ["train"]
        if validation_ratio > 0:
            required_splits.append("validation")
        if test_ratio > 0:
            required_splits.append("test")
        number_of_groups = connection.execute("SELECT COUNT(DISTINCT group_key) FROM examples").fetchone()[0]
        if number_of_groups < len(required_splits):
            raise ValueError(
                f"Only {unique_rows} unique record(s) in {number_of_groups} independent group(s); "
                f"cannot fill {len(required_splits)} requested splits without group leakage. "
                "A one-row attachment is suitable for conversion verification only. "
                "Supply more data, or explicitly set --validation-ratio 0 --test-ratio 0 for a conversion/data smoke check. "
                "No outputs were committed."
            )

        connection.execute("CREATE TABLE groups (group_key TEXT PRIMARY KEY, split TEXT NOT NULL)")
        group_counts = {name: 0 for name in SPLIT_NAMES}
        pending: list[tuple[str, str]] = []
        for (key,) in connection.execute("SELECT DISTINCT group_key FROM examples"):
            split = _split_for_key(key, seed, validation_ratio, test_ratio)
            group_counts[split] += 1
            pending.append((key, split))
            if len(pending) >= 10000:
                connection.executemany("INSERT INTO groups(group_key,split) VALUES (?,?)", pending)
                pending.clear()
        if pending:
            connection.executemany("INSERT INTO groups(group_key,split) VALUES (?,?)", pending)
        connection.commit()

        counts = {name: 0 for name in SPLIT_NAMES}
        split_labels = {name: _score_counts(names) for name in SPLIT_NAMES}
        with ExitStack() as stack:
            handles = {
                name: stack.enter_context((staging / f"{name}.jsonl").open("w", encoding="utf-8", newline="\n"))
                for name in SPLIT_NAMES
            }
            for raw_json, scores_json, split in connection.execute(
                "SELECT e.raw_json,e.scores,g.split FROM examples e "
                "JOIN groups g ON e.group_key=g.group_key ORDER BY e.rowid"
            ):
                handles[split].write(raw_json + "\n")
                counts[split] += 1
                _count_scores(split_labels[split], json.loads(scores_json))
        empty = [split for split in required_splits if counts[split] == 0]
        if empty:
            raise ValueError(
                f"Hash splitting produced empty requested split(s): {', '.join(empty)}. "
                "Use more independent groups, another seed, or larger validation/test ratios. "
                "No outputs were committed."
            )

        requested_ratios = {"train": 1.0 - validation_ratio - test_ratio, "validation": validation_ratio, "test": test_ratio}
        warnings: list[str] = []
        for split in required_splits:
            absent_labels = {
                dimension: [score for score, count in distribution.items() if count == 0]
                for dimension, distribution in split_labels[split].items()
            }
            absent_labels = {dimension: scores for dimension, scores in absent_labels.items() if scores}
            if absent_labels:
                warnings.append(f"{split}: some dimension/score bins have no examples: {absent_labels}")
        report: dict[str, Any] = {
            "pipeline": PIPELINE_ID,
            "input_file": str(source),
            "seed": seed,
            "input_rows": total_rows,
            "unique_rows": unique_rows,
            "duplicates_removed": duplicate_rows,
            "conflicting_label_duplicates": 0,
            "conflicting_group_duplicates": 0,
            "text_column": text_column,
            "scores_column": scores_column if score_columns is None else None,
            "score_columns": list(score_columns) if score_columns is not None else None,
            "num_dimensions": num_dimensions,
            "dimension_names": names,
            "group_column": resolved_group_column,
            "preserved_fields": ["id", "group_id", "dimension_names", *PROVENANCE_KEYS],
            "deduplication": "Exact normalized text: Unicode NFC, LF line endings, leading/trailing whitespace trimmed; internal whitespace and case preserved. First occurrence retained; conflicting labels or group IDs abort.",
            "split_method": "Seeded SHA-256 of group ID, or normalized text when ungrouped. Ratios are approximate, not stratified. No semantic/paraphrase deduplication or chronological split is performed.",
            "requested_ratios": requested_ratios,
            "group_count": sum(group_counts.values()),
            "splits": {
                name: {
                    "file": f"{name}.jsonl",
                    "rows": counts[name],
                    "fraction": counts[name] / unique_rows,
                    "groups": group_counts[name],
                    "score_counts": split_labels[name],
                }
                for name in SPLIT_NAMES
            },
            "input_score_counts": input_counts,
            "unique_score_counts": unique_counts,
            "warnings": warnings,
        }
        (staging / "report.json").write_text(
            json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8"
        )
        connection.close()
        connection = None
        database_path.unlink()
        _publish_directory(staging, output, overwrite)
        return report
    finally:
        if connection is not None:
            connection.close()
        if staging.exists():
            shutil.rmtree(staging)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--input", required=True, help="Input .jsonl/.json/.csv/.parquet file")
    parser.add_argument("--output-dir", required=True, help="Directory for canonical train/validation/test.jsonl and report.json")
    parser.add_argument("--config", help="Optional shared training YAML, e.g. configs/train.yaml; explicit CLI options take precedence")
    parser.add_argument("--dimension-names", nargs="+", metavar="NAME", help="Ordered task names; default: model.dimension_names from config, or the seven XLSX dimensions")
    parser.add_argument("--num-dimensions", type=int, help="Optional count, checked against the ordered names when supplied")
    parser.add_argument("--text-column", help="Text column (default: config data.text_column, or text)")
    scores = parser.add_mutually_exclusive_group()
    scores.add_argument("--scores-column", help="Column containing a D-element score array; explicitly setting this disables config data.score_columns")
    scores.add_argument("--score-columns", nargs="+", metavar="COLUMN", help="D scalar score columns, in the model's dimension order")
    parser.add_argument("--group-column", help="Group column for source/document/conversation IDs; canonical group_id is auto-detected")
    parser.add_argument("--seed", type=int, help="Default: config training.seed, or 42")
    parser.add_argument("--validation-ratio", type=float, help="Default: config data.validation_ratio, or 0.05")
    parser.add_argument("--test-ratio", type=float, help="Default: config data.test_ratio, or 0.05")
    parser.add_argument("--overwrite", action="store_true", help="Replace only a dataset directory previously generated by this script")
    return parser


def options_from_args(args: argparse.Namespace) -> dict[str, Any]:
    """Merge explicit CLI choices over config values over standalone defaults.

    A CLI --scores-column deliberately switches back to an array column even
    when the configuration supplies scalar score_columns. An explicit count
    never silently overrides a conflicting dimension_names list.
    """
    config: dict[str, Any] = {}
    if args.config is not None:
        from five_scores.config import load_config
        from yaml import YAMLError

        try:
            config = load_config(args.config)
        except YAMLError as exc:
            raise ValueError(f"Invalid YAML configuration: {exc}") from exc
    data = config.get("data", {})
    model = config.get("model", {})
    training = config.get("training", {})
    if args.score_columns is not None:
        score_columns = args.score_columns
    elif args.scores_column is not None:
        score_columns = None
    else:
        score_columns = data.get("score_columns")
    return {
        "text_column": args.text_column if args.text_column is not None else data.get("text_column", "text"),
        "scores_column": args.scores_column if args.scores_column is not None else data.get("scores_column", "scores"),
        "score_columns": score_columns,
        "dimension_names": args.dimension_names if args.dimension_names is not None else model.get("dimension_names"),
        "num_dimensions": args.num_dimensions,
        "group_column": args.group_column,
        "seed": args.seed if args.seed is not None else training.get("seed", 42),
        "validation_ratio": args.validation_ratio if args.validation_ratio is not None else data.get("validation_ratio", 0.05),
        "test_ratio": args.test_ratio if args.test_ratio is not None else data.get("test_ratio", 0.05),
        "overwrite": args.overwrite,
    }


def main() -> int:
    args = build_parser().parse_args()
    try:
        report = prepare_dataset(
            args.input,
            args.output_dir,
            **options_from_args(args),
        )
    except (OSError, ValueError, ImportError, sqlite3.Error) as exc:
        print(f"Data preparation failed: {exc}", file=sys.stderr)
        return 2
    print(json.dumps({
        "output_dir": str(Path(args.output_dir).expanduser().absolute()),
        "input_rows": report["input_rows"],
        "unique_rows": report["unique_rows"],
        "duplicates_removed": report["duplicates_removed"],
        "num_dimensions": report["num_dimensions"],
        "dimension_names": report["dimension_names"],
        "split_rows": {name: info["rows"] for name, info in report["splits"].items()},
        "warnings": report["warnings"],
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
