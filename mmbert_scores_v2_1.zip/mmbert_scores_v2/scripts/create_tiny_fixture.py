#!/usr/bin/env python3
"""Create a fully local, random ModernBERT fixture for pipeline smoke tests.

This model has random weights and a deliberately tiny tokenizer. It verifies
loading, training, saving and inference mechanics; it cannot assess Chinese
language quality or predict useful scores. Output defaults to /tmp, outside the
source tree, and no model download is needed.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import torch
from tokenizers import Tokenizer, models, pre_tokenizers, processors
from transformers import ModernBertConfig, ModernBertForMaskedLM, PreTrainedTokenizerFast

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from five_scores.schema import DEFAULT_DIMENSION_NAMES, default_dimension_names, validate_num_dimensions


def create_fixture(
    output: Path, train_rows: int = 80, num_dimensions: int = len(DEFAULT_DIMENSION_NAMES)
) -> Path:
    if type(train_rows) is not int or train_rows < 10:
        raise ValueError("train_rows must be at least 10")
    num_dimensions = validate_num_dimensions(num_dimensions)
    names = default_dimension_names(num_dimensions)
    output.mkdir(parents=True, exist_ok=True)
    model_dir = output / "model"
    model_dir.mkdir(exist_ok=True)
    torch.manual_seed(17)

    tokens = [
        "[PAD]", "[CLS]", "[SEP]", "[UNK]", "[MASK]",
        "这", "是", "一个", "测试", "文本", "回答", "清晰", "准确", "完整",
        "相关", "简洁", "需要", "改善", "内容", "样本", "优秀", "普通", "错误",
        "训练", "验证", "评估", "hello", "world", "first", "second",
    ]
    tokens += [f"token{i}" for i in range(64 - len(tokens))]
    tokenizer_backend = Tokenizer(models.WordLevel(
        vocab={token: i for i, token in enumerate(tokens)}, unk_token="[UNK]"
    ))
    tokenizer_backend.pre_tokenizer = pre_tokenizers.Whitespace()
    tokenizer_backend.post_processor = processors.TemplateProcessing(
        single="[CLS] $A [SEP]",
        pair="[CLS] $A [SEP] $B:1 [SEP]:1",
        special_tokens=[("[CLS]", 1), ("[SEP]", 2)],
    )
    tokenizer = PreTrainedTokenizerFast(
        tokenizer_object=tokenizer_backend,
        unk_token="[UNK]", pad_token="[PAD]", cls_token="[CLS]",
        sep_token="[SEP]", bos_token="[CLS]", eos_token="[SEP]",
        mask_token="[MASK]", model_max_length=128,
        model_input_names=["input_ids", "attention_mask"],
    )
    tokenizer.save_pretrained(model_dir)

    config = ModernBertConfig(
        vocab_size=64,
        hidden_size=32,
        intermediate_size=64,
        num_hidden_layers=2,
        num_attention_heads=4,
        max_position_embeddings=128,
        local_attention=32,
        global_attn_every_n_layers=2,
        pad_token_id=0,
        bos_token_id=1,
        eos_token_id=2,
        cls_token_id=1,
        sep_token_id=2,
        reference_compile=False,
        embedding_dropout=0.0,
        attention_dropout=0.0,
        mlp_dropout=0.0,
        classifier_dropout=0.0,
    )
    # Saving the *MLM* wrapper, rather than the custom classifier, exercises
    # real pretrained-backbone transfer and missing/new classification weights.
    ModernBertForMaskedLM(config).save_pretrained(model_dir, safe_serialization=True)

    for split, count, offset in (("train", train_rows, 0), ("validation", 20, 1000), ("test", 20, 2000)):
        with (output / f"{split}.jsonl").open("w", encoding="utf-8") as stream:
            for i in range(count):
                n = i + offset
                row = {
                    "id": f"{split}-{i:04d}",
                    "group_id": f"{split}-group-{i // 2:04d}",
                    # Whitespace-delimited Chinese is intentional for this
                    # synthetic tokenizer. Each exact text is split-unique.
                    "text": f"这 是 一个 测试 文本 {split} 样本 {n} token{i % 34}",
                    "scores": [((i + d) % 5) + 1 for d in range(num_dimensions)],
                    "dimension_names": names,
                }
                stream.write(json.dumps(row, ensure_ascii=False) + "\n")
    with (output / "predict.jsonl").open("w", encoding="utf-8") as stream:
        for i, value in enumerate(("这 是 一个 清晰 回答", "需要 改善 内容", "hello world")):
            stream.write(json.dumps({"id": str(i), "text": value}, ensure_ascii=False) + "\n")
    (output / "fixture_schema.json").write_text(
        json.dumps({"num_dimensions": num_dimensions, "dimension_names": names, "num_classes": 5},
                   ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return output


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("/tmp/mmbert-scores-fixture"))
    parser.add_argument("--train-rows", type=int, default=80)
    parser.add_argument("--num-dimensions", type=int, default=len(DEFAULT_DIMENSION_NAMES))
    args = parser.parse_args()
    if args.num_dimensions < 1:
        parser.error("--num-dimensions must be positive")
    print(create_fixture(args.output, args.train_rows, args.num_dimensions).resolve())


if __name__ == "__main__":
    main()
