#!/usr/bin/env python3
"""Single-process FastAPI service. Run: MODEL_DIR=... python serve.py

Environment: MODEL_DIR (required), DEVICE=cuda, DTYPE=auto, BATCH_SIZE=32,
MAX_LENGTH=<checkpoint value>, ATTN_IMPLEMENTATION=sdpa, COMPILE_MODEL=false,
MAX_REQUEST_TEXTS=128, MAX_TEXT_CHARS=50000, MAX_TOTAL_CHARS=200000,
REJECT_TRUNCATION=false. HOST defaults to 127.0.0.1 and PORT to 8000.
Use one server worker per GPU; each worker would otherwise load its own model.
"""

from __future__ import annotations

import os
from contextlib import asynccontextmanager
from typing import Any

import torch
from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field, StrictBool, StrictStr

from five_scores.inference import ScorePredictor


def env_int(name: str, default: int) -> int:
    try:
        value = int(os.getenv(name, str(default)))
    except ValueError as exc:
        raise ValueError(f"{name} must be a positive integer") from exc
    if value < 1:
        raise ValueError(f"{name} must be a positive integer")
    return value


def env_bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name, str(default)).lower()
    if value in {"true", "1", "yes"}:
        return True
    if value in {"false", "0", "no"}:
        return False
    raise ValueError(f"{name} must be true or false")


class PredictRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    texts: list[StrictStr] = Field(min_length=1)
    include_probabilities: StrictBool = False
    reject_truncation: StrictBool = False


@asynccontextmanager
async def lifespan(application: FastAPI):
    model_dir = os.getenv("MODEL_DIR")
    if not model_dir:
        raise RuntimeError("Set MODEL_DIR to the saved trained checkpoint directory before starting the server")
    application.state.batch_size = env_int("BATCH_SIZE", 32)
    application.state.max_request_texts = env_int("MAX_REQUEST_TEXTS", 128)
    application.state.max_total_chars = env_int("MAX_TOTAL_CHARS", 200_000)
    application.state.reject_truncation = env_bool("REJECT_TRUNCATION")
    application.state.predictor = ScorePredictor(
        model_dir, device=os.getenv("DEVICE", "cuda"), precision=os.getenv("DTYPE", "auto"),
        max_length=env_int("MAX_LENGTH", 512) if os.getenv("MAX_LENGTH") else None,
        attn_implementation=os.getenv("ATTN_IMPLEMENTATION", "sdpa"),
        compile_model=env_bool("COMPILE_MODEL"), max_text_chars=env_int("MAX_TEXT_CHARS", 50_000),
    )
    try:
        yield
    finally:
        application.state.predictor = None


app = FastAPI(title="mmBERT Five-Dimension Scoring", version="1.0.0", lifespan=lifespan)


@app.get("/health")
def health(request: Request) -> dict[str, Any]:
    predictor: ScorePredictor | None = getattr(request.app.state, "predictor", None)
    if predictor is None:
        raise HTTPException(status_code=503, detail="Model is not ready")
    return {
        "status": "ok", "dimensions": predictor.dimension_names,
        "device": str(predictor.device), "precision": predictor.precision,
        "max_length": predictor.max_length,
    }


@app.post("/predict")
def predict(payload: PredictRequest, request: Request) -> dict[str, Any]:
    state = request.app.state
    predictor: ScorePredictor | None = getattr(state, "predictor", None)
    if predictor is None:
        raise HTTPException(status_code=503, detail="Model is not ready")
    if len(payload.texts) > state.max_request_texts:
        raise HTTPException(status_code=422, detail=f"At most {state.max_request_texts} texts per request are allowed")
    if sum(len(text) for text in payload.texts) > state.max_total_chars:
        raise HTTPException(status_code=422, detail=f"Request exceeds MAX_TOTAL_CHARS={state.max_total_chars}")
    try:
        predictions = predictor.predict(
            payload.texts, batch_size=state.batch_size,
            include_probabilities=payload.include_probabilities,
            reject_truncation=state.reject_truncation or payload.reject_truncation,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except torch.cuda.OutOfMemoryError as exc:
        raise HTTPException(status_code=503, detail="GPU memory exhausted; reduce BATCH_SIZE or request size") from exc
    return {"dimensions": predictor.dimension_names, "predictions": predictions}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host=os.getenv("HOST", "127.0.0.1"), port=env_int("PORT", 8000), workers=1)
