"""Shared offline fixtures. Tests never download a pretrained checkpoint."""

from __future__ import annotations

import os
import runpy
from pathlib import Path

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

import pytest
import torch
from transformers import AutoConfig

from five_scores.schema import DEFAULT_DIMENSION_NAMES, default_dimension_names

DIMENSIONS = list(DEFAULT_DIMENSION_NAMES)


@pytest.fixture(scope="session", autouse=True)
def single_cpu_thread():
    original = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(original)


@pytest.fixture(scope="session")
def tiny_pretrained(tmp_path_factory):
    path = tmp_path_factory.mktemp("tiny_modernbert")
    namespace = runpy.run_path(
        str(Path(__file__).resolve().parents[1] / "scripts" / "create_tiny_fixture.py")
    )
    namespace["create_fixture"](path, train_rows=20)
    return path


@pytest.fixture
def tiny_config(tiny_pretrained, request):
    config = AutoConfig.from_pretrained(tiny_pretrained / "model", local_files_only=True)
    # Selected tests use indirect parametrization to verify 1D/5D/7D with the
    # same tiny offline backbone; most tests exercise the seven-dimensional default.
    config.score_dim_names = default_dimension_names(getattr(request, "param", len(DIMENSIONS)))
    config.score_pooling = "mean"
    config.score_max_length = 128
    config.score_model_version = 2
    config.score_ordinal_weight = 0.0
    config._attn_implementation = "sdpa"
    return config


@pytest.fixture
def input_batch():
    return {
        "input_ids": torch.tensor([[1, 5, 6, 7, 2, 0], [1, 8, 9, 2, 0, 0]]),
        "attention_mask": torch.tensor([[1, 1, 1, 1, 1, 0], [1, 1, 1, 1, 0, 0]]),
    }
