"""Configuration invariants that prevent label-order/count mistakes."""

import json

import pytest

from five_scores.config import load_config
from five_scores.schema import DEFAULT_DIMENSION_NAMES


def write_config(tmp_path, value):
    path = tmp_path / "config.yaml"
    path.write_text(json.dumps(value), encoding="utf-8")
    return path


@pytest.mark.parametrize("count", [1, 5, 7])
def test_dimensions_and_equal_weights_derive_from_names(tmp_path, count):
    names = [f"dimension_{index}" for index in range(count)]
    config = load_config(write_config(tmp_path, {"model": {"dimension_names": names}}))
    assert config["model"]["num_dimensions"] == count
    assert config["model"]["dimension_names"] == names
    assert config["model"]["dimension_weights"] == [1.0] * count


def test_defaults_use_all_rows_seven_names_and_epoch_eval(tmp_path):
    config = load_config(write_config(tmp_path, {}))
    assert config["model"]["dimension_names"] == list(DEFAULT_DIMENSION_NAMES)
    assert config["data"]["max_train_samples"] is None
    assert config["training"]["eval_strategy"] == "epoch"


@pytest.mark.parametrize("model", [
    {"dimension_names": []},
    {"dimension_names": ["a", " a "]},
    {"dimension_names": ["a"], "num_dimensions": 7},
    {"dimension_names": ["a"], "dimension_weights": [1, 1]},
    {"dimension_names": ["a"], "dimension_weights": [True]},
    {"dimension_names": ["a"], "dimension_weights": [0]},
])
def test_invalid_schema_fails_early(tmp_path, model):
    with pytest.raises(ValueError):
        load_config(write_config(tmp_path, {"model": model}))


@pytest.mark.parametrize("value", [0, -1, True, 2.5, "1000"])
def test_sample_limits_are_positive_integers_or_null(tmp_path, value):
    with pytest.raises(ValueError, match="max_train_samples"):
        load_config(write_config(tmp_path, {"data": {"max_train_samples": value}}))


def test_split_ratios_need_remaining_training_rows(tmp_path):
    with pytest.raises(ValueError, match="ratio"):
        load_config(write_config(tmp_path, {"data": {"validation_ratio": 0.5, "test_ratio": 0.5}}))


def test_unknown_option_is_not_silently_ignored(tmp_path):
    with pytest.raises(ValueError, match="Unknown data options"):
        load_config(write_config(tmp_path, {"data": {"max_training_samples": 20}}))


def test_every_step_evaluation_can_save_its_best_model(tmp_path):
    with pytest.raises(ValueError, match="save_steps must equal eval_steps"):
        load_config(write_config(tmp_path, {"training": {
            "eval_strategy": "steps", "eval_steps": 10, "save_steps": 20,
        }}))
