"""CSV reader contract tests using only temporary standard-library fixtures.

These checks exercise the public converter, including shared row validation
and atomic output publication. No user data or XLSX workbooks are modified.
"""

from __future__ import annotations

import builtins
from copy import deepcopy
import csv
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from five_scores.excel import DEFAULT_CONVERSION, convert_files, resolve_settings
from five_scores.schema import DEFAULT_DIMENSION_NAMES


def config(**overrides):
    options = deepcopy(DEFAULT_CONVERSION)
    options.update(csv_encoding="utf-8-sig", csv_delimiter=",")
    options.update(overrides)
    return {"model": {"dimension_names": list(DEFAULT_DIMENSION_NAMES)}, "conversion": options}


def valid_row():
    # Keep identifiers as strings, including leading zeroes. The overall score
    # and model name are metadata, not any of the seven classification labels.
    return {
        "id": "000001", "scene_key": "000023", "score_status": "done",
        "core_elements": " 用户与场景 ", "scene_description": "真实场景",
        "pain_analysis": "实际问题", "solution": "解决方法", "domains": "行业A",
        "authenticity": "4", "value": "3.0", "relevance": "4", "severity": "4",
        "effectiveness": "3", "innovativeness": "3", "feasibility": "3",
        "score": "3.3", "model_name": "Qwen3.5-4B",
        "scored_at": "2026-10-19T01:02:03", "create_time": "",
    }


class CSVConversionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.source = self.root / "source.csv"
        self.output = self.root / "converted"

    def write_csv(self, rows, *, headers=None, encoding="utf-8-sig", delimiter=",", prefix=(), path=None):
        path = path or self.source
        names = list(valid_row()) if headers is None else headers
        with path.open("w", encoding=encoding, newline="") as handle:
            writer = csv.writer(handle, delimiter=delimiter, lineterminator="\r\n")
            writer.writerows(prefix)
            writer.writerow(names)
            for row in rows:
                writer.writerow([row.get(name, "") for name in names] if isinstance(row, dict) else row)
        return path

    def convert(self, conf=None, **kwargs):
        return convert_files([self.source], self.output, conf or config(), **kwargs)

    def records(self, name="labeled.jsonl"):
        return [json.loads(line) for line in (self.output / name).read_text(encoding="utf-8").splitlines()]

    def test_utf8_bom_quoted_commas_quotes_and_newlines_preserve_the_contract(self):
        row = valid_row()
        row["scene_description"] = ' 第一站是A,B站\r\n乘客说："请稍等" '
        self.write_csv([row])
        before = self.source.read_bytes()
        report = self.convert()
        self.assertTrue(before.startswith(b"\xef\xbb\xbf"))
        self.assertEqual(self.source.read_bytes(), before)
        self.assertEqual((report["input_rows"], report["accepted_rows"], report["rejected_rows"]), (1, 1, 0))
        result = self.records()[0]
        self.assertEqual(result["id"], "000001")
        self.assertEqual(result["group_id"], "000023")
        self.assertEqual(result["scores"], [4, 3, 4, 4, 3, 3, 3])
        self.assertEqual(result["dimension_names"], list(DEFAULT_DIMENSION_NAMES))
        self.assertEqual(result["text"], '【核心要素】用户与场景\n【场景描述】第一站是A,B站\n乘客说："请稍等"\n【痛点分析】实际问题\n【解决方案】解决方法\n【所属领域】行业A')
        self.assertEqual(result["metadata"]["source_file"], str(self.source.resolve()))
        self.assertIsNone(result["metadata"]["source_sheet"])
        self.assertEqual(result["metadata"]["source_row"], 2)
        self.assertEqual(result["metadata"]["model_name"], "Qwen3.5-4B")
        self.assertEqual(result["metadata"]["score"], "3.3")
        self.assertNotIn("Qwen", result["text"])
        self.assertNotIn("3.3", result["text"])
        template = json.loads((self.output / "text_template.json").read_text(encoding="utf-8"))
        self.assertEqual(template["dimension_names"], list(DEFAULT_DIMENSION_NAMES))

    def test_utf8_without_bom_and_csv_only_do_not_require_openpyxl(self):
        self.write_csv([valid_row()], encoding="utf-8")
        original_import = builtins.__import__

        def without_excel(name, *args, **kwargs):
            if name == "openpyxl" or name.startswith("openpyxl."):
                raise ImportError("openpyxl deliberately unavailable in CSV-only test")
            return original_import(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=without_excel):
            self.assertEqual(self.convert()["accepted_rows"], 1)

    def test_gb18030_encoding_is_explicit_and_decoding_failure_publishes_nothing(self):
        self.write_csv([valid_row()], encoding="gb18030")
        with self.assertRaisesRegex(ValueError, r"--encoding") as failure:
            self.convert()
        self.assertIsInstance(failure.exception.__cause__, UnicodeError)
        self.assertFalse(self.output.exists())
        report = self.convert(config(csv_encoding="gb18030"))
        self.assertEqual(report["accepted_rows"], 1)
        self.assertIn("【场景描述】真实场景", self.records()[0]["text"])

    def test_invalid_csv_encoding_options_fail_with_configuration_errors(self):
        for encoding in (None, "", " ", True, 123, "no-such-encoding", "base64_codec"):
            with self.subTest(encoding=encoding):
                with self.assertRaisesRegex(ValueError, r"csv_encoding"):
                    resolve_settings(config(csv_encoding=encoding))

    def test_invalid_csv_delimiters_fail_with_configuration_errors(self):
        for delimiter in (None, "", True, 123, ",;", '"', "\r", "\n", "\x00"):
            with self.subTest(delimiter=delimiter):
                with self.assertRaisesRegex(ValueError, r"csv_delimiter"):
                    resolve_settings(config(csv_delimiter=delimiter))

    def test_description_larger_than_default_csv_field_limit_is_preserved(self):
        row = valid_row()
        row["scene_description"] = "内容" * 70000
        self.assertGreater(len(row["scene_description"]), 128 * 1024)
        self.write_csv([row])
        original_limit = csv.field_size_limit()
        self.assertEqual(self.convert()["accepted_rows"], 1)
        self.assertEqual(csv.field_size_limit(), original_limit)
        self.assertIn("【场景描述】" + row["scene_description"] + "\n【痛点分析】", self.records()[0]["text"])

    def test_semicolon_and_tab_delimiters(self):
        for actual, configured in [(";", ";"), ("\t", "\t"), ("\t", r"\t")]:
            with self.subTest(delimiter=configured):
                self.write_csv([valid_row()], delimiter=actual)
                self.convert(config(csv_delimiter=configured), overwrite=self.output.exists())
                self.assertEqual(self.records()[0]["scores"], [4, 3, 4, 4, 3, 3, 3])

    def test_header_row_and_source_rows_count_logical_records(self):
        first = valid_row()
        first["scene_description"] = "first physical line\nsecond physical line"
        second = valid_row()
        second["id"] = "000002"
        self.write_csv([first, [], second], prefix=(["export metadata"], ["generated on 2026-10-19"]))
        report = self.convert(config(header_row=3))
        self.assertEqual((report["scanned_rows"], report["blank_rows"], report["input_rows"]), (3, 1, 2))
        self.assertEqual([row["metadata"]["source_row"] for row in self.records()], [4, 6])

    def test_header_whitespace_is_trimmed(self):
        names = list(valid_row())
        self.write_csv([list(valid_row().values())], headers=[f" {name} " for name in names])
        self.assertEqual(self.convert()["accepted_rows"], 1)

    def test_duplicate_and_missing_headers_abort_before_publication(self):
        names = list(valid_row())
        for headers in (names + [" value "], names[:-1]):
            with self.subTest(headers=headers):
                self.write_csv([], headers=headers)
                with self.assertRaises(ValueError):
                    self.convert()
                self.assertFalse(self.output.exists())

    def test_missing_header_row_aborts_before_publication(self):
        self.source.write_text("", encoding="utf-8")
        with self.assertRaises(ValueError):
            self.convert()
        self.assertFalse(self.output.exists())

    def test_invalid_scores_status_and_blank_records_have_explicit_diagnostics(self):
        bad_status = valid_row()
        bad_status["score_status"] = "failed"
        fractional = valid_row()
        fractional["authenticity"] = "3.5"
        missing_score = valid_row()
        missing_score["feasibility"] = ""
        self.write_csv([valid_row(), bad_status, fractional, missing_score, [], [""] * len(valid_row())])
        report = self.convert()
        self.assertEqual((report["scanned_rows"], report["input_rows"], report["accepted_rows"], report["rejected_rows"], report["blank_rows"]), (6, 4, 1, 3, 2))
        self.assertEqual(report["rejection_reason_rows"], {"invalid_score": 2, "status_not_accepted": 1})
        rejected = self.records("rejected.jsonl")
        self.assertEqual([row["source_row"] for row in rejected], [3, 4, 5])
        self.assertTrue(all(row["source_sheet"] is None for row in rejected))
        self.assertEqual(rejected[1]["raw"]["authenticity"], "3.5")

    def test_extra_and_missing_csv_fields_are_rejected_even_when_empty(self):
        values = list(valid_row().values())
        # The omitted final field is optional metadata. A CSV record still
        # must match the header width: silently accepting it hides export bugs.
        self.write_csv([values, values + [""], values + ["unexpected"], values[:-1]])
        report = self.convert()
        self.assertEqual((report["accepted_rows"], report["rejected_rows"]), (1, 3))
        for row in self.records("rejected.jsonl"):
            reason_text = json.dumps(row["reasons"], ensure_ascii=False).lower()
            self.assertTrue("field" in reason_text or "column" in reason_text, reason_text)
            self.assertTrue("count" in reason_text or "expected" in reason_text or "length" in reason_text, reason_text)

    def test_malformed_quoted_record_preserves_all_prior_output_files(self):
        self.write_csv([valid_row()])
        self.convert()
        before = {path.name: path.read_bytes() for path in self.output.iterdir()}
        with self.source.open("a", encoding="utf-8", newline="") as handle:
            handle.write('"unterminated quoted field\n')
        with self.assertRaises((ValueError, csv.Error)):
            self.convert(overwrite=True)
        after = {path.name: path.read_bytes() for path in self.output.iterdir()}
        self.assertEqual(after, before)
        self.assertEqual(list(self.root.glob(".converted.tmp-*")), [])

    def test_csv_formula_like_text_is_literal_but_not_a_valid_score(self):
        row = valid_row()
        row["solution"] = "=SUM(1,2) 是原始文本"
        bad = deepcopy(row)
        bad["value"] = "=2+1"
        self.write_csv([row, bad])
        report = self.convert()
        self.assertEqual((report["accepted_rows"], report["rejected_rows"]), (1, 1))
        self.assertIn("【解决方案】=SUM(1,2) 是原始文本", self.records()[0]["text"])
        self.assertEqual(report["rejection_reason_rows"], {"invalid_score": 1})

    def test_selected_dimensions_determine_csv_label_order_and_manifest(self):
        self.write_csv([valid_row()])
        conf = config(score_columns=["feasibility", "authenticity"])
        conf["model"]["dimension_names"] = ["可行性", "真实性"]
        report = self.convert(conf)
        self.assertEqual(report["num_dimensions"], 2)
        self.assertEqual(self.records()[0]["dimension_names"], ["可行性", "真实性"])
        self.assertEqual(self.records()[0]["scores"], [3, 4])
        template = json.loads((self.output / "text_template.json").read_text(encoding="utf-8"))
        self.assertEqual(template["score_columns"], ["feasibility", "authenticity"])

    def test_all_invalid_csv_still_publishes_reviewable_diagnostics(self):
        row = valid_row()
        row["authenticity"] = "6"
        self.write_csv([row])
        report = self.convert()
        self.assertEqual(report["status"], "no_valid_rows")
        self.assertEqual(self.records(), [])
        self.assertEqual(len(self.records("rejected.jsonl")), 1)
        self.assertTrue((self.output / "report.json").is_file())

    def test_multiple_csv_paths_are_aggregated_with_distinct_provenance(self):
        second = self.root / "export[1].CSV"
        self.write_csv([valid_row()])
        self.write_csv([valid_row()], path=second)
        report = convert_files([self.source, second, self.source], self.output, config())
        self.assertEqual(report["accepted_rows"], 2)
        self.assertEqual(len(report["source_reports"]), 2)
        self.assertEqual([row["metadata"]["source_file"] for row in self.records()], [str(self.source.resolve()), str(second.resolve())])


if __name__ == "__main__":
    unittest.main()
