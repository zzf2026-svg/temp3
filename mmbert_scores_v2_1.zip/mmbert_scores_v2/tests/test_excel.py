"""Converter behavior tests; workbooks are mocked, never authored or modified.

These tests run with the standard unittest runner as well as pytest. The input
fixtures are inert byte placeholders; the actual Excel reader is replaced by
mock workbook objects. The user's real XLSX can be checked separately.
"""

from __future__ import annotations

from copy import deepcopy
from datetime import datetime
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from five_scores.excel import (
    DEFAULT_CONVERSION,
    PIPELINE_ID,
    build_input_text,
    build_text_from_template,
    convert_workbooks,
    expand_input_paths,
    parse_rating,
    resolve_settings,
    validate_row,
)
from five_scores.schema import DEFAULT_DIMENSION_NAMES


def config(**overrides):
    options = deepcopy(DEFAULT_CONVERSION)
    options.update(overrides)
    return {"model": {"dimension_names": list(DEFAULT_DIMENSION_NAMES)}, "conversion": options}


def valid_row():
    return {
        "id": "sample-001", "scene_key": "scene-001", "score_status": "done",
        "core_elements": " 用户与场景 ", "scene_description": "真实场景",
        "pain_analysis": "实际问题", "solution": "解决方法", "domains": "行业A",
        "authenticity": 4, "value": 3, "relevance": 4, "severity": 4,
        "effectiveness": 3, "innovativeness": 3, "feasibility": 3,
        "score": 3.3, "model_name": "Qwen3.5-4B",
        "scored_at": datetime(2026, 10, 19, 1, 2, 3), "create_time": None,
    }


class Cell:
    def __init__(self, value=None, data_type=None):
        self.value = value
        self.data_type = data_type or ("s" if isinstance(value, str) else "n")


class Sheet:
    def __init__(self, rows):
        self.rows = rows
        self.reset = False

    def reset_dimensions(self):
        self.reset = True

    def iter_rows(self, min_row=1):
        return iter(self.rows[min_row - 1:])


class Workbook:
    def __init__(self, rows, name="Sheet1"):
        self.sheetnames = [name]
        self.sheet = Sheet(rows)
        self.closed = False

    def __getitem__(self, name):
        if name not in self.sheetnames:
            raise KeyError(name)
        return self.sheet

    def close(self):
        self.closed = True


def fake_workbook(rows, headers=None):
    names = list(valid_row()) if headers is None else headers
    return Workbook([[Cell(name) for name in names]] + [
        [value if isinstance(value, Cell) else Cell(value) for value in row]
        if isinstance(row, list) else [
            row.get(name) if isinstance(row.get(name), Cell) else Cell(row.get(name))
            for name in names
        ]
        for row in rows
    ])


class RatingTests(unittest.TestCase):
    def test_integer_scores_accept_exact_values_only(self):
        for value, expected in [(1, 1), (5, 5), (3.0, 3), (" 4 ", 4), ("3.0", 3)]:
            with self.subTest(value=value):
                self.assertEqual(parse_rating(value), expected)
        for value in [True, False, None, "", " ", 0, 6, -1, 3.5, "3.5", float("nan"), float("inf"), "nan", "3e0", "=2+1"]:
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    parse_rating(value)


class RowTests(unittest.TestCase):
    def validate(self, row=None, conf=None, **kwargs):
        return validate_row(row or valid_row(), resolve_settings(conf or config()), source_file="source.xlsx", source_sheet="Sheet1", source_row=2, **kwargs)

    def test_actual_seven_dimension_contract(self):
        result, errors = self.validate()
        self.assertEqual(errors, [])
        self.assertEqual(result["scores"], [4, 3, 4, 4, 3, 3, 3])
        self.assertEqual(result["dimension_names"], list(DEFAULT_DIMENSION_NAMES))
        self.assertEqual(result["text"], "【核心要素】用户与场景\n【场景描述】真实场景\n【痛点分析】实际问题\n【解决方案】解决方法\n【所属领域】行业A")
        self.assertEqual(result["group_id"], "scene-001")
        self.assertEqual(result["metadata"]["score"], 3.3)
        self.assertEqual(result["metadata"]["model_name"], "Qwen3.5-4B")
        self.assertEqual(result["metadata"]["source_row"], 2)
        self.assertEqual(result["metadata"]["scored_at"], "2026-10-19T01:02:03")
        self.assertNotIn("Qwen", result["text"])
        self.assertNotIn("3.3", result["text"])

    def test_dimension_reordering_subset_and_mapping(self):
        conf = config()
        conf["model"]["dimension_names"] = ["second", "first"]
        conf["conversion"]["score_columns"] = ["value", "authenticity"]
        result, errors = self.validate(conf=conf)
        self.assertEqual(errors, [])
        self.assertEqual(result["scores"], [3, 4])
        self.assertEqual(result["dimension_names"], ["second", "first"])

    def test_nonaccepted_status_and_bad_labels_are_not_imputed(self):
        row = valid_row()
        row.update(score_status="failed", authenticity=3.5, feasibility=None)
        result, errors = self.validate(row)
        self.assertIsNone(result)
        self.assertEqual({error["code"] for error in errors}, {"status_not_accepted", "invalid_score"})
        self.assertEqual(sum(error["code"] == "invalid_score" for error in errors), 2)

    def test_formula_and_error_cells_are_not_cached_labels(self):
        result, errors = self.validate(formula_columns={"authenticity"}, error_columns={"value"})
        self.assertIsNone(result)
        self.assertEqual({error["code"] for error in errors}, {"formula_cell", "excel_error"})

    def test_null_id_group_status_disable_behaviors(self):
        row = valid_row()
        row.update(id=None, scene_key=None, score_status=None)
        result, errors = self.validate(row, config(id_column=None, group_column=None, status_column=None))
        self.assertEqual(errors, [])
        self.assertNotIn("id", result)
        self.assertNotIn("group_id", result)

    def test_required_text_and_group_cannot_be_blank(self):
        row = valid_row()
        row.update(solution="  ", scene_key=None)
        result, errors = self.validate(row)
        self.assertIsNone(result)
        self.assertEqual({error["code"] for error in errors}, {"invalid_text", "invalid_identifier"})

    def test_optional_text_fields_omit_blanks_and_reusable_template_matches(self):
        row = valid_row()
        row.update(core_elements=None, domains="  ", scene_description="  A\r\nB  ")
        settings = resolve_settings(config())
        expected = "【场景描述】A\nB\n【痛点分析】实际问题\n【解决方案】解决方法"
        self.assertEqual(build_input_text(row, settings), expected)
        manifest = json.loads(json.dumps(settings.text_template()))
        self.assertEqual(build_text_from_template(row, manifest), expected)

    def test_config_rejects_label_leakage_and_order_mismatch(self):
        for conf in [
            config(text_columns=["score"], required_text_columns=[]),
            config(text_columns=["value"], required_text_columns=[]),
            config(score_columns=["authenticity"]),
            config(header_row=True),
            config(text_columns=["solution", " solution "], required_text_columns=[]),
        ]:
            with self.subTest(conf=conf):
                with self.assertRaises(ValueError):
                    resolve_settings(conf)


class ConversionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.source = self.root / "source.xlsx"
        self.source.write_bytes(b"inert mock reader input; this is not an authored workbook")
        self.output = self.root / "converted"

    def convert(self, workbook, **kwargs):
        with patch("openpyxl.load_workbook", return_value=workbook) as reader:
            report = convert_workbooks([self.source], self.output, config(), **kwargs)
        reader.assert_called_once_with(self.source.resolve(), read_only=True, data_only=False, keep_links=False)
        self.assertTrue(workbook.closed)
        self.assertTrue(workbook.sheet.reset)
        return report

    def test_streaming_conversion_keeps_diagnostics_and_metadata(self):
        rejected = valid_row()
        rejected["authenticity"] = 3.5
        formula = valid_row()
        formula["value"] = Cell("=2+1", "f")
        blank = {name: None for name in valid_row()}
        before = self.source.read_bytes()
        report = self.convert(fake_workbook([valid_row(), rejected, formula, blank]))
        self.assertEqual((report["input_rows"], report["accepted_rows"], report["rejected_rows"], report["blank_rows"]), (3, 1, 2, 1))
        self.assertEqual(report["label_distributions"]["authenticity"]["4"], 1)
        self.assertEqual(report["rejection_reason_rows"], {"formula_cell": 1, "invalid_score": 1})
        self.assertEqual(self.source.read_bytes(), before)
        accepted = [json.loads(line) for line in (self.output / "labeled.jsonl").read_text(encoding="utf-8").splitlines()]
        self.assertEqual(accepted[0]["metadata"]["source_row"], 2)
        errors = [json.loads(line) for line in (self.output / "rejected.jsonl").read_text(encoding="utf-8").splitlines()]
        self.assertEqual([item["source_row"] for item in errors], [3, 4])
        self.assertEqual(errors[1]["raw"]["value"], "=2+1")
        self.assertEqual(set(path.name for path in self.output.iterdir()), {"labeled.jsonl", "rejected.jsonl", "report.json", "text_template.json"})

    def test_all_invalid_publishes_diagnostics_with_no_valid_status(self):
        row = valid_row()
        row["score_status"] = None
        report = self.convert(fake_workbook([row]))
        self.assertEqual(report["status"], "no_valid_rows")
        self.assertEqual((self.output / "labeled.jsonl").read_text(), "")
        self.assertTrue((self.output / "report.json").is_file())

    def test_header_names_trimmed_but_duplicates_fail_without_publication(self):
        names = list(valid_row())
        data = [list(valid_row().values())]
        book = fake_workbook(data, [f" {name} " for name in names])
        self.assertEqual(self.convert(book)["accepted_rows"], 1)
        existing = (self.output / "labeled.jsonl").read_bytes()
        bad = fake_workbook(data, names + [" value "])
        with patch("openpyxl.load_workbook", return_value=bad):
            with self.assertRaisesRegex(ValueError, "duplicate header"):
                convert_workbooks([self.source], self.output, config(), overwrite=True)
        self.assertEqual((self.output / "labeled.jsonl").read_bytes(), existing)
        self.assertTrue(bad.closed)

    def test_missing_schema_and_sheet_fail_without_output(self):
        for book in [fake_workbook([valid_row()], list(valid_row())[:-1]), Workbook([], name="Other")]:
            with patch("openpyxl.load_workbook", return_value=book):
                with self.assertRaises(ValueError):
                    convert_workbooks([self.source], self.output, config())
            self.assertFalse(self.output.exists())
            self.assertTrue(book.closed)

    def test_multiple_paths_sorted_globs_and_duplicates_are_deterministic(self):
        second = self.root / "second.xlsx"
        second.write_bytes(b"another inert mock input")
        paths = expand_input_paths([str(self.root / "*.xlsx"), self.source])
        self.assertEqual(paths, [second.resolve(), self.source.resolve()])
        books = [fake_workbook([valid_row()]), fake_workbook([valid_row()])]
        with patch("openpyxl.load_workbook", side_effect=books):
            report = convert_workbooks([self.source, second], self.output, config())
        self.assertEqual(report["accepted_rows"], 2)
        self.assertEqual(len(report["source_reports"]), 2)

    def test_existing_literal_filename_with_glob_metacharacters(self):
        literal = self.root / "export[1].xlsx"
        literal.write_bytes(b"inert mock input")
        self.assertEqual(expand_input_paths([literal]), [literal.resolve()])

    def test_later_workbook_schema_error_rolls_back_complete_batch(self):
        self.convert(fake_workbook([valid_row()]))
        old_report = (self.output / "report.json").read_bytes()
        old_data = (self.output / "labeled.jsonl").read_bytes()
        second = self.root / "second.xlsx"
        second.write_bytes(b"inert mock input")
        books = [fake_workbook([valid_row()]), fake_workbook([valid_row()], ["id", "score"])]
        with patch("openpyxl.load_workbook", side_effect=books):
            with self.assertRaisesRegex(ValueError, "missing configured columns"):
                convert_workbooks([self.source, second], self.output, config(), overwrite=True)
        self.assertEqual((self.output / "report.json").read_bytes(), old_report)
        self.assertEqual((self.output / "labeled.jsonl").read_bytes(), old_data)
        self.assertTrue(all(book.closed for book in books))
        self.assertFalse(list(self.root.glob(".converted.tmp-*")))

    def test_overwrite_protection_preserves_unrelated_and_source_directories(self):
        self.output.mkdir()
        precious = self.output / "keep.txt"
        precious.write_text("user file")
        with self.assertRaises(ValueError):
            convert_workbooks([self.source], self.output, config(), overwrite=True)
        self.assertEqual(precious.read_text(), "user file")
        with self.assertRaisesRegex(ValueError, "outside the output"):
            convert_workbooks([self.source], self.root, config(), overwrite=True)
        self.assertTrue(self.source.is_file())

    def test_owned_directory_can_be_replaced(self):
        self.convert(fake_workbook([valid_row()]))
        row = valid_row()
        row["authenticity"] = 5
        report = self.convert(fake_workbook([row]), overwrite=True)
        self.assertEqual(report["label_distributions"]["authenticity"]["5"], 1)
        self.assertEqual(json.loads((self.output / "report.json").read_text())["pipeline"], PIPELINE_ID)


if __name__ == "__main__":
    unittest.main()
