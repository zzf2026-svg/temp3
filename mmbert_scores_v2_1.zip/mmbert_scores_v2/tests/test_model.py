"""Verify the expensive risks: backbone transfer, loss, masking, persistence."""

from __future__ import annotations

import pytest
import torch
import torch.nn.functional as F
from transformers import ModernBertForMaskedLM

from five_scores.modeling import ModernBertForFiveScores, ModernBertForMultiScores


def test_loads_actual_mlm_backbone(tiny_pretrained, tiny_config):
    source = ModernBertForMaskedLM.from_pretrained(
        tiny_pretrained / "model", local_files_only=True, attn_implementation="sdpa"
    )
    target = ModernBertForFiveScores.from_pretrained(
        tiny_pretrained / "model", config=tiny_config,
        local_files_only=True, attn_implementation="sdpa"
    )
    # Compare every backbone tensor so an incorrect pretrained prefix cannot
    # silently turn supervised fine-tuning into training a random encoder.
    assert set(source.model.state_dict()) == set(target.model.state_dict())
    for key, value in source.model.state_dict().items():
        torch.testing.assert_close(target.model.state_dict()[key], value, rtol=0, atol=0)
    # A custom head must be initialized by our override: upstream ModernBERT
    # only initializes classifier weights for its own built-in task classes.
    assert torch.isfinite(target.classifier.weight).all()
    assert 1e-3 < target.classifier.weight.float().std() < 1
    assert target.classifier.weight.abs().max() < 5
    torch.testing.assert_close(target.classifier.bias, torch.zeros_like(target.classifier.bias))


@pytest.mark.parametrize("tiny_config", [1, 5, 7], indirect=True)
def test_dynamic_head_cross_entropy_and_backbone_gradient(tiny_config, input_batch):
    torch.manual_seed(5)
    model = ModernBertForFiveScores(tiny_config)
    dimensions = len(tiny_config.score_dim_names)
    labels = torch.stack([torch.arange(dimensions) % 5, (4 - torch.arange(dimensions)) % 5])
    output = model(**input_batch, labels=labels)
    assert output.logits.shape == (2, dimensions, 5)
    expected = F.cross_entropy(output.logits.reshape(-1, 5), labels.reshape(-1))
    torch.testing.assert_close(output.loss, expected)
    output.loss.backward()
    assert model.classifier.weight.grad is not None
    assert torch.isfinite(model.classifier.weight.grad).all()
    assert model.classifier.weight.grad.abs().sum() > 0
    assert any(p.grad is not None and p.grad.abs().sum() > 0 for p in model.model.parameters())


@pytest.mark.parametrize("pooling", ["mean", "cls"])
def test_right_padding_does_not_change_scores(tiny_config, pooling):
    tiny_config.score_pooling = pooling
    model = ModernBertForFiveScores(tiny_config).eval()
    ids = torch.tensor([[1, 5, 6, 2]])
    padded = F.pad(ids, (0, 7), value=0)
    with torch.inference_mode():
        reference = model(input_ids=ids, attention_mask=torch.ones_like(ids)).logits
        result = model(input_ids=padded, attention_mask=padded.ne(0).long()).logits
    torch.testing.assert_close(result, reference, rtol=1e-4, atol=1e-6)


@pytest.mark.parametrize("tiny_config", [5, 7], indirect=True)
def test_save_reload_keeps_logits_and_scoring_metadata(tmp_path, tiny_config, input_batch):
    tiny_config.score_ordinal_weight = 0.15
    tiny_config.score_dim_weights = [float(i + 1) for i in range(len(tiny_config.score_dim_names))]
    model = ModernBertForFiveScores(tiny_config).eval()
    with torch.inference_mode():
        before = model(**input_batch).logits
    model.save_pretrained(tmp_path, safe_serialization=True)
    restored = ModernBertForFiveScores.from_pretrained(
        tmp_path, local_files_only=True, attn_implementation="sdpa"
    ).eval()
    with torch.inference_mode():
        after = restored(**input_batch).logits
    torch.testing.assert_close(after, before, rtol=0, atol=0)
    for field in (
        "score_dim_names", "score_pooling", "score_max_length",
        "score_model_version", "score_ordinal_weight", "score_num_dimensions",
        "score_num_classes", "score_dim_weights",
    ):
        assert getattr(restored.config, field) == getattr(tiny_config, field)


def test_weighted_ordinal_loss_keeps_dimension_and_class_axes_separate(tiny_config, input_batch):
    dimensions = len(tiny_config.score_dim_names)
    tiny_config.score_dim_weights = [float(i + 1) for i in range(dimensions)]
    tiny_config.score_ordinal_weight = 0.3
    model = ModernBertForFiveScores(tiny_config)
    labels = torch.arange(2 * dimensions).reshape(2, dimensions) % 5
    output = model(**input_batch, labels=labels)
    ce = F.cross_entropy(output.logits.reshape(-1, 5), labels.reshape(-1), reduction="none").reshape(2, dimensions)
    predicted_cdf = output.logits.softmax(-1).cumsum(-1)[..., :-1]
    true_cdf = F.one_hot(labels, 5).float().cumsum(-1)[..., :-1]
    ordinal = (predicted_cdf - true_cdf).square().mean(-1)
    weights = torch.tensor(tiny_config.score_dim_weights)
    expected = ((ce + 0.3 * ordinal) * weights).sum(-1).div(weights.sum()).mean()
    torch.testing.assert_close(output.loss, expected)


@pytest.mark.parametrize("tiny_config", [5], indirect=True)
def test_legacy_version_one_checkpoint_keeps_five_dimensions(tmp_path, tiny_config, input_batch):
    tiny_config.score_model_version = 1
    model = ModernBertForFiveScores(tiny_config).eval()
    assert ModernBertForMultiScores is ModernBertForFiveScores
    model.save_pretrained(tmp_path, safe_serialization=True)
    restored = ModernBertForMultiScores.from_pretrained(
        tmp_path, local_files_only=True, attn_implementation="sdpa"
    ).eval()
    with torch.inference_mode():
        torch.testing.assert_close(restored(**input_batch).logits, model(**input_batch).logits, rtol=0, atol=0)
    assert restored.num_dimensions == 5
    assert restored.config.score_model_version == 1


@pytest.mark.parametrize("names", [[], ["a", "a"], ["a", " a "], ["a", ""], ["a", " "], [1], "seven"])
def test_rejects_invalid_dimension_names(tiny_config, names):
    tiny_config.score_dim_names = names
    with pytest.raises((ValueError, TypeError)):
        ModernBertForFiveScores(tiny_config)


def test_rejects_unsupported_pooling(tiny_config):
    tiny_config.score_pooling = "last"
    with pytest.raises(ValueError):
        ModernBertForFiveScores(tiny_config)


@pytest.mark.parametrize("field,value", [
    ("score_num_dimensions", 0), ("score_num_dimensions", -1),
    ("score_num_dimensions", True), ("score_num_dimensions", 7.0),
    ("score_num_dimensions", 5), ("score_num_classes", 7),
    ("score_num_classes", True), ("score_num_classes", 5.0),
    ("score_dim_weights", [1.0] * 5), ("score_dim_weights", [0.0] * 7),
    ("score_dim_weights", [float("nan")] * 7), ("score_dim_weights", [True] * 7),
    ("score_model_version", 1), ("score_model_version", 3),
])
def test_rejects_inconsistent_scoring_metadata(tiny_config, field, value):
    setattr(tiny_config, field, value)
    with pytest.raises(ValueError):
        ModernBertForFiveScores(tiny_config)


@pytest.mark.parametrize("case", ["shape", "high", "negative", "float", "bool"])
def test_invalid_model_targets_fail_explicitly(tiny_config, input_batch, case):
    dimensions = len(tiny_config.score_dim_names)
    labels = {
        "shape": torch.zeros((2, dimensions - 1), dtype=torch.long),
        "high": torch.full((2, dimensions), 5, dtype=torch.long),
        "negative": torch.full((2, dimensions), -1, dtype=torch.long),
        "float": torch.ones((2, dimensions), dtype=torch.float32),
        "bool": torch.ones((2, dimensions), dtype=torch.bool),
    }[case]
    model = ModernBertForFiveScores(tiny_config)
    with pytest.raises((ValueError, TypeError)):
        model(**input_batch, labels=labels)
