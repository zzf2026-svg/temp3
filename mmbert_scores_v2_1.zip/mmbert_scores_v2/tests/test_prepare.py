"""Verify group isolation, conflicting-label protection and atomic outputs."""

from __future__ import annotations

import json

import pytest

from five_scores.schema import DEFAULT_DIMENSION_NAMES, default_dimension_names
from prepare_data import build_parser, options_from_args, prepare_dataset


def write_jsonl(path, rows):
    path.write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows), encoding="utf-8")


def read_jsonl(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def group_membership(directory):
    membership = {}
    for split in ("train", "validation", "test"):
        for row in read_jsonl(directory / f"{split}.jsonl"):
            group = row["group_id"]
            assert membership.setdefault(group, split) == split, f"Group {group} leaked across splits"
    return membership


@pytest.mark.parametrize("dimensions", [1, 5, 7])
def test_split_preserves_groups_and_is_independent_of_input_order(tmp_path, dimensions):
    names = default_dimension_names(dimensions)
    scores = [(dimension % 5) + 1 for dimension in range(dimensions)]
    rows = [
        {"id": f"{i}-{j}", "group_id": f"document-{i}", "text": f"文档 {i} 段落 {j}", "scores": scores}
        for i in range(100) for j in range(2)
    ]
    # Same content and labels in one group: one canonical example is retained.
    rows.append({**rows[0], "id": "duplicate", "text": "  " + rows[0]["text"] + "\n"})
    source = tmp_path / "source.jsonl"
    first, second = tmp_path / "first", tmp_path / "second"
    write_jsonl(source, rows)
    report = prepare_dataset(source, first, dimension_names=names, validation_ratio=0.2, test_ratio=0.2, seed=19)
    assert report["input_rows"] == 201
    assert report["unique_rows"] == 200
    assert report["duplicates_removed"] == 1
    assert report["dimension_names"] == names
    assert report["num_dimensions"] == dimensions
    assert list(report["input_score_counts"]) == names
    assert sum(report["splits"][split]["rows"] for split in ("train", "validation", "test")) == 200
    assert all(report["splits"][split]["rows"] > 0 for split in ("train", "validation", "test"))
    first_membership = group_membership(first)
    assert len(first_membership) == 100
    write_jsonl(source, list(reversed(rows)))
    prepare_dataset(source, second, dimension_names=names, validation_ratio=0.2, test_ratio=0.2, seed=19)
    assert group_membership(second) == first_membership


@pytest.mark.parametrize("change,error", [
    ({"scores": [5, 4, 3, 2, 1]}, "conflicting labels"),
    ({"group_id": "other-document"}, "different group ID"),
])
def test_conflicting_duplicates_abort_and_preserve_previous_outputs(tmp_path, change, error):
    source = tmp_path / "source.jsonl"
    destination = tmp_path / "prepared"
    first = {"text": "相同 文本", "scores": [1, 2, 3, 4, 5], "group_id": "document-1"}
    write_jsonl(source, [first])
    prepare_dataset(source, destination, num_dimensions=5, validation_ratio=0, test_ratio=0)
    before = {path.name: path.read_bytes() for path in destination.iterdir()}
    write_jsonl(source, [first, {**first, **change}])
    with pytest.raises(ValueError, match=error):
        prepare_dataset(source, destination, num_dimensions=5, validation_ratio=0, test_ratio=0, overwrite=True)
    assert {path.name: path.read_bytes() for path in destination.iterdir()} == before


@pytest.mark.parametrize("reverse", [False, True])
def test_mixed_group_ids_are_rejected_in_any_order(tmp_path, reverse):
    rows = [
        {"text": "第一条", "scores": [1, 2, 3, 4, 5], "group_id": "document"},
        {"text": "第二条", "scores": [1, 2, 3, 4, 5]},
    ]
    source = tmp_path / "mixed.jsonl"
    write_jsonl(source, list(reversed(rows)) if reverse else rows)
    with pytest.raises(ValueError, match="group"):
        prepare_dataset(source, tmp_path / "out", num_dimensions=5, validation_ratio=0, test_ratio=0)
    assert not (tmp_path / "out").exists()


def test_single_row_conversion_provenance_is_preserved_without_forced_split(tmp_path):
    source = tmp_path / "source.jsonl"
    destination = tmp_path / "prepared"
    names = list(DEFAULT_DIMENSION_NAMES)
    record = {
        "id": "original-001", "group_id": "scene-001", "text": "合成文本，仅用于转换验证",
        "scores": [4, 3, 4, 4, 3, 3, 3], "dimension_names": names,
        "metadata": {"source_file": "sample.xlsx", "source_sheet": "Sheet1", "source_row": 2, "score": 3.3},
        "source_row": 2,
    }
    write_jsonl(source, [record])
    with pytest.raises(ValueError, match="independent group"):
        prepare_dataset(source, destination)
    assert not destination.exists()
    report = prepare_dataset(source, destination, validation_ratio=0, test_ratio=0)
    assert read_jsonl(destination / "train.jsonl") == [record]
    assert read_jsonl(destination / "validation.jsonl") == []
    assert report["num_dimensions"] == 7
    assert report["splits"]["train"]["rows"] == 1


def test_declared_dimension_order_mismatch_aborts_without_outputs(tmp_path):
    source = tmp_path / "reordered.jsonl"
    row = {"text": "测试", "scores": [4, 3], "dimension_names": ["first", "second"]}
    write_jsonl(source, [row])
    with pytest.raises(ValueError, match="dimension_names/order"):
        prepare_dataset(source, tmp_path / "out", dimension_names=["second", "first"], validation_ratio=0, test_ratio=0)
    assert not (tmp_path / "out").exists()


@pytest.mark.parametrize("metadata", [None, "unstructured", [1, 2], {"bad": float("nan")}])
def test_invalid_metadata_has_a_clear_row_diagnostic(tmp_path, metadata):
    source = tmp_path / "invalid_metadata.jsonl"
    write_jsonl(source, [{"text": "测试", "scores": [1] * 7, "metadata": metadata}])
    with pytest.raises(ValueError, match="record/line 1: metadata"):
        prepare_dataset(source, tmp_path / "out", validation_ratio=0, test_ratio=0)
    assert not (tmp_path / "out").exists()


def test_mixed_record_dimensions_fail_instead_of_silently_truncating(tmp_path):
    source = tmp_path / "mixed_dimensions.jsonl"
    write_jsonl(source, [{"text": "七维", "scores": [1] * 7}, {"text": "五维", "scores": [1] * 5}])
    with pytest.raises(ValueError, match="record/line 2: expected exactly 7"):
        prepare_dataset(source, tmp_path / "out", validation_ratio=0, test_ratio=0)
    assert not (tmp_path / "out").exists()


def test_output_directory_protects_unrelated_files_even_with_overwrite(tmp_path):
    source = tmp_path / "source.jsonl"
    destination = tmp_path / "out"
    destination.mkdir()
    original = destination / "my_notes.txt"
    original.write_text("keep me", encoding="utf-8")
    write_jsonl(source, [{"text": "输入", "scores": [1] * 7}])
    with pytest.raises(ValueError, match="only replaces"):
        prepare_dataset(source, destination, validation_ratio=0, test_ratio=0, overwrite=True)
    assert original.read_text(encoding="utf-8") == "keep me"


def test_cli_config_and_explicit_overrides_have_unambiguous_precedence(tmp_path):
    config = tmp_path / "train.yaml"
    # JSON is a YAML subset and keeps this fixture simple.
    config.write_text(json.dumps({
        "model": {"dimension_names": ["first", "second"]},
        "data": {"score_columns": ["score_a", "score_b"], "validation_ratio": 0.2, "test_ratio": 0.1},
        "training": {"seed": 19},
    }), encoding="utf-8")
    base = ["--input", "unused.jsonl", "--output-dir", "unused_out", "--config", str(config)]
    inherited = options_from_args(build_parser().parse_args(base))
    assert inherited["dimension_names"] == ["first", "second"]
    assert inherited["score_columns"] == ["score_a", "score_b"]
    assert inherited["seed"] == 19
    assert inherited["validation_ratio"] == 0.2
    assert inherited["test_ratio"] == 0.1

    overridden = options_from_args(build_parser().parse_args(base + [
        "--scores-column", "scores", "--dimension-names", "only", "--num-dimensions", "1",
        "--seed", "5", "--validation-ratio", "0", "--test-ratio", "0",
    ]))
    assert overridden["score_columns"] is None
    assert overridden["dimension_names"] == ["only"]
    assert overridden["num_dimensions"] == 1
    assert overridden["seed"] == 5
    assert overridden["validation_ratio"] == 0
    assert overridden["test_ratio"] == 0


def test_optional_count_must_agree_with_names_before_reading_source(tmp_path):
    with pytest.raises(ValueError, match="does not match"):
        prepare_dataset(tmp_path / "unused.jsonl", tmp_path / "out", dimension_names=["one"], num_dimensions=7)


def test_empty_input_has_explicit_diagnostic(tmp_path):
    source = tmp_path / "empty.jsonl"
    source.write_text("\n", encoding="utf-8")
    with pytest.raises(ValueError, match="no labeled records"):
        prepare_dataset(source, tmp_path / "out")
    assert not (tmp_path / "out").exists()
