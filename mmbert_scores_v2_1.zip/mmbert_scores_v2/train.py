#!/usr/bin/env python3
"""Train mmBERT-small once per text, optimizing D five-class score distributions."""

from __future__ import annotations

import argparse
import json
import logging
import math
import os
import platform
from pathlib import Path

# Datasets.map uses separate processes; avoid oversubscribing tokenizer threads.
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import numpy as np
import torch
import transformers
import datasets
from transformers import (
    AutoTokenizer,
    DataCollatorWithPadding,
    EarlyStoppingCallback,
    ModernBertConfig,
    Trainer,
    TrainingArguments,
    set_seed,
)
from transformers.trainer_utils import get_last_checkpoint

from five_scores.config import load_config, validate_config
from five_scores.data import get_tokenized_dataset, load_labeled_dataset
from five_scores.metrics import score_metrics
from five_scores.modeling import ModernBertForFiveScores, validate_score_config


LOGGER = logging.getLogger("five_scores.train")


class ScoreCollator:
    """Dynamically pad text and stack D class indices for each example."""

    def __init__(self, tokenizer, pad_to_multiple_of=8):
        self.padder = DataCollatorWithPadding(
            tokenizer, pad_to_multiple_of=pad_to_multiple_of, return_tensors="pt"
        )

    def __call__(self, features):
        labels = [feature["labels"] for feature in features]
        inputs = [
            {key: value for key, value in row.items() if key in {"input_ids", "attention_mask"}}
            for row in features
        ]
        batch = self.padder(inputs)
        batch["labels"] = torch.tensor(labels, dtype=torch.long)
        return batch


class FiveScoreTrainer(Trainer):
    """Separate learning rates for a pretrained backbone and a new head."""

    def __init__(self, *args, head_learning_rate=1e-4, **kwargs):
        self.head_learning_rate = float(head_learning_rate)
        if not math.isfinite(self.head_learning_rate) or self.head_learning_rate <= 0:
            raise ValueError("head_learning_rate must be finite and positive")
        super().__init__(*args, **kwargs)

    def create_optimizer(self):
        if self.optimizer is None:
            decay_names = set(self.get_decay_parameter_names(self.model))
            groups = {}
            for name, parameter in self.model.named_parameters():
                if not parameter.requires_grad:
                    continue
                lr = self.head_learning_rate if name.startswith("classifier.") else self.args.learning_rate
                decay = self.args.weight_decay if name in decay_names else 0.0
                groups.setdefault((lr, decay), []).append(parameter)
            self.optimizer = torch.optim.AdamW(
                [{"params": parameters, "lr": lr, "weight_decay": decay}
                 for (lr, decay), parameters in groups.items()],
                lr=self.args.learning_rate,
                betas=(self.args.adam_beta1, self.args.adam_beta2),
                eps=self.args.adam_epsilon,
            )
        return self.optimizer


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/train.yaml")
    parser.add_argument("--model", help="Override model.name_or_path, including a local MLM checkpoint")
    parser.add_argument("--train-file")
    parser.add_argument("--validation-file")
    parser.add_argument("--text-template-file", help="Save converter text_template.json with the trained model")
    parser.add_argument("--output-dir")
    parser.add_argument("--max-steps", type=int)
    parser.add_argument("--max-train-samples", type=int)
    parser.add_argument("--max-eval-samples", type=int)
    parser.add_argument("--resume-from-checkpoint", help="Checkpoint directory, or 'auto'")
    parser.add_argument("--precision", choices=["auto", "bf16", "fp16", "fp32"])
    parser.add_argument("--cpu", action="store_true", help="CPU mode for small functional checks")
    return parser.parse_args()


def apply_overrides(config, cli):
    for section, field, value in [
        ("model", "name_or_path", cli.model),
        ("data", "train_file", cli.train_file),
        ("data", "validation_file", cli.validation_file),
        ("data", "text_template_file", cli.text_template_file),
        ("data", "max_train_samples", cli.max_train_samples),
        ("data", "max_eval_samples", cli.max_eval_samples),
        ("training", "output_dir", cli.output_dir),
        ("training", "max_steps", cli.max_steps),
        ("training", "resume_from_checkpoint", cli.resume_from_checkpoint),
        ("training", "precision", cli.precision),
    ]:
        if value is not None:
            config[section][field] = value
    if cli.cpu:
        config["training"]["use_cpu"] = True
    validate_config(config)


def precision_settings(training):
    cpu = bool(training["use_cpu"])
    if not cpu and not torch.cuda.is_available():
        raise RuntimeError("CUDA is unavailable. Install a CUDA PyTorch wheel, or use --cpu for a functional check.")
    if not cpu and "LOCAL_RANK" in os.environ:
        # Set before querying precision support, including on mixed-GPU hosts.
        torch.cuda.set_device(int(os.environ["LOCAL_RANK"]))
    precision = training["precision"]
    if precision not in {"auto", "bf16", "fp16", "fp32"}:
        raise ValueError("precision must be auto, bf16, fp16 or fp32")
    if cpu:
        if precision not in {"auto", "fp32"}:
            raise ValueError("This project's CPU verification mode requires precision=fp32 or auto")
        return "fp32", False
    if precision == "auto":
        precision = "bf16" if torch.cuda.is_bf16_supported(including_emulation=False) else "fp16"
    if precision == "bf16" and not torch.cuda.is_bf16_supported(including_emulation=False):
        raise ValueError("This GPU does not support BF16; use precision=fp16 or fp32")
    tf32 = bool(training["tf32"]) and torch.cuda.get_device_capability()[0] >= 8
    return precision, tf32


def json_dump(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def setup_output_directory(args, requested_resume):
    """Rank-zero validation is broadcast so all DDP ranks fail together."""
    output = Path(args.output_dir)
    payload = [None, None]
    if args.process_index == 0:
        if output.exists() and not output.is_dir():
            payload[0] = f"Output path is a file, not a directory: {output}"
        elif requested_resume:
            resume = get_last_checkpoint(str(output)) if requested_resume == "auto" and output.exists() else requested_resume
            if not resume or not Path(resume).is_dir() or not (Path(resume) / "trainer_state.json").is_file():
                payload[0] = "No complete Trainer checkpoint found. Resume from checkpoint-N, not the final inference folder."
            else:
                payload[1] = str(Path(resume).resolve())
        elif output.exists() and any(output.iterdir()):
            payload[0] = f"Output directory is not empty: {output}. Choose a new directory or use --resume-from-checkpoint."
    if torch.distributed.is_available() and torch.distributed.is_initialized():
        torch.distributed.broadcast_object_list(payload, src=0)
    if payload[0]:
        raise ValueError(payload[0])
    if args.process_index == 0:
        output.mkdir(parents=True, exist_ok=True)
    if torch.distributed.is_available() and torch.distributed.is_initialized():
        torch.distributed.barrier()
    return payload[1]


def main():
    cli = parse_args()
    config = load_config(cli.config)
    apply_overrides(config, cli)
    model_options, data_options, train_options = (config[key] for key in ("model", "data", "training"))
    num_dimensions = len(model_options["dimension_names"])
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    precision, tf32 = precision_settings(train_options)
    # Validate metric-name normalization before an expensive training run.
    score_metrics(np.zeros((1, num_dimensions), dtype=np.int64),
                  np.zeros((1, num_dimensions), dtype=np.int64), model_options["dimension_names"])
    if model_options["attn_implementation"] not in {"sdpa", "eager", "flash_attention_2"}:
        raise ValueError("attn_implementation must be sdpa, eager or flash_attention_2")
    if train_options["use_cpu"] and model_options["attn_implementation"] == "flash_attention_2":
        raise ValueError("flash_attention_2 requires a supported GPU; use sdpa for CPU verification")
    for field in ("eval_steps", "save_steps", "logging_steps"):
        if isinstance(train_options[field], bool) or not isinstance(train_options[field], int) or train_options[field] <= 0:
            raise ValueError(f"{field} must be a positive integer")
    strategy = train_options["eval_strategy"]
    if strategy == "steps" and train_options["save_steps"] != train_options["eval_steps"]:
        raise ValueError("save_steps must equal eval_steps so every candidate best model is saved")
    # Make short --max-steps checks save/evaluate a checkpoint as well.
    eval_steps = train_options["eval_steps"]
    save_steps = train_options["save_steps"]
    if strategy == "steps" and 0 < train_options["max_steps"] < eval_steps:
        eval_steps = save_steps = train_options["max_steps"]

    args = TrainingArguments(
        output_dir=train_options["output_dir"],
        num_train_epochs=train_options["num_train_epochs"],
        max_steps=train_options["max_steps"],
        per_device_train_batch_size=train_options["per_device_train_batch_size"],
        per_device_eval_batch_size=train_options["per_device_eval_batch_size"],
        gradient_accumulation_steps=train_options["gradient_accumulation_steps"],
        learning_rate=train_options["learning_rate"],
        weight_decay=train_options["weight_decay"],
        warmup_ratio=train_options["warmup_ratio"],
        lr_scheduler_type=train_options["lr_scheduler_type"],
        max_grad_norm=train_options["max_grad_norm"],
        optim="adamw_torch",
        bf16=precision == "bf16",
        fp16=precision == "fp16",
        tf32=tf32,
        use_cpu=train_options["use_cpu"],
        gradient_checkpointing=train_options["gradient_checkpointing"],
        gradient_checkpointing_kwargs={"use_reentrant": False},
        eval_strategy=strategy,
        eval_steps=eval_steps,
        save_strategy=strategy,
        save_steps=save_steps,
        logging_steps=train_options["logging_steps"],
        save_total_limit=train_options["save_total_limit"],
        save_safetensors=True,
        load_best_model_at_end=True,
        metric_for_best_model="mae",
        greater_is_better=False,
        eval_accumulation_steps=8,
        dataloader_num_workers=train_options["dataloader_num_workers"],
        dataloader_pin_memory=not train_options["use_cpu"],
        dataloader_persistent_workers=train_options["dataloader_num_workers"] > 0,
        group_by_length=train_options["group_by_length"],
        length_column_name="length",
        remove_unused_columns=True,
        label_names=["labels"],
        ddp_find_unused_parameters=False,
        report_to=[],
        seed=train_options["seed"],
        data_seed=train_options["seed"],
        torch_compile=train_options["torch_compile"],
    )
    # Initialize the distributed device before any rank-zero-only file writes.
    _ = args.device
    resume = setup_output_directory(args, train_options["resume_from_checkpoint"])
    set_seed(train_options["seed"])

    source = resume or model_options["name_or_path"]
    revision = None if Path(source).exists() else model_options["revision"]
    backbone_config = ModernBertConfig.from_pretrained(source, revision=revision)
    if backbone_config.model_type != "modernbert":
        raise ValueError("This project requires a ModernBERT/mmBERT backbone")
    if resume:
        for attribute, requested in [
            ("score_dim_names", model_options["dimension_names"]),
            ("score_pooling", model_options["pooling"]),
            ("score_ordinal_weight", model_options["ordinal_weight"]),
            ("score_dim_weights", model_options["dimension_weights"]),
        ]:
            if getattr(backbone_config, attribute, None) != requested:
                raise ValueError(f"Resume config mismatch for {attribute}; use the original training configuration")
    elif hasattr(backbone_config, "score_dim_names") and backbone_config.score_dim_names != model_options["dimension_names"]:
        raise ValueError("The source is a trained scoring checkpoint with different dimensions/order. "
                         "Use the original mmBERT backbone to train a new task head.")
    backbone_config.score_dim_names = model_options["dimension_names"]
    backbone_config.score_pooling = model_options["pooling"]
    backbone_config.score_dropout = model_options["dropout"]
    backbone_config.score_dim_weights = model_options["dimension_weights"]
    backbone_config.score_ordinal_weight = model_options["ordinal_weight"]
    backbone_config.score_max_length = data_options["max_length"]
    text_template = getattr(backbone_config, "score_text_template", None)
    if data_options["text_template_file"]:
        supplied_template = json.loads(Path(data_options["text_template_file"]).read_text(encoding="utf-8"))
        if not isinstance(supplied_template, dict):
            raise ValueError("text_template_file must contain a JSON object")
        if supplied_template.get("dimension_names") != model_options["dimension_names"]:
            raise ValueError("The text template dimension order differs from the model configuration")
        if supplied_template.get("num_classes") != 5:
            raise ValueError("The text template must declare five score classes")
        if resume and text_template is not None and supplied_template != text_template:
            raise ValueError("The text template differs from the resumed checkpoint")
        text_template = supplied_template
    if text_template is not None:
        backbone_config.score_text_template = text_template
    # Avoid hidden compilation behavior; explicit torch_compile remains opt-in.
    backbone_config.reference_compile = False
    validate_score_config(backbone_config)

    tokenizer = AutoTokenizer.from_pretrained(source, revision=revision, use_fast=True)
    tokenizer.padding_side = "right"
    tokenizer.truncation_side = "right"
    if tokenizer.pad_token_id is None or tokenizer.pad_token_id != backbone_config.pad_token_id:
        raise ValueError("Tokenizer/model pad_token_id must agree")
    model, loading = ModernBertForFiveScores.from_pretrained(
        source,
        revision=revision,
        config=backbone_config,
        attn_implementation=model_options["attn_implementation"],
        torch_dtype=torch.float32,
        output_loading_info=True,
    )
    allowed_missing = set() if resume else {"classifier.weight", "classifier.bias"}
    bad_missing = set(loading.get("missing_keys", [])) - allowed_missing
    if bad_missing or loading.get("mismatched_keys") or loading.get("error_msgs"):
        raise RuntimeError(f"Backbone/checkpoint did not load completely: {loading}")
    LOGGER.info("Backbone loaded; new score-head tensors: %s", loading.get("missing_keys", []))

    with args.main_process_first(desc="validate and tokenize local datasets"):
        prepared = {}
        data_report = {}
        for split, path_key, limit_key in [
            ("train", "train_file", "max_train_samples"),
            ("validation", "validation_file", "max_eval_samples"),
        ]:
            raw = load_labeled_dataset(
                data_options[path_key],
                text_column=data_options["text_column"],
                scores_column=data_options["scores_column"],
                score_columns=data_options["score_columns"],
                num_proc=data_options["num_proc"],
                num_dimensions=num_dimensions,
                dimension_names=model_options["dimension_names"],
            )
            available_examples = len(raw)
            limit = data_options[limit_key]
            if limit is not None:
                if isinstance(limit, bool) or not isinstance(limit, int) or limit <= 0:
                    raise ValueError(f"{limit_key} must be a positive integer or null")
                raw = raw.shuffle(seed=train_options["seed"]).select(range(min(limit, len(raw))))
            if not len(raw):
                raise ValueError(f"{split} split is empty")
            # Sample only for a length diagnostic, never for the actual training input.
            texts = raw.select(range(min(2000, len(raw))))["text"]
            lengths = [len(ids) for ids in tokenizer(list(texts), truncation=False)["input_ids"]]
            data_report[split] = {
                "examples": len(raw),
                "available_examples_before_sampling": available_examples,
                "requested_max_samples": limit,
                "sampling_seed": train_options["seed"],
                "num_dimensions": num_dimensions,
                "dimension_names": model_options["dimension_names"],
                "length_sample_size": len(lengths),
                "sample_token_length_p50": float(np.quantile(lengths, 0.5)),
                "sample_token_length_p95": float(np.quantile(lengths, 0.95)),
                "sample_truncation_rate": float(np.mean(np.asarray(lengths) > data_options["max_length"])),
            }
            prepared[split] = get_tokenized_dataset(
                raw, tokenizer, max_length=data_options["max_length"], num_proc=data_options["num_proc"],
                num_dimensions=num_dimensions,
                dimension_names=model_options["dimension_names"],
            )

    def compute_metrics(evaluation):
        return score_metrics(evaluation.label_ids, evaluation.predictions, model_options["dimension_names"])

    def compact_predictions(logits, labels):
        if isinstance(logits, tuple):
            logits = logits[0]
        return logits.argmax(dim=-1)

    callbacks = []
    if train_options["early_stopping_patience"]:
        callbacks.append(EarlyStoppingCallback(early_stopping_patience=train_options["early_stopping_patience"]))
    trainer = FiveScoreTrainer(
        model=model,
        args=args,
        processing_class=tokenizer,
        train_dataset=prepared["train"],
        eval_dataset=prepared["validation"],
        data_collator=ScoreCollator(tokenizer, pad_to_multiple_of=8 if data_options["max_length"] % 8 == 0 else None),
        compute_metrics=compute_metrics,
        preprocess_logits_for_metrics=compact_predictions,
        callbacks=callbacks,
        head_learning_rate=train_options["head_learning_rate"],
    )
    if trainer.is_world_process_zero():
        json_dump(Path(args.output_dir) / "resolved_config.json", config)
        json_dump(Path(args.output_dir) / "data_report.json", data_report)
        json_dump(Path(args.output_dir) / "environment.json", {
            "python": platform.python_version(), "torch": torch.__version__,
            "transformers": transformers.__version__, "datasets": datasets.__version__,
            "cuda_runtime": torch.version.cuda,
            "gpu": torch.cuda.get_device_name(args.device) if args.device.type == "cuda" else None,
            "precision": precision, "world_size": args.world_size,
            "model_source": source, "requested_revision": revision,
            "resolved_revision": getattr(backbone_config, "_commit_hash", None),
            "trainable_parameters": sum(p.numel() for p in model.parameters() if p.requires_grad),
            "effective_batch_size": args.per_device_train_batch_size * args.gradient_accumulation_steps * args.world_size,
            "num_dimensions": num_dimensions,
            "dimension_names": model_options["dimension_names"],
            "evaluation_strategy": strategy,
        })
        LOGGER.info("Data report: %s", json.dumps(data_report, ensure_ascii=False))

    train_result = trainer.train(resume_from_checkpoint=resume)
    trainer.log_metrics("train", train_result.metrics)
    trainer.save_metrics("train", train_result.metrics)
    trainer.save_state()
    # Trainer loads the best validation checkpoint before returning from train.
    final_dir = Path(args.output_dir) / "final"
    trainer.save_model(str(final_dir))
    validation_metrics = trainer.evaluate(metric_key_prefix="validation")
    trainer.log_metrics("validation", validation_metrics)
    trainer.save_metrics("validation", validation_metrics)
    if trainer.is_world_process_zero():
        tokenizer.save_pretrained(final_dir)
        if text_template is not None:
            json_dump(final_dir / "text_template.json", text_template)
        json_dump(final_dir / "training_summary.json", {
            "best_checkpoint": trainer.state.best_model_checkpoint,
            "best_validation_mae": trainer.state.best_metric,
            "global_step": trainer.state.global_step,
            "dimension_names": model_options["dimension_names"],
            "num_dimensions": num_dimensions,
            "selection_metric": "validation mean MAE across configured dimensions (lower is better)",
            "validation_metrics": validation_metrics,
        })
        LOGGER.info("Inference checkpoint ready at %s", final_dir)


if __name__ == "__main__":
    main()
